# Leo v2.1.1

Leo is a personal Android AI assistant.

## v2.1 changes
- Android `VoiceInteractionService` / `VoiceInteractionSessionService` assistant architecture.
- Leo can be selected as the device's digital assistant through Android's role/settings UI.
- The old always-running wake-word foreground service and its notification are removed.
- Clean, solid input bar with no cloudy/translucent layer.
- New black-and-white thorn Leo icon.
- Settings > Fonts: System Default, Sans, Serif, Monospace, Cursive.
- Settings > Leo Voice: Android TTS voice selection, test voice, and voice replies toggle.
- Existing Gemini/OpenAI chat, app opening, calling, search, themes, and chat history retained.

## Important Android behavior
Android decides which assistant entry points and hotword capabilities are available on a particular phone. Selecting Leo as the system assistant enables the official Android assistant architecture; a custom third-party app cannot force a hidden microphone state or bypass Android privacy indicators.

API keys are not included in this project. Add them locally in Leo Settings.


Build fix: corrected the VoiceInteractionSessionService override signature and bumped the version to 2.1.1.
