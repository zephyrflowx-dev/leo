package com.leo.assistant

import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject

class AiClient {
    fun ask(provider: String, key: String, message: String): String {
        if (key.isBlank()) return "Add your $provider API key in Settings."
        return try {
            when (provider) {
                "OpenAI" -> openAi(key, message)
                "Anthropic" -> anthropic(key, message)
                else -> gemini(key, message)
            }
        } catch (e: Exception) {
            "Leo couldn't reach $provider. Check your internet connection."
        }
    }

    private fun openAi(key: String, msg: String): String {
        val c = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "application/json")
        val b = JSONObject().put("model", "gpt-4o-mini")
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", msg)))
        c.outputStream.use { it.write(b.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val r = if (code in 200..299) c.inputStream else c.errorStream
        val s = r?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) return openAiError(code, s)
        return JSONObject(s).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }

    private fun gemini(key: String, msg: String): String {
        val model = "gemini-3.5-flash-lite"
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        val b = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", msg)))))
        c.outputStream.use { it.write(b.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val r = if (code in 200..299) c.inputStream else c.errorStream
        val s = r?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) return geminiError(code, s)
        return JSONObject(s).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    private fun anthropic(key: String, msg: String): String {
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        val b = JSONObject()
            .put("model", "claude-sonnet-4-5")
            .put("max_tokens", 1024)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", msg)))
        c.outputStream.use { it.write(b.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val r = if (code in 200..299) c.inputStream else c.errorStream
        val s = r?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) return anthropicError(code, s)
        val content = JSONObject(s).optJSONArray("content") ?: return "Anthropic returned an empty response."
        for (i in 0 until content.length()) {
            val item = content.optJSONObject(i) ?: continue
            if (item.optString("type") == "text") return item.optString("text")
        }
        return "Anthropic returned an empty response."
    }

    private fun openAiError(code: Int, body: String): String {
        val detail = try { JSONObject(body).getJSONObject("error").optString("message") } catch (_: Exception) { "" }
        return when (code) {
            401 -> "OpenAI error 401: API key is invalid or expired."
            403 -> "OpenAI error 403: this API key is not allowed to use the requested resource."
            429 -> "OpenAI error 429: the API quota or rate limit was reached."
            else -> if (detail.isNotBlank()) "OpenAI error $code: $detail" else "OpenAI error: $code"
        }
    }

    private fun geminiError(code: Int, body: String): String {
        val detail = try { JSONObject(body).getJSONObject("error").optString("message") } catch (_: Exception) { "" }
        return when (code) {
            400 -> "Gemini error 400: the request was rejected."
            401 -> "Gemini error 401: API key is invalid or expired."
            403 -> "Gemini error 403: this API key does not have access to this resource."
            404 -> "Gemini error 404: the requested model was not found or is unavailable."
            429 -> "Gemini error 429: the API rate limit or quota was reached."
            else -> if (detail.isNotBlank()) "Gemini error $code: $detail" else "Gemini error: $code"
        }
    }

    private fun anthropicError(code: Int, body: String): String {
        val detail = try { JSONObject(body).optString("message") } catch (_: Exception) { "" }
        return when (code) {
            401 -> "Anthropic error 401: API key is invalid."
            403 -> "Anthropic error 403: this key cannot access the requested resource."
            429 -> "Anthropic error 429: rate limit reached."
            else -> if (detail.isNotBlank()) "Anthropic error $code: $detail" else "Anthropic error: $code"
        }
    }
}
