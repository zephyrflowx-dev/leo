package com.leo.assistant

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.view.Window
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

data class Msg(val text: String, val user: Boolean)
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class LeoFont { SYSTEM, SANS, SERIF, MONO, CURSIVE }

class MainActivity : ComponentActivity() {
    private var incomingVoice by mutableStateOf("")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureBars(window)
        incomingVoice = intent?.getStringExtra("voice_command").orEmpty()
        setContent { LeoApp(incomingVoice) { incomingVoice = "" } }
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incomingVoice = intent.getStringExtra("voice_command").orEmpty()
    }
}

private fun configureBars(window: Window) {
    window.navigationBarColor = android.graphics.Color.TRANSPARENT
    window.statusBarColor = android.graphics.Color.TRANSPARENT
    if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
}

@Composable
private fun LeoTheme(mode: ThemeMode, dynamic: Boolean, font: LeoFont, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val ctx = LocalContext.current
    val colors = if (dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else if (dark) {
        darkColorScheme(background = Color(0xFF0B0B0B), surface = Color(0xFF121212), surfaceContainer = Color(0xFF1A1A1A))
    } else {
        lightColorScheme(background = Color(0xFFF7F7F5), surface = Color(0xFFFFFFFF), surfaceContainer = Color(0xFFF0F0EE))
    }
    val family = when (font) {
        LeoFont.SYSTEM -> FontFamily.Default
        LeoFont.SANS -> FontFamily.SansSerif
        LeoFont.SERIF -> FontFamily.Serif
        LeoFont.MONO -> FontFamily.Monospace
        LeoFont.CURSIVE -> FontFamily.Cursive
    }
    val base = Typography()
    val typography = base.copy(
        headlineLarge = base.headlineLarge.copy(fontFamily = family),
        headlineMedium = base.headlineMedium.copy(fontFamily = family),
        titleLarge = base.titleLarge.copy(fontFamily = family),
        titleMedium = base.titleMedium.copy(fontFamily = family),
        bodyLarge = base.bodyLarge.copy(fontFamily = family),
        bodyMedium = base.bodyMedium.copy(fontFamily = family),
        bodySmall = base.bodySmall.copy(fontFamily = family),
        labelLarge = base.labelLarge.copy(fontFamily = family)
    )
    MaterialTheme(colorScheme = colors, typography = typography, content = content)
}

private sealed class CommandResult {
    data class Done(val text: String) : CommandResult()
    data object None : CommandResult()
    data object NeedContacts : CommandResult()
    data object NeedCall : CommandResult()
}

private fun handleCommand(ctx: Context, text: String): CommandResult {
    val lower = text.trim().lowercase(Locale.getDefault())
    if (lower.startsWith("open ")) return CommandResult.Done(AppActions.openApp(ctx, text.trim().substringAfter(" ")))
    if (lower == "open youtube") return CommandResult.Done(AppActions.openApp(ctx, "YouTube"))
    if (lower.startsWith("call ")) {
        val name = text.trim().substringAfter(" ").trim()
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return CommandResult.NeedContacts
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return CommandResult.NeedCall
        return CommandResult.Done(AppActions.callContact(ctx, name).second)
    }
    return CommandResult.None
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LeoApp(incomingVoice: String, onVoiceConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { SecureStore(ctx) }
    val chatStore = remember { ChatStore(ctx) }
    val scope = rememberCoroutineScope()
    var provider by remember { mutableStateOf(store.get("provider").ifBlank { "Gemini" }) }
    var openai by remember { mutableStateOf(store.get("openai")) }
    var gemini by remember { mutableStateOf(store.get("gemini")) }
    var anthropic by remember { mutableStateOf(store.get("anthropic")) }
    var input by remember { mutableStateOf("") }
    var screen by remember { mutableStateOf("home") }
    var busy by remember { mutableStateOf(false) }
    var theme by remember { mutableStateOf(runCatching { ThemeMode.valueOf(store.get("theme").ifBlank { "SYSTEM" }) }.getOrDefault(ThemeMode.SYSTEM)) }
    var dynamic by remember { mutableStateOf(store.get("dynamic_color") != "false") }
    var voiceReplies by remember { mutableStateOf(store.get("voice_replies") != "false") }
    var font by remember { mutableStateOf(runCatching { LeoFont.valueOf(store.get("font").ifBlank { "SYSTEM" }) }.getOrDefault(LeoFont.SYSTEM)) }
    var selectedVoice by remember { mutableStateOf(store.get("tts_voice")) }
    var speechResult by remember { mutableStateOf("") }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var voices by remember { mutableStateOf<List<Voice>>(emptyList()) }
    val messages = remember { mutableStateListOf<Msg>().apply { addAll(chatStore.load()) } }

    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine?.language = Locale.getDefault()
                tts = engine
                voices = engine?.voices?.filter { !it.isNetworkConnectionRequired }?.sortedBy { it.name.lowercase(Locale.getDefault()) }.orEmpty()
            }
        }
        onDispose { engine?.stop(); engine?.shutdown(); tts = null }
    }

    val speech = remember(ctx) {
        LeoSpeechController(ctx,
            onResult = { speechResult = it },
            onError = { android.widget.Toast.makeText(ctx, it, android.widget.Toast.LENGTH_SHORT).show() }
        )
    }
    DisposableEffect(speech) { onDispose { speech.stop() } }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) speech.start() }
    val contactsPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val callPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun save() = chatStore.save(messages)
    fun speak(text: String) {
        val engine = tts ?: return
        if (selectedVoice.isNotBlank()) engine.voices?.firstOrNull { it.name == selectedVoice }?.let { engine.voice = it }
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "leo")
    }
    fun send(textValue: String = input) {
        val text = textValue.trim()
        if (text.isEmpty() || busy) return
        input = ""
        messages.add(Msg(text, true)); save(); busy = true
        scope.launch {
            val command = withContext(Dispatchers.Default) { handleCommand(ctx, text) }
            val reply = when (command) {
                is CommandResult.Done -> command.text
                CommandResult.NeedContacts -> { contactsPermission.launch(Manifest.permission.READ_CONTACTS); "I need contact permission to find that person." }
                CommandResult.NeedCall -> { callPermission.launch(Manifest.permission.CALL_PHONE); "I need phone permission before placing the call." }
                CommandResult.None -> withContext(Dispatchers.IO) {
                    val key = when (provider) { "OpenAI" -> openai; "Anthropic" -> anthropic; else -> gemini }
                    AiClient().ask(provider, key, text)
                }
            }
            messages.add(Msg(reply, false)); save()
            if (voiceReplies) speak(reply)
            busy = false
        }
    }

    LaunchedEffect(incomingVoice) {
        if (incomingVoice.isNotBlank()) { screen = "home"; send(incomingVoice); onVoiceConsumed() }
    }
    LaunchedEffect(speechResult) {
        val spoken = speechResult
        if (spoken.isNotBlank()) { speechResult = ""; send(spoken) }
    }

    LeoTheme(theme, dynamic, font) {
        when (screen) {
            "settings" -> SettingsScreen(provider, { provider = it; store.put("provider", it) }, openai, { openai = it; store.put("openai", it) }, gemini, { gemini = it; store.put("gemini", it) }, anthropic, { anthropic = it; store.put("anthropic", it) }, theme, { theme = it; store.put("theme", it.name) }, dynamic, { dynamic = it; store.put("dynamic_color", it.toString()) }, voiceReplies, { voiceReplies = it; store.put("voice_replies", it.toString()) }, font, { font = it; store.put("font", it.name) }, selectedVoice, voices, { selectedVoice = it; store.put("tts_voice", it) }, { speak("Hello, I'm Leo. This is my selected voice.") }, ::openAssistantSettings, { messages.clear(); chatStore.clear(); save() }, { screen = "home" })
            "history" -> HistoryScreen(messages, { screen = "home" }, { messages.clear(); chatStore.clear(); save() })
            else -> HomeScreen(input, { input = it }, busy, messages, { send() }, { if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) speech.start() else micPermission.launch(Manifest.permission.RECORD_AUDIO) }, { screen = "history" }, { screen = "settings" })
        }
    }
}

private fun openAssistantSettings(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 29) {
        val role = ctx.getSystemService(RoleManager::class.java)
        if (role?.isRoleAvailable(RoleManager.ROLE_ASSISTANT) == true) {
            runCatching { ctx.startActivity(role.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT)) }.onFailure { ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
            return
        }
    }
    runCatching { ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
}

@Composable
private fun HomeScreen(input: String, onInput: (String) -> Unit, busy: Boolean, messages: List<Msg>, onSend: () -> Unit, onMic: () -> Unit, onHistory: () -> Unit, onSettings: () -> Unit) {
    Scaffold(containerColor = MaterialTheme.colorScheme.background, topBar = {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(com.leo.assistant.R.drawable.leo_icon), "Leo", Modifier.size(42.dp).clip(CircleShape), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(10.dp)); Text("Leo", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onHistory) { Icon(Icons.Default.History, "History") }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings") }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (messages.isEmpty()) item { EmptyHero() }
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.user) Arrangement.End else Arrangement.Start) {
                        Surface(color = if (msg.user) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainer, contentColor = if (msg.user) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, shape = RoundedCornerShape(20.dp), tonalElevation = 0.dp) {
                            Text(msg.text, Modifier.padding(horizontal = 15.dp, vertical = 11.dp), fontSize = 15.sp)
                        }
                    }
                }
            }
            Surface(color = MaterialTheme.colorScheme.background, tonalElevation = 0.dp, shadowElevation = 0.dp) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp).background(MaterialTheme.colorScheme.surface, RoundedCornerShape(24.dp)).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = input, onValueChange = onInput, Modifier.weight(1f), placeholder = { Text("Ask Leo...") }, maxLines = 5, singleLine = false, colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent), shape = RoundedCornerShape(20.dp))
                    IconButton(onClick = onMic, enabled = !busy) { Icon(Icons.Default.Mic, "Speak") }
                    IconButton(onClick = onSend, enabled = !busy && input.isNotBlank()) { Icon(Icons.Default.Send, "Send") }
                }
            }
        }
    }
}

@Composable private fun EmptyHero() {
    Column(Modifier.fillMaxWidth().padding(top = 55.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.leo_icon), "Leo", Modifier.size(88.dp).clip(CircleShape), contentScale = ContentScale.Crop)
        Spacer(Modifier.height(18.dp)); Text("What can Leo do for you?", fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp)); Text("Ask a question or speak a command.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun HistoryScreen(messages: List<Msg>, onBack: () -> Unit, onClear: () -> Unit) {
    Scaffold(topBar = { TopAppBar(navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }, title = { Text("History", fontWeight = FontWeight.Bold) }, actions = { IconButton(onClick = onClear) { Icon(Icons.Default.DeleteSweep, "Clear") } }) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (messages.isEmpty()) item { Text("No saved chats yet.") }
            items(messages) { m -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(14.dp)) { Text(if (m.user) "You" else "Leo", fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text(m.text) } } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun SettingsScreen(provider: String, onProvider: (String) -> Unit, openai: String, onOpenAi: (String) -> Unit, gemini: String, onGemini: (String) -> Unit, anthropic: String, onAnthropic: (String) -> Unit, theme: ThemeMode, onTheme: (ThemeMode) -> Unit, dynamic: Boolean, onDynamic: (Boolean) -> Unit, voiceReplies: Boolean, onVoiceReplies: (Boolean) -> Unit, font: LeoFont, onFont: (LeoFont) -> Unit, selectedVoice: String, voices: List<Voice>, onVoice: (String) -> Unit, onTestVoice: () -> Unit, onAssistant: () -> Unit, onClear: () -> Unit, onBack: () -> Unit) {
    Scaffold(topBar = { TopAppBar(navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }, title = { Text("Settings", fontWeight = FontWeight.Bold) }) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { SettingsSection("Appearance", Icons.Default.Palette) { Text("Theme", fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { ThemeChip("System", theme == ThemeMode.SYSTEM) { onTheme(ThemeMode.SYSTEM) }; ThemeChip("Light", theme == ThemeMode.LIGHT) { onTheme(ThemeMode.LIGHT) }; ThemeChip("Dark", theme == ThemeMode.DARK) { onTheme(ThemeMode.DARK) } }; Spacer(Modifier.height(10.dp)); SettingSwitch("Use device dynamic colors", dynamic, onDynamic) } }
            item { SettingsSection("Fonts", Icons.Default.TextFields) { FontSelector(font, onFont) } }
            item { SettingsSection("Leo Voice", Icons.Default.RecordVoiceOver) { SettingSwitch("Read Leo replies aloud", voiceReplies, onVoiceReplies); Spacer(Modifier.height(8.dp)); VoiceSelector(selectedVoice, voices, onVoice); Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = onTestVoice, Modifier.fillMaxWidth()) { Icon(Icons.Default.VolumeUp, null); Spacer(Modifier.width(8.dp)); Text("Test voice") } } }
            item { SettingsSection("Device Assistant", Icons.Default.Assistant) { Text("Set Leo as the phone's digital assistant.", style = MaterialTheme.typography.bodySmall); Spacer(Modifier.height(8.dp)); Button(onClick = onAssistant, Modifier.fillMaxWidth()) { Icon(Icons.Default.Assistant, null); Spacer(Modifier.width(8.dp)); Text("Set Leo as device assistant") } } }
            item { SettingsSection("AI Provider", Icons.Default.AutoAwesome) { Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { FilterChip(provider == "Gemini", { onProvider("Gemini") }, label = { Text("Gemini") }); FilterChip(provider == "OpenAI", { onProvider("OpenAI") }, label = { Text("OpenAI") }); FilterChip(provider == "Anthropic", { onProvider("Anthropic") }, label = { Text("Anthropic") }) } } }
            item { SettingsSection("API Keys", Icons.Default.Key) { Text("Keys are stored locally on this device.", style = MaterialTheme.typography.bodySmall); Spacer(Modifier.height(8.dp)); KeyField("OpenAI API key", openai, onOpenAi); Spacer(Modifier.height(8.dp)); KeyField("Gemini API key", gemini, onGemini); Spacer(Modifier.height(8.dp)); KeyField("Anthropic API key", anthropic, onAnthropic) } }
            item { SettingsSection("Chat", Icons.Default.DeleteSweep) { OutlinedButton(onClick = onClear, Modifier.fillMaxWidth()) { Icon(Icons.Default.DeleteSweep, null); Spacer(Modifier.width(8.dp)); Text("Clear saved chats") } } }
            item { SettingsSection("About Leo", Icons.Default.Info) { Text("Leo v2.5.3", fontWeight = FontWeight.SemiBold); Text("Your own AI assistant") } }
        }
    }
}

@Composable private fun KeyField(label: String, value: String, onChange: (String) -> Unit) { OutlinedTextField(value, onChange, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true, visualTransformation = PasswordVisualTransformation()) }
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun FontSelector(selected: LeoFont, onChange: (LeoFont) -> Unit) { var expanded by remember { mutableStateOf(false) }; val label = when (selected) { LeoFont.SYSTEM -> "System Default"; LeoFont.SANS -> "Sans"; LeoFont.SERIF -> "Serif"; LeoFont.MONO -> "Monospace"; LeoFont.CURSIVE -> "Cursive" }; ExposedDropdownMenuBox(expanded, { expanded = !expanded }) { OutlinedTextField(label, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Font") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }); ExposedDropdownMenu(expanded, { expanded = false }) { LeoFont.values().forEach { f -> DropdownMenuItem(text = { Text(f.name.lowercase().replaceFirstChar { it.uppercase() }) }, onClick = { onChange(f); expanded = false }) } } } }
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun VoiceSelector(selected: String, voices: List<Voice>, onChange: (String) -> Unit) { var expanded by remember { mutableStateOf(false) }; val label = voices.firstOrNull { it.name == selected }?.let { "${it.locale.displayLanguage} · ${it.name}" } ?: if (selected.isBlank()) "System default" else selected; ExposedDropdownMenuBox(expanded, { expanded = !expanded }) { OutlinedTextField(label, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Voice") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }); ExposedDropdownMenu(expanded, { expanded = false }) { DropdownMenuItem(text = { Text("System default") }, onClick = { onChange(""); expanded = false }); voices.take(60).forEach { v -> DropdownMenuItem(text = { Text("${v.locale.displayLanguage} · ${v.name}") }, onClick = { onChange(v.name); expanded = false }) } } } }
@Composable private fun SettingsSection(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)) { Column(Modifier.padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(10.dp)); Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp) }; Spacer(Modifier.height(14.dp)); content() } } }
@Composable private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(checked, onChange) } }
@Composable private fun ThemeChip(label: String, selected: Boolean, onClick: () -> Unit) { FilterChip(selected, onClick, label = { Text(label) }) }
