package com.leo.assistant

import android.Manifest
import android.app.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.view.Window
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

 data class Msg(val text: String, val user: Boolean)
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class LeoFont { SYSTEM, SANS, SERIF, MONO, CURSIVE }

class MainActivity : ComponentActivity() {
    private var incomingVoice by mutableStateOf("")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        configureBars(window)
        incomingVoice = intent?.getStringExtra("voice_command") ?: ""
        setContent { LeoApp(incomingVoice) { incomingVoice = "" } }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); incomingVoice = intent.getStringExtra("voice_command") ?: "" }
}

private fun configureBars(window: Window) {
    window.navigationBarColor = android.graphics.Color.TRANSPARENT
    window.statusBarColor = android.graphics.Color.TRANSPARENT
    if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
}

@Composable
fun LeoTheme(mode: ThemeMode, dynamicColor: Boolean, font: LeoFont, content: @Composable () -> Unit) {
    val dark = when (mode) { ThemeMode.SYSTEM -> isSystemInDarkTheme(); ThemeMode.LIGHT -> false; ThemeMode.DARK -> true }
    val context = LocalContext.current
    val colors = if (dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else if (dark) darkColorScheme(
        primary = Color(0xFFE8E8E8), onPrimary = Color(0xFF111111), primaryContainer = Color(0xFF292929), onPrimaryContainer = Color(0xFFF5F5F5), background = Color(0xFF090909), surface = Color(0xFF101010), surfaceContainer = Color(0xFF181818)
    ) else lightColorScheme(
        primary = Color(0xFF111111), onPrimary = Color.White, primaryContainer = Color(0xFFEDEDED), onPrimaryContainer = Color(0xFF111111), background = Color(0xFFF7F7F5), surface = Color.White, surfaceContainer = Color(0xFFF0F0EE)
    )
    val family = when (font) { LeoFont.SYSTEM -> FontFamily.Default; LeoFont.SANS -> FontFamily.SansSerif; LeoFont.SERIF -> FontFamily.Serif; LeoFont.MONO -> FontFamily.Monospace; LeoFont.CURSIVE -> FontFamily.Cursive }
    val base = Typography()
    val t = base.copy(
        headlineLarge=base.headlineLarge.copy(fontFamily=family), headlineMedium=base.headlineMedium.copy(fontFamily=family), titleLarge=base.titleLarge.copy(fontFamily=family), titleMedium=base.titleMedium.copy(fontFamily=family), bodyLarge=base.bodyLarge.copy(fontFamily=family), bodyMedium=base.bodyMedium.copy(fontFamily=family), bodySmall=base.bodySmall.copy(fontFamily=family), labelLarge=base.labelLarge.copy(fontFamily=family), labelMedium=base.labelMedium.copy(fontFamily=family), labelSmall=base.labelSmall.copy(fontFamily=family)
    )
    MaterialTheme(colorScheme=colors, typography=t, shapes=Shapes(extraLarge=RoundedCornerShape(28.dp), large=RoundedCornerShape(22.dp), medium=RoundedCornerShape(18.dp), small=RoundedCornerShape(14.dp), extraSmall=RoundedCornerShape(10.dp)), content=content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeoApp(incomingVoice:String, onVoiceConsumed:()->Unit) {
    val ctx=LocalContext.current; val store=remember{SecureStore(ctx)}; val chatStore=remember{ChatStore(ctx)}; val scope=rememberCoroutineScope()
    var provider by remember{mutableStateOf(store.get("provider").ifBlank{"Gemini"})}; var openai by remember{mutableStateOf(store.get("openai"))}; var gemini by remember{mutableStateOf(store.get("gemini"))}; var anthropic by remember{mutableStateOf(store.get("anthropic"))}
    var input by remember{mutableStateOf("")}; var screen by remember{mutableStateOf("home")}; var busy by remember{mutableStateOf(false)}
    var themeMode by remember{mutableStateOf(runCatching{ThemeMode.valueOf(store.get("theme").ifBlank{"SYSTEM"})}.getOrDefault(ThemeMode.SYSTEM))}; var dynamicColor by remember{mutableStateOf(store.get("dynamic_color")!="false")}; var voiceReplies by remember{mutableStateOf(store.get("voice_replies")!="false")}; var font by remember{mutableStateOf(runCatching{LeoFont.valueOf(store.get("font").ifBlank{"SYSTEM"})}.getOrDefault(LeoFont.SYSTEM))}; var selectedVoice by remember{mutableStateOf(store.get("tts_voice"))}
    var tts by remember{mutableStateOf<TextToSpeech?>(null)}; var ttsVoices by remember{mutableStateOf<List<Voice>>(emptyList())}; val messages=remember{mutableStateListOf<Msg>().apply{addAll(chatStore.load())}}
    DisposableEffect(Unit){ var engine:TextToSpeech?=null; engine=TextToSpeech(ctx){if(it==TextToSpeech.SUCCESS){engine?.language=Locale.getDefault(); tts=engine; ttsVoices=engine?.voices?.filter{v->!v.isNetworkConnectionRequired}?.sortedBy{v->v.name.lowercase(Locale.getDefault())}?:emptyList()}}; onDispose{engine?.stop();engine?.shutdown();tts=null} }
    fun saveChat()=chatStore.save(messages)
    val sendText=remember{mutableStateOf("")}; val speech=remember(ctx){LeoSpeechController(ctx,{sendText.value=it},{android.widget.Toast.makeText(ctx,it,android.widget.Toast.LENGTH_SHORT).show()})}; DisposableEffect(speech){onDispose{speech.stop()}}
    val mic=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){if(it)speech.start()}; val contacts=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){}; val call=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){}
    fun setAssistant(){if(Build.VERSION.SDK_INT>=29){val rm=ctx.getSystemService(RoleManager::class.java);if(rm!=null&&rm.isRoleAvailable(RoleManager.ROLE_ASSISTANT)){runCatching{ctx.startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT))}.onFailure{ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))};return}};runCatching{ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))}}
    fun speak(text:String){val e=tts?:return;if(selectedVoice.isNotBlank())e.voices?.firstOrNull{it.name==selectedVoice}?.let{e.voice=it};e.speak(text,TextToSpeech.QUEUE_FLUSH,null,"leo")}
    fun send(textOverride:String?=null){val text=(textOverride?:input).trim();if(text.isEmpty()||busy)return;messages.add(Msg(text,true));saveChat();input="";busy=true;scope.launch{val action=handleCommand(ctx,text);val reply=when(action){is CommandResult.Done->action.text;is CommandResult.NeedContacts->{if(ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)contacts.launch(Manifest.permission.READ_CONTACTS);"I need contact permission to find that person."};is CommandResult.NeedCall->{if(ctx.checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED)call.launch(Manifest.permission.CALL_PHONE);"I need phone permission before placing the call."};CommandResult.None->withContext(Dispatchers.IO){AiClient().ask(provider,when(provider){"OpenAI"->openai;"Anthropic"->anthropic;else->gemini},text)}};messages.add(Msg(reply,false));saveChat();if(voiceReplies)speak(reply);busy=false}}
    LaunchedEffect(incomingVoice){if(incomingVoice.isNotBlank()){screen="home";send(incomingVoice);onVoiceConsumed()}}
    LaunchedEffect(sendText.value){val spoken=sendText.value;if(spoken.isNotBlank()){sendText.value="";screen="home";send(spoken)}}
    LeoTheme(themeMode,dynamicColor,font){when(screen){"settings"->SettingsScreen(provider,{provider=it;store.put("provider",it)},openai,{openai=it;store.put("openai",it)},gemini,{gemini=it;store.put("gemini",it)},anthropic,{anthropic=it;store.put("anthropic",it)},themeMode,{themeMode=it;store.put("theme",it.name)},dynamicColor,{dynamicColor=it;store.put("dynamic_color",it.toString())},voiceReplies,{voiceReplies=it;store.put("voice_replies",it.toString())},font,{font=it;store.put("font",it.name)},selectedVoice,ttsVoices,{selectedVoice=it;store.put("tts_voice",it)},{speak("Hello, I'm Leo. This is my selected voice.")},::setAssistant,{messages.clear();chatStore.clear();messages.add(Msg("Chat cleared. Hi! I'm Leo — ready when you are.",false));saveChat()},{screen="home"});"history"->HistoryScreen(messages,{screen="home"},{messages.clear();chatStore.clear();messages.add(Msg("Hi! I'm Leo. Ask me anything, or try \"open YouTube\".",false));saveChat()});else->HomeScreen(provider,messages,input,{input=it},busy,{send()},{mic.launch(Manifest.permission.RECORD_AUDIO)},{screen="history"},{screen="settings"})}}
}

@Composable
private fun HomeScreen(provider:String,messages:List<Msg>,input:String,onInput:(String)->Unit,busy:Boolean,onSend:()->Unit,onMic:()->Unit,onHistory:()->Unit,onSettings:()->Unit){
    val bg=MaterialTheme.colorScheme.background
    Scaffold(containerColor=bg,topBar={Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=18.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically){Image(painterResource(R.drawable.leo_icon),"Leo",Modifier.size(44.dp).clip(CircleShape),contentScale=ContentScale.Crop);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("Leo",fontSize=22.sp,fontWeight=FontWeight.Bold);Text(provider,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)};IconButton(onClick=onHistory){Icon(Icons.Default.History,"History")};IconButton(onClick=onSettings){Icon(Icons.Default.Settings,"Settings")}}},bottomBar={
        Surface(color=bg,tonalElevation=0.dp,shadowElevation=0.dp){Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal=14.dp,vertical=10.dp)){Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(MaterialTheme.colorScheme.surfaceContainer).padding(6.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onMic){Icon(Icons.Default.Mic,"Voice")};BasicTextField(value=input,onValueChange=onInput,modifier=Modifier.weight(1f).padding(horizontal=8.dp,vertical=12.dp),textStyle=TextStyle(fontSize=16.sp,color=MaterialTheme.colorScheme.onSurface),singleLine=true,decorationBox={inner->if(input.isEmpty())Text("Ask Leo anything…",color=MaterialTheme.colorScheme.onSurfaceVariant);inner()});FilledIconButton(onClick=onSend,enabled=!busy,shape=CircleShape,modifier=Modifier.size(46.dp)){Icon(if(busy)Icons.Default.HourglassTop else Icons.Default.ArrowUpward,"Send")}})}}){p->
        LazyColumn(Modifier.fillMaxSize().padding(p).padding(horizontal=16.dp),contentPadding=PaddingValues(top=18.dp,bottom=18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            if(messages.isEmpty()) item{Column(Modifier.fillMaxWidth().padding(top=42.dp),horizontalAlignment=Alignment.CenterHorizontally){Image(painterResource(R.drawable.leo_icon),"Leo",Modifier.size(78.dp).clip(CircleShape),contentScale=ContentScale.Crop);Spacer(Modifier.height(20.dp));Text("What can Leo do for you?",fontSize=25.sp,fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(8.dp));Text("Ask a question, speak a command, or open an app.",color=MaterialTheme.colorScheme.onSurfaceVariant)}}
            items(messages){m->Row(Modifier.fillMaxWidth(),horizontalArrangement=if(m.user)Arrangement.End else Arrangement.Start){Surface(shape=RoundedCornerShape(22.dp),color=if(m.user)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainer,contentColor=if(m.user)MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface){Text(m.text,Modifier.padding(horizontal=16.dp,vertical=12.dp),fontSize=15.sp)}}}
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun HistoryScreen(messages:List<Msg>,onBack:()->Unit,onClear:()->Unit){Scaffold(topBar={TopAppBar(navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Back")}},title={Text("History",fontWeight=FontWeight.Bold)},actions={IconButton(onClick=onClear){Icon(Icons.Default.DeleteSweep,"Clear")}})}){p->LazyColumn(Modifier.fillMaxSize().padding(p),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){if(messages.isEmpty())item{Text("No saved chats yet.")};items(messages){m->Card(Modifier.fillMaxWidth(),RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp)){Text(if(m.user)"You"else"Leo",fontWeight=FontWeight.Bold);Spacer(Modifier.height(3.dp));Text(m.text)}}}}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun SettingsScreen(provider:String,onProviderChange:(String)->Unit,openai:String,onOpenAiChange:(String)->Unit,gemini:String,onGeminiChange:(String)->Unit,anthropic:String,onAnthropicChange:(String)->Unit,themeMode:ThemeMode,onThemeChange:(ThemeMode)->Unit,dynamicColor:Boolean,onDynamicColorChange:(Boolean)->Unit,voiceReplies:Boolean,onVoiceRepliesChange:(Boolean)->Unit,font:LeoFont,onFontChange:(LeoFont)->Unit,selectedVoice:String,voices:List<Voice>,onVoiceChange:(String)->Unit,onTestVoice:()->Unit,onSetAssistant:()->Unit,onClearChat:()->Unit,onBack:()->Unit){Scaffold(topBar={TopAppBar(navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Back")}},title={Text("Settings",fontWeight=FontWeight.Bold)})}){p->LazyColumn(Modifier.fillMaxSize().padding(p),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{SettingsSection("Appearance",Icons.Default.Palette){Text("Theme",fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ThemeChip("System",themeMode==ThemeMode.SYSTEM){onThemeChange(ThemeMode.SYSTEM)};ThemeChip("Light",themeMode==ThemeMode.LIGHT){onThemeChange(ThemeMode.LIGHT)};ThemeChip("Dark",themeMode==ThemeMode.DARK){onThemeChange(ThemeMode.DARK)}};Spacer(Modifier.height(10.dp));SettingSwitch("Use device dynamic colors",dynamicColor,onDynamicColorChange)}};item{SettingsSection("Fonts",Icons.Default.TextFields){FontSelector(font,onFontChange)}};item{SettingsSection("Leo Voice",Icons.Default.RecordVoiceOver){SettingSwitch("Read Leo replies aloud",voiceReplies,onVoiceRepliesChange);Spacer(Modifier.height(8.dp));VoiceSelector(selectedVoice,voices,onVoiceChange);Spacer(Modifier.height(8.dp));OutlinedButton(onClick=onTestVoice,Modifier.fillMaxWidth()){Icon(Icons.Default.VolumeUp,null);Spacer(Modifier.width(8.dp));Text("Test voice")}}};item{SettingsSection("Device Assistant",Icons.Default.Assistant){Text("Set Leo as the phone's digital assistant. Android decides which assistant and hotword features are available.",style=MaterialTheme.typography.bodySmall);Spacer(Modifier.height(8.dp));Button(onClick=onSetAssistant,Modifier.fillMaxWidth()){Icon(Icons.Default.Assistant,null);Spacer(Modifier.width(8.dp));Text("Set Leo as device assistant")}}};item{SettingsSection("AI Provider",Icons.Default.AutoAwesome){Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(provider=="Gemini",{onProviderChange("Gemini")},label={Text("Gemini")});FilterChip(provider=="OpenAI",{onProviderChange("OpenAI")},label={Text("OpenAI")});FilterChip(provider=="Anthropic",{onProviderChange("Anthropic")},label={Text("Anthropic")})}}};item{SettingsSection("API Keys",Icons.Default.Key){Text("Keys are stored locally on this device.",style=MaterialTheme.typography.bodySmall);Spacer(Modifier.height(8.dp));KeyField("OpenAI API key",openai,onOpenAiChange);Spacer(Modifier.height(8.dp));KeyField("Gemini API key",gemini,onGeminiChange);Spacer(Modifier.height(8.dp));KeyField("Anthropic API key",anthropic,onAnthropicChange)}};item{SettingsSection("Chat",Icons.Default.DeleteSweep){OutlinedButton(onClick=onClearChat,Modifier.fillMaxWidth()){Icon(Icons.Default.DeleteSweep,null);Spacer(Modifier.width(8.dp));Text("Clear saved chats")}}};item{SettingsSection("About Leo",Icons.Default.Info){Text("Leo v2.5.1",fontWeight=FontWeight.SemiBold);Text("Your own AI assistant",style=MaterialTheme.typography.bodyMedium)}}}}}

@Composable private fun KeyField(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value,onChange,Modifier.fillMaxWidth(),label={Text(label)},singleLine=true,visualTransformation=PasswordVisualTransformation())}
@OptIn(ExperimentalMaterial3Api::class) @Composable private fun FontSelector(selected:LeoFont,onChange:(LeoFont)->Unit){var expanded by remember{mutableStateOf(false)};val label=when(selected){LeoFont.SYSTEM->"System Default";LeoFont.SANS->"Sans";LeoFont.SERIF->"Serif";LeoFont.MONO->"Monospace";LeoFont.CURSIVE->"Cursive"};ExposedDropdownMenuBox(expanded,{expanded=!expanded}){OutlinedTextField(label,{},Modifier.menuAnchor().fillMaxWidth(),readOnly=true,label={Text("Font")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)});ExposedDropdownMenu(expanded,{expanded=false}){LeoFont.values().forEach{f->DropdownMenuItem(text={Text(when(f){LeoFont.SYSTEM->"System Default";LeoFont.SANS->"Sans";LeoFont.SERIF->"Serif";LeoFont.MONO->"Monospace";LeoFont.CURSIVE->"Cursive"})},onClick={onChange(f);expanded=false})}}}}
@OptIn(ExperimentalMaterial3Api::class) @Composable private fun VoiceSelector(selected:String,voices:List<Voice>,onChange:(String)->Unit){var expanded by remember{mutableStateOf(false)};val label=voices.firstOrNull{it.name==selected}?.let{"${it.locale.displayLanguage} · ${it.name}"}?:if(selected.isBlank())"System default"else selected;ExposedDropdownMenuBox(expanded,{expanded=!expanded}){OutlinedTextField(label,{},Modifier.menuAnchor().fillMaxWidth(),readOnly=true,label={Text("Voice")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)});ExposedDropdownMenu(expanded,{expanded=false}){DropdownMenuItem(text={Text("System default")},onClick={onChange("");expanded=false});voices.take(80).forEach{v->DropdownMenuItem(text={Text("${v.locale.displayLanguage} · ${v.name}")},onClick={onChange(v.name);expanded=false})}}}}
@Composable private fun SettingsSection(title:String,icon:androidx.compose.ui.graphics.vector.ImageVector,content:@Composable ColumnScope.()->Unit){Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),elevation=CardDefaults.cardElevation(defaultElevation=0.dp)){Column(Modifier.padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=MaterialTheme.colorScheme.primary);Spacer(Modifier.width(10.dp));Text(title,fontWeight=FontWeight.Bold,fontSize=17.sp)};Spacer(Modifier.height(14.dp));content()}}}
@Composable private fun SettingSwitch(label:String,checked:Boolean,onChange:(Boolean)->Unit){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(label,Modifier.weight(1f));Switch(checked,onChange)}}
@Composable private fun ThemeChip(label:String,selected:Boolean,onClick:()->Unit){FilterChip(selected,onClick,label={Text(label)})}
