# Leo v5.0.0

Leo is a personal Android AI assistant with a Gemini-style home experience.

## v5.0.0
- Gemini-inspired home UI with Leo branding.
- Separate normal speech mic and Live controls.
- Live uses Gemini 3.8 Live over WebSocket with PCM audio.
- Removed the wake-word engine and all wake-word settings.
- Added OpenRouter API key support.
- Added home-screen provider/model selector.
- Added model selection presets for Gemini, OpenAI, Anthropic, Groq and OpenRouter.
- API keys remain stored locally through the existing encrypted store.

Live mode requires a Gemini API key and Android microphone permission. Android keeps microphone use visible through its normal privacy/foreground-service indicators.


## v5.0.0 final UI/icon pass
- Supplied black/white Leo logo is now the launcher/adaptive icon.
- The launcher icon is not used as an in-app avatar or chat identity image.
- Home model selection is in the top bar only, matching the supplied Gemini-style layout.
- Normal voice and Live remain separate controls.
