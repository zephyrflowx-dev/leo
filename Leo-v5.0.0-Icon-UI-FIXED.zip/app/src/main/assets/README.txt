Leo v5.0.0 assets. No wake-word model is bundled; wake-word support was intentionally removed in v5.0.0.
