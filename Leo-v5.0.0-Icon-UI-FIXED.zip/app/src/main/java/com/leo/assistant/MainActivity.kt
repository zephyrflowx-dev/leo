package com.leo.assistant

import android.Manifest
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.widget.Toast
import android.view.Window
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale


data class Msg(val text: String, val user: Boolean)
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class LeoFont { SYSTEM, SANS, SERIF, MONO, CURSIVE }
enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

data class ModelOption(val label: String, val id: String)

private val providerModels = mapOf(
    "Gemini" to listOf(
        ModelOption("Gemini 3.8 Flash", "gemini-3.8-flash"),
        ModelOption("Gemini 3.7 Flash", "gemini-3.7-flash"),
        ModelOption("Gemini 3.6 Flash", "gemini-3.6-flash"),
        ModelOption("Gemini 3.5 Flash", "gemini-3.5-flash"),
        ModelOption("Gemini 3.1 Pro", "gemini-3.1-pro-preview")
    ),
    "OpenAI" to listOf(
        ModelOption("GPT-4o mini", "gpt-4o-mini")
    ),
    "Anthropic" to listOf(
        ModelOption("Claude Sonnet 4.6", "claude-sonnet-4-6")
    ),
    "Groq" to listOf(
        ModelOption("GPT-OSS 20B", "openai/gpt-oss-20b"),
        ModelOption("Llama 3.3 70B", "llama-3.3-70b-versatile")
    ),
    "OpenRouter" to listOf(
        ModelOption("OpenRouter Free", "openrouter/free"),
        ModelOption("GPT 6.1 Sol", "openai/gpt-6.1-sol"),
        ModelOption("Gemini 3.8 Flash", "google/gemini-3.8-flash"),
        ModelOption("Claude Sonnet 4.6", "anthropic/claude-sonnet-4-6")
    )
)

class MainActivity : ComponentActivity() {
    private var incomingVoice by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureBars(window)
        incomingVoice = intent?.getStringExtra("voice_command").orEmpty()
        setContent { LeoApp(incomingVoice) { incomingVoice = "" } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incomingVoice = intent.getStringExtra("voice_command").orEmpty()
    }
}

private fun configureBars(window: Window) {
    window.statusBarColor = android.graphics.Color.TRANSPARENT
    window.navigationBarColor = android.graphics.Color.TRANSPARENT
    if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
}

@Composable
private fun LeoTheme(mode: ThemeMode, dynamic: Boolean, font: LeoFont, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val ctx = LocalContext.current
    val colors = if (dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) androidx.compose.material3.dynamicDarkColorScheme(ctx) else androidx.compose.material3.dynamicLightColorScheme(ctx)
    } else if (dark) {
        androidx.compose.material3.darkColorScheme(background = Color(0xFF0B0B10), surface = Color(0xFF111119), surfaceContainer = Color(0xFF191922))
    } else {
        androidx.compose.material3.lightColorScheme(background = Color(0xFFFBF9FF), surface = Color.White, surfaceContainer = Color(0xFFF1EFF6))
    }
    val family = when (font) {
        LeoFont.SYSTEM -> FontFamily.Default
        LeoFont.SANS -> FontFamily.SansSerif
        LeoFont.SERIF -> FontFamily.Serif
        LeoFont.MONO -> FontFamily.Monospace
        LeoFont.CURSIVE -> FontFamily.Cursive
    }
    val base = androidx.compose.material3.Typography()
    MaterialTheme(colorScheme = colors, typography = base.copy(
        headlineLarge = base.headlineLarge.copy(fontFamily = family),
        headlineMedium = base.headlineMedium.copy(fontFamily = family),
        titleLarge = base.titleLarge.copy(fontFamily = family),
        titleMedium = base.titleMedium.copy(fontFamily = family),
        bodyLarge = base.bodyLarge.copy(fontFamily = family),
        bodyMedium = base.bodyMedium.copy(fontFamily = family)
    ), content = content)
}

private sealed class CommandResult {
    data class Done(val text: String) : CommandResult()
    data object None : CommandResult()
    data object NeedContacts : CommandResult()
    data object NeedCall : CommandResult()
}

private fun handleCommand(ctx: Context, text: String): CommandResult {
    val lower = text.trim().lowercase(Locale.getDefault())
    if (lower.startsWith("open ")) return CommandResult.Done(AppActions.openApp(ctx, text.trim().substringAfter(" ")))
    if (lower.startsWith("search ") || lower.startsWith("search the web for ") || lower.startsWith("google ")) {
        val query = if (lower.startsWith("search the web for ")) text.trim().substring(20) else text.trim().substringAfter(" ")
        if (query.isNotBlank()) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return CommandResult.Done("Searching the web for $query.")
        }
    }
    if (lower.startsWith("call ")) {
        val name = text.trim().substringAfter(" ").trim()
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return CommandResult.NeedContacts
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return CommandResult.NeedCall
        return CommandResult.Done(AppActions.callContact(ctx, name).second)
    }
    return CommandResult.None
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LeoApp(incomingVoice: String, onVoiceConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { SecureStore(ctx) }
    val chatStore = remember { ChatStore(ctx) }
    val scope = rememberCoroutineScope()

    var provider by remember { mutableStateOf(store.get("provider").ifBlank { "Gemini" }) }
    var model by remember { mutableStateOf(store.get("model").ifBlank { "gemini-3.8-flash" }) }
    var openai by remember { mutableStateOf(store.get("openai")) }
    var gemini by remember { mutableStateOf(store.get("gemini")) }
    var anthropic by remember { mutableStateOf(store.get("anthropic")) }
    var groq by remember { mutableStateOf(store.get("groq")) }
    var openrouter by remember { mutableStateOf(store.get("openrouter")) }
    var input by remember { mutableStateOf("") }
    var screen by remember { mutableStateOf("home") }
    var busy by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    var speaking by remember { mutableStateOf(false) }
    var liveMode by remember { mutableStateOf(store.get("live_mode") == "true") }
    var orbState by remember { mutableStateOf(OrbState.IDLE) }
    var theme by remember { mutableStateOf(runCatching { ThemeMode.valueOf(store.get("theme").ifBlank { "SYSTEM" }) }.getOrDefault(ThemeMode.SYSTEM)) }
    var dynamic by remember { mutableStateOf(store.get("dynamic_color") != "false") }
    var font by remember { mutableStateOf(runCatching { LeoFont.valueOf(store.get("font").ifBlank { "SYSTEM" }) }.getOrDefault(LeoFont.SYSTEM)) }
    var selectedVoice by remember { mutableStateOf(store.get("tts_voice")) }
    var showKeyboard by remember { mutableStateOf(false) }
    var actionLabel by remember { mutableStateOf<String?>(null) }
    var pendingCallName by remember { mutableStateOf<String?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var voices by remember { mutableStateOf<List<Voice>>(emptyList()) }
    var speechResult by remember { mutableStateOf("") }
    var attachments by remember { mutableStateOf<List<AiAttachment>>(emptyList()) }
    val messages = remember { mutableStateListOf<Msg>().apply { addAll(chatStore.load()) } }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        attachments = uris.mapNotNull { readAttachment(ctx, it) }.take(6)
    }

    val models = providerModels[provider].orEmpty()
    LaunchedEffect(provider) {
        val valid = models.any { it.id == model }
        if (!valid) {
            model = models.firstOrNull()?.id.orEmpty()
            store.put("model", model)
        }
    }

    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine?.language = Locale.getDefault()
                tts = engine
                voices = engine?.voices?.filter { !it.isNetworkConnectionRequired }?.sortedBy { it.name.lowercase(Locale.getDefault()) }.orEmpty()
            }
        }
        onDispose { engine?.stop(); engine?.shutdown(); tts = null }
    }

    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    LiveAssistantService.ACTION_STATE -> {
                        liveMode = intent.getBooleanExtra(LiveAssistantService.EXTRA_LIVE, false)
                        if (!liveMode) orbState = OrbState.IDLE
                        store.put("live_mode", liveMode.toString())
                    }
                    LiveAssistantService.ACTION_ORB_STATE -> {
                        orbState = when (intent.getStringExtra(LiveAssistantService.EXTRA_ORB_STATE)) {
                            "listening" -> OrbState.LISTENING
                            "thinking" -> OrbState.THINKING
                            "speaking" -> OrbState.SPEAKING
                            else -> OrbState.IDLE
                        }
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(LiveAssistantService.ACTION_STATE)
            addAction(LiveAssistantService.ACTION_ORB_STATE)
        }
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") ctx.registerReceiver(receiver, filter)
        onDispose { runCatching { ctx.unregisterReceiver(receiver) } }
    }

    val speech = remember(ctx) {
        LeoSpeechController(ctx, onResult = { speechResult = it }, onError = { listening = false }, onListeningChanged = { listening = it })
    }
    DisposableEffect(speech) { onDispose { speech.stop() } }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startLiveSafely(ctx, store)
    }
    val contactsPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val callPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun save() = chatStore.save(messages)
    fun speak(text: String) {
        val engine = tts ?: return
        if (selectedVoice.isNotBlank()) engine.voices?.firstOrNull { it.name == selectedVoice }?.let { engine.voice = it }
        speaking = true
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { speaking = true }
            override fun onDone(utteranceId: String?) { speaking = false }
            override fun onError(utteranceId: String?) { speaking = false }
        })
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "leo")
    }

    fun send(textValue: String = input) {
        val text = textValue.trim()
        if ((text.isEmpty() && attachments.isEmpty()) || busy) return
        val currentAttachments = attachments
        val visibleText = if (text.isBlank()) "Attached files: ${currentAttachments.joinToString(", ") { it.name }}" else text
        input = ""
        attachments = emptyList()
        showKeyboard = false
        actionLabel = null
        messages.add(Msg(visibleText, true)); save(); busy = true; orbState = OrbState.THINKING
        scope.launch {
            val lower = text.lowercase(Locale.getDefault())
            if (currentAttachments.isEmpty() && (lower.startsWith("call ") || lower.startsWith("ring "))) {
                pendingCallName = text.substringAfter(" ").trim(); busy = false; orbState = OrbState.IDLE; return@launch
            }
            val command = if (currentAttachments.isEmpty()) withContext(Dispatchers.Default) { handleCommand(ctx, text) } else CommandResult.None
            val reply = when (command) {
                is CommandResult.Done -> { actionLabel = command.text; command.text }
                CommandResult.NeedContacts -> { contactsPermission.launch(Manifest.permission.READ_CONTACTS); "I need contact permission to find that person." }
                CommandResult.NeedCall -> { callPermission.launch(Manifest.permission.CALL_PHONE); "I need phone permission to place that call." }
                CommandResult.None -> withContext(Dispatchers.IO) { AiClient().ask(provider, keyFor(provider, openai, gemini, anthropic, groq, openrouter), model, text, currentAttachments, messages.dropLast(1)) }
            }
            messages.add(Msg(reply, false)); save(); busy = false; orbState = OrbState.IDLE
        }
    }

    LaunchedEffect(speechResult) {
        if (speechResult.isNotBlank()) { input = speechResult; send(speechResult); speechResult = "" }
    }
    LaunchedEffect(incomingVoice) {
        if (incomingVoice.isNotBlank()) { send(incomingVoice); onVoiceConsumed() }
    }

    LeoTheme(theme, dynamic, font) {
        when (screen) {
            "settings" -> SettingsScreen(
                openai, { openai = it; store.put("openai", it) },
                gemini, { gemini = it; store.put("gemini", it) },
                anthropic, { anthropic = it; store.put("anthropic", it) },
                groq, { groq = it; store.put("groq", it) },
                openrouter, { openrouter = it; store.put("openrouter", it) },
                theme, { theme = it; store.put("theme", it.name) },
                dynamic, { dynamic = it; store.put("dynamic_color", it.toString()) },
                font, { font = it; store.put("font", it.name) }, selectedVoice, voices,
                { selectedVoice = it; store.put("tts_voice", it) },
                { speak("Hello, I'm Leo. Your voice assistant is ready.") },
                { openAssistantSettings(ctx) },
                { messages.clear(); chatStore.clear(); save() },
                { screen = "home" }
            )
            "history" -> HistoryScreen(messages, { screen = "home" }, { messages.clear(); chatStore.clear(); save() })
            else -> HomeScreen(
                input, busy, listening, speaking, liveMode, orbState, provider, model, models, messages, attachments, actionLabel, showKeyboard,
                onProvider = { provider = it; store.put("provider", it) },
                onModel = { model = it; store.put("model", it) },
                onInput = { input = it },
                onSuggestion = { input = it; send(it) },
                onPickFiles = { filePicker.launch(arrayOf("*/*")) },
                onRemoveAttachment = { i -> attachments = attachments.toMutableList().also { it.removeAt(i) } },
                onNewChat = { messages.clear(); chatStore.clear(); actionLabel = null },
                onSend = { send() },
                onLive = {
                    if (liveMode) LiveAssistantService.stop(ctx)
                    else if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    else startLiveSafely(ctx, store)
                },
                onHistory = { screen = "history" }, onSettings = { screen = "settings" },
                onKeyboard = { showKeyboard = !showKeyboard }, onSay = { speak(it) }, onPickMic = { speech.start() }
            )
        }
    }

    if (pendingCallName != null) {
        val name = pendingCallName!!
        AlertDialog(onDismissRequest = { pendingCallName = null }, title = { Text("Call $name?") }, text = { Text("Leo will place the call only after confirmation.") },
            confirmButton = { Button(onClick = { pendingCallName = null; send("call $name") }) { Text("Call") } },
            dismissButton = { TextButton(onClick = { pendingCallName = null }) { Text("Cancel") } })
    }
}

private fun keyFor(provider: String, openai: String, gemini: String, anthropic: String, groq: String, openrouter: String) = when (provider) {
    "OpenAI" -> openai
    "Anthropic" -> anthropic
    "Groq" -> groq
    "OpenRouter" -> openrouter
    else -> gemini
}

private fun startLiveSafely(ctx: Context, store: SecureStore) {
    if (store.get("gemini").isBlank()) {
        Toast.makeText(ctx, "Add a Gemini API key in Settings for Live mode", Toast.LENGTH_LONG).show()
        return
    }
    store.put("live_mode", "true")
    LiveAssistantService.start(ctx)
}

private fun openAssistantSettings(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 29) {
        val role = ctx.getSystemService(RoleManager::class.java)
        if (role?.isRoleAvailable(RoleManager.ROLE_ASSISTANT) == true) {
            runCatching { ctx.startActivity(role.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT)) }.onFailure { ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
            return
        }
    }
    runCatching { ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
}

private fun readAttachment(ctx: Context, uri: Uri): AiAttachment? = runCatching {
    val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
    val name = uri.lastPathSegment?.substringAfterLast('/') ?: "attachment"
    val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
    if (bytes.size > 10 * 1024 * 1024) return null
    AiAttachment(name, mime, bytes)
}.getOrNull()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(
    input: String, busy: Boolean, listening: Boolean, speaking: Boolean, liveMode: Boolean, orbState: OrbState,
    provider: String, model: String, models: List<ModelOption>, messages: List<Msg>, attachments: List<AiAttachment>, actionLabel: String?, showKeyboard: Boolean,
    onProvider: (String) -> Unit, onModel: (String) -> Unit, onInput: (String) -> Unit, onSuggestion: (String) -> Unit,
    onPickFiles: () -> Unit, onRemoveAttachment: (Int) -> Unit, onNewChat: () -> Unit, onSend: () -> Unit, onLive: () -> Unit,
    onHistory: () -> Unit, onSettings: () -> Unit, onKeyboard: () -> Unit, onSay: (String) -> Unit, onPickMic: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    var providerOpen by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }

    val selectedModel = models.firstOrNull { it.id == model }
    val hero = messages.isEmpty()

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.Menu, "Menu", Modifier.size(28.dp)) }
                Spacer(Modifier.width(8.dp))
                Box {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .clickable { providerOpen = true }
                            .padding(horizontal = 8.dp, vertical = 7.dp)
                    ) {
                        Text(
                            selectedModel?.label ?: "Leo",
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1
                        )
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Default.Tune, "Choose model", Modifier.size(18.dp))
                    }
                    DropdownMenu(providerOpen, { providerOpen = false }) {
                        providerModels.forEach { (p, options) ->
                            DropdownMenuItem(
                                text = { Text(p, fontWeight = FontWeight.SemiBold) },
                                onClick = { providerOpen = false; onProvider(p) }
                            )
                            options.forEach { option ->
                                DropdownMenuItem(
                                    text = { Text("  ${option.label}") },
                                    onClick = { providerOpen = false; onProvider(p); onModel(option.id) }
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Default.MoreVert, "More")
                }
            }

            DropdownMenu(menuOpen, { menuOpen = false }) {
                DropdownMenuItem(text = { Text("New chat") }, leadingIcon = { Icon(Icons.Default.AddComment, null) }, onClick = { menuOpen = false; onNewChat() })
                DropdownMenuItem(text = { Text("History") }, leadingIcon = { Icon(Icons.Default.History, null) }, onClick = { menuOpen = false; onHistory() })
                DropdownMenuItem(text = { Text("Settings") }, leadingIcon = { Icon(Icons.Default.Settings, null) }, onClick = { menuOpen = false; onSettings() })
            }

            if (liveMode) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 24.dp)) {
                        LargeOrb(orbState)
                        Spacer(Modifier.height(24.dp))
                        Text("Leo", fontSize = 30.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            when (orbState) {
                                OrbState.SPEAKING -> "Leo is speaking"
                                OrbState.THINKING -> "Thinking…"
                                OrbState.LISTENING -> "Listening…"
                                OrbState.IDLE -> "Live conversation"
                            },
                            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 15.sp
                        )
                    }
                }
                Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 34.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.size(58.dp)) {
                            IconButton(onClick = onPickMic) { Icon(if (listening) Icons.Default.Stop else Icons.Default.Mic, "Normal voice input") }
                        }
                        Spacer(Modifier.width(24.dp))
                        FilledIconButton(onClick = onLive, modifier = Modifier.size(70.dp), shape = CircleShape) {
                            Icon(Icons.Default.Stop, "End Live", Modifier.size(31.dp))
                        }
                    }
                }
            } else if (hero) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(bottom = 36.dp)) {
                        Icon(Icons.Default.AutoAwesome, "Leo", Modifier.size(62.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(20.dp))
                        Text("What’s next, Leo?", fontSize = 32.sp, fontWeight = FontWeight.Normal)
                        Spacer(Modifier.height(10.dp))
                        Text("Ask anything", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 16.sp)
                    }
                }
            } else {
                LazyColumn(state = listState, modifier = Modifier.fillMaxWidth().weight(1f), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    items(messages) { MessageBubble(it, onSay) }
                    if (actionLabel != null) item { AssistChip(onClick = {}, label = { Text(actionLabel) }) }
                }
            }

            if (!liveMode && showKeyboard) {
                if (attachments.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    attachments.forEachIndexed { i, a -> AssistChip(onClick = { onRemoveAttachment(i) }, label = { Text(a.name.take(18)) }) }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPickFiles) { Icon(Icons.Default.AttachFile, "Attach") }
                    OutlinedTextField(input, onInput, Modifier.weight(1f), placeholder = { Text("Ask Leo") }, maxLines = 4, shape = RoundedCornerShape(28.dp))
                    IconButton(onClick = onSend, enabled = input.isNotBlank() || attachments.isNotEmpty()) { Icon(Icons.Default.Add, "Send") }
                }
            }

            if (!liveMode) Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onKeyboard) { Icon(Icons.Default.Keyboard, "Keyboard") }
                        Spacer(Modifier.width(4.dp))
                        Surface(color = MaterialTheme.colorScheme.surfaceContainer, shape = RoundedCornerShape(30.dp), modifier = Modifier.weight(1f).height(58.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
                                IconButton(onClick = onPickFiles) { Icon(Icons.Default.Add, "Attach") }
                                Text(if (input.isBlank()) "Ask Leo" else input.take(34), color = if (input.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f), maxLines = 1)
                                IconButton(onClick = onPickMic) { Icon(if (listening) Icons.Default.Stop else Icons.Default.Mic, "Speak") }
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        FilledIconButton(onClick = onLive, modifier = Modifier.size(58.dp), shape = CircleShape) {
                            Icon(if (liveMode) Icons.Default.Stop else Icons.Default.AutoAwesome, if (liveMode) "Stop Live" else "Live", Modifier.size(27.dp))
                        }
                    }
                    if (liveMode) {
                        Spacer(Modifier.height(7.dp))
                        Text("Live • ${orbState.name.lowercase().replaceFirstChar { it.uppercase() }}", Modifier.align(Alignment.CenterHorizontally), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else if (busy || speaking) {
                        Spacer(Modifier.height(5.dp))
                        Text(if (busy) "Leo is thinking…" else "Leo is speaking…", Modifier.align(Alignment.CenterHorizontally), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun LargeOrb(state: OrbState) {
    val transition = rememberInfiniteTransition(label = "leoOrb")
    val pulse by transition.animateFloat(1f, if (state == OrbState.IDLE) 1.03f else 1.10f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse")
    val gradient = Brush.radialGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.background))
    Box(Modifier.size(150.dp * pulse).clip(CircleShape).background(gradient), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.AutoAwesome, "Leo", Modifier.size(82.dp), tint = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun MessageBubble(msg: Msg, onSay: (String) -> Unit) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (msg.user) Alignment.End else Alignment.Start) {
        if (msg.user) {
            Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = RoundedCornerShape(22.dp)) { Text(msg.text, Modifier.padding(horizontal = 15.dp, vertical = 11.dp), fontSize = 15.sp) }
        } else {
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.AutoAwesome, "Leo", Modifier.size(26.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(msg.text, fontSize = 16.sp, lineHeight = 24.sp)
                    IconButton(onClick = { onSay(msg.text) }, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.VolumeUp, "Speak", Modifier.size(18.dp)) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HistoryScreen(messages: List<Msg>, onBack: () -> Unit, onClear: () -> Unit) {
    Scaffold(topBar = { TopAppBar(navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }, title = { Text("History") }, actions = { IconButton(onClick = onClear) { Icon(Icons.Default.DeleteSweep, "Clear") } }) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (messages.isEmpty()) item { Text("No saved chats yet.") }
            items(messages) { m -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(15.dp)) { Text(if (m.user) "You" else "Leo", fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(m.text) } } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(
    openai: String, onOpenAi: (String) -> Unit, gemini: String, onGemini: (String) -> Unit,
    anthropic: String, onAnthropic: (String) -> Unit, groq: String, onGroq: (String) -> Unit,
    openrouter: String, onOpenRouter: (String) -> Unit,
    theme: ThemeMode, onTheme: (ThemeMode) -> Unit, dynamic: Boolean, onDynamic: (Boolean) -> Unit,
    font: LeoFont, onFont: (LeoFont) -> Unit, selectedVoice: String, voices: List<Voice>, onVoice: (String) -> Unit,
    onTestVoice: () -> Unit, onAssistant: () -> Unit, onClear: () -> Unit, onBack: () -> Unit
) {
    Scaffold(topBar = { TopAppBar(navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }, title = { Text("Settings") }) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { SettingsCard("API keys", Icons.Default.Settings) {
                Text("Keys stay encrypted on this device.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                KeyField("Gemini API key", gemini, onGemini); Spacer(Modifier.height(8.dp))
                KeyField("OpenAI API key", openai, onOpenAi); Spacer(Modifier.height(8.dp))
                KeyField("Anthropic API key", anthropic, onAnthropic); Spacer(Modifier.height(8.dp))
                KeyField("Groq API key", groq, onGroq); Spacer(Modifier.height(8.dp))
                KeyField("OpenRouter API key", openrouter, onOpenRouter)
            } }
            item { SettingsCard("Voice", Icons.Default.Mic) {
                Text("Normal voice input and Gemini Live are separate controls.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                VoiceSelector(selectedVoice, voices, onVoice)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onTestVoice, Modifier.fillMaxWidth()) { Icon(Icons.Default.VolumeUp, null); Spacer(Modifier.width(8.dp)); Text("Test voice") }
            } }
            item { SettingsCard("Appearance", Icons.Default.Settings) {
                Text("Theme", fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ThemeChip("System", theme == ThemeMode.SYSTEM) { onTheme(ThemeMode.SYSTEM) }
                    ThemeChip("Light", theme == ThemeMode.LIGHT) { onTheme(ThemeMode.LIGHT) }
                    ThemeChip("Dark", theme == ThemeMode.DARK) { onTheme(ThemeMode.DARK) }
                }
                Spacer(Modifier.height(10.dp)); SettingSwitch("Use device dynamic colors", dynamic, onDynamic)
                Spacer(Modifier.height(10.dp)); FontSelector(font, onFont)
            } }
            item { SettingsCard("Device assistant", Icons.Default.AutoAwesome) {
                Text("Let Leo appear as the Android digital assistant.", color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(8.dp))
                Button(onClick = onAssistant, Modifier.fillMaxWidth()) { Text("Set Leo as device assistant") }
            } }
            item { SettingsCard("Chat", Icons.Default.AddComment) {
                OutlinedButton(onClick = onClear, Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("New chat") }
            } }
            item { Text("Leo v5.0.0 • Gemini-style home redesign", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp)) }
        }
    }
}

@Composable
private fun SettingsCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer), shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(10.dp)); Text(title, fontWeight = FontWeight.SemiBold, fontSize = 18.sp) }
            Spacer(Modifier.height(13.dp)); content()
        }
    }
}

@Composable
private fun KeyField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), shape = RoundedCornerShape(18.dp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FontSelector(selected: LeoFont, onChange: (LeoFont) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val label = when (selected) { LeoFont.SYSTEM -> "System Default"; LeoFont.SANS -> "Sans"; LeoFont.SERIF -> "Serif"; LeoFont.MONO -> "Monospace"; LeoFont.CURSIVE -> "Cursive" }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(label, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Font") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, shape = RoundedCornerShape(18.dp))
        ExposedDropdownMenu(expanded, { expanded = false }) { LeoFont.values().forEach { f -> DropdownMenuItem(text = { Text(f.name.lowercase().replaceFirstChar { it.uppercase() }) }, onClick = { onChange(f); expanded = false }) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VoiceSelector(selected: String, voices: List<Voice>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val label = voices.firstOrNull { it.name == selected }?.let { "${it.locale.displayLanguage} · ${it.name}" } ?: if (selected.isBlank()) "System default" else selected
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(label, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Voice") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, shape = RoundedCornerShape(18.dp))
        ExposedDropdownMenu(expanded, { expanded = false }) {
            DropdownMenuItem(text = { Text("System default") }, onClick = { onChange(""); expanded = false })
            voices.take(60).forEach { v -> DropdownMenuItem(text = { Text("${v.locale.displayLanguage} · ${v.name}") }, onClick = { onChange(v.name); expanded = false }) }
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(checked, onChange) }
}

@Composable
private fun ThemeChip(label: String, selected: Boolean, onClick: () -> Unit) = FilterChip(selected, onClick, label = { Text(label) })
