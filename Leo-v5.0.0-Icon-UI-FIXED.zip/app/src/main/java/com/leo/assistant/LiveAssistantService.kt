package com.leo.assistant

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import android.util.Base64
import kotlin.math.max
import kotlin.math.sqrt
import java.util.concurrent.TimeUnit

class LiveAssistantService : Service() {
    companion object {
        const val ACTION_START = "com.leo.assistant.action.START_LIVE"
        const val ACTION_STOP = "com.leo.assistant.action.STOP_LIVE"
        const val ACTION_STATE = "com.leo.assistant.action.LIVE_STATE"
        const val ACTION_ORB_STATE = "com.leo.assistant.action.ORB_STATE"
        const val EXTRA_LIVE = "live"
        const val EXTRA_ORB_STATE = "orb_state"
        const val CHANNEL_ID = "leo_live"
        const val NOTIFICATION_ID = 2601

        fun start(context: Context) {
            val intent = Intent(context, LiveAssistantService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }

        fun stop(context: Context) {
            context.startService(Intent(context, LiveAssistantService::class.java).setAction(ACTION_STOP))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val httpClient = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).retryOnConnectionFailure(true).build()
    private var live = false
    private var socket: WebSocket? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var audioStarted = false
    private var retryAttempt = 0
    private var lastInput = 0L
    private var speakingJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startLive()
            ACTION_STOP -> stopLive()
        }
        return START_NOT_STICKY
    }

    private fun startLive() {
        if (live) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            notifyMissing("Microphone permission is required for Live mode")
            stopSelf()
            return
        }
        val key = SecureStore(this).get("gemini")
        if (key.isBlank()) {
            notifyMissing("Add a Gemini API key in Settings for Live mode")
            stopSelf()
            return
        }

        live = true
        retryAttempt = 0
        startAsForeground()
        sendState(true)
        sendOrb("listening")
        connect()
    }

    private fun startAsForeground() {
        val stopIntent = PendingIntent.getService(
            this, 2,
            Intent(this, LiveAssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getActivity(
            this, 3,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.leo_icon)
            .setContentTitle("Leo Live")
            .setContentText("Voice conversation is active")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Leo Live", NotificationManager.IMPORTANCE_LOW).apply {
                    setSound(null, null)
                    enableVibration(false)
                }
            )
        }
    }

    private fun notifyMissing(message: String) {
        val launch = PendingIntent.getActivity(
            this, 91,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        getSystemService(NotificationManager::class.java).notify(
            2604,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.leo_icon)
                .setContentTitle("Leo voice needs attention")
                .setContentText(message)
                .setContentIntent(launch)
                .setAutoCancel(true)
                .build()
        )
    }

    private fun connect() {
        if (!live) return
        val key = SecureStore(this).get("gemini")
        if (key.isBlank()) {
            notifyMissing("Add a Gemini API key in Settings for Live mode")
            stopLive()
            return
        }

        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" +
            java.net.URLEncoder.encode(key, "UTF-8")
        audioStarted = false

        socket = httpClient.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                retryAttempt = 0
                sendOrb("listening")
                val history = ChatStore(this@LiveAssistantService).load().takeLast(20).joinToString("\n") {
                    if (it.user) "User: ${it.text}" else "Leo: ${it.text}"
                }
                val instructions = buildString {
                    append(AiClient.SYSTEM_PROMPT)
                    if (history.isNotBlank()) append("\nRecent conversation context:\n$history")
                }
                val setup = JSONObject().put("setup", JSONObject()
                    .put("model", "models/gemini-3.8-live")
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instructions))))
                    .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO")))
                    .put("inputAudioTranscription", JSONObject())
                    .put("outputAudioTranscription", JSONObject())
                )
                if (!ws.send(setup.toString())) scheduleReconnect("Live setup could not be sent")
            }

            override fun onMessage(ws: WebSocket, text: String) = handleServer(ws, text)

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                scheduleReconnect("Live connection failed: ${t.message ?: "network error"}")
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                if (live) scheduleReconnect("Live connection closed")
            }
        })
    }

    private fun scheduleReconnect(reason: String) {
        if (!live) return
        val attempt = retryAttempt++
        if (attempt >= 4) {
            notifyMissing("$reason. Please tap Live again.")
            stopLive()
            return
        }
        val delayMs = 800L shl attempt
        sendOrb("thinking")
        scope.launch {
            delay(delayMs)
            if (live) connect()
        }
    }

    private fun startAudio(ws: WebSocket) {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufferSize = max(min, 1280)
        val buffer = ByteArray(bufferSize)
        val audio = AudioRecord(
            MediaRecorder.AudioSource.MIC, 16000,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            bufferSize * 2
        )
        if (audio.state != AudioRecord.STATE_INITIALIZED) {
            audio.release()
            notifyMissing("Android could not open the microphone for Live mode")
            stopLive()
            return
        }
        recorder = audio
        runCatching { audio.startRecording() }.onFailure {
            notifyMissing("Android could not start the microphone for Live mode")
            stopLive()
            return
        }

        sendOrb("listening")
        scope.launch {
            while (live && recorder === audio && ws === socket) {
                val count = runCatching { audio.read(buffer, 0, buffer.size) }.getOrDefault(-1)
                if (count <= 0) continue
                var sum = 0.0
                var samples = 0
                var i = 0
                while (i + 1 < count) {
                    val lo = buffer[i].toInt() and 0xff
                    val hi = buffer[i + 1].toInt()
                    val sample = ((hi shl 8) or lo).toShort().toInt()
                    sum += sample.toDouble() * sample.toDouble()
                    samples++
                    i += 2
                }
                val rms = sqrt((sum / samples.coerceAtLeast(1)).coerceAtLeast(1.0))
                if (rms > 900) {
                    lastInput = System.currentTimeMillis()
                    player?.pause()
                    player?.flush()
                    sendOrb("listening")
                }
                val data = Base64.encodeToString(buffer.copyOf(count), Base64.NO_WRAP)
                val sent = ws.send(JSONObject().put("realtimeInput", JSONObject().put(
                    "audio", JSONObject().put("data", data).put("mimeType", "audio/pcm;rate=16000")
                )).toString())
                if (!sent) break
            }
        }
    }

    private fun handleServer(ws: WebSocket, raw: String) {
        runCatching {
            val root = JSONObject(raw)
            if (root.optJSONObject("setupComplete") != null) {
                if (!audioStarted) {
                    audioStarted = true
                    startAudio(ws)
                }
                return
            }
            val server = root.optJSONObject("serverContent") ?: return
            if (server.optBoolean("interrupted", false)) {
                player?.pause(); player?.flush(); sendOrb("listening"); return
            }
            val parts = server.optJSONObject("modelTurn")?.optJSONArray("parts")
            if (parts == null) {
                if (server.optBoolean("turnComplete", false)) sendOrb("listening")
                return
            }
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                val inline = part.optJSONObject("inlineData") ?: continue
                val data = inline.optString("data")
                if (data.isNotBlank()) playAudio(Base64.decode(data, Base64.DEFAULT))
            }
        }
    }

    private fun playAudio(data: ByteArray) {
        if (!live || System.currentTimeMillis() - lastInput < 700) return
        if (player == null) {
            val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            player = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(min, data.size * 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            player?.play()
        }
        player?.write(data, 0, data.size)
        sendOrb("speaking")
        speakingJob?.cancel()
        speakingJob = scope.launch {
            delay(500)
            if (live) sendOrb("listening")
        }
    }

    private fun sendState(on: Boolean) = sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra(EXTRA_LIVE, on))
    private fun sendOrb(state: String) = sendBroadcast(Intent(ACTION_ORB_STATE).setPackage(packageName).putExtra(EXTRA_ORB_STATE, state))

    private fun stopLive() {
        live = false
        speakingJob?.cancel()
        runCatching { recorder?.stop() }
        recorder?.release(); recorder = null
        socket?.close(1000, "stopped"); socket = null
        runCatching { player?.stop() }
        player?.release(); player = null
        sendState(false)
        sendOrb("idle")
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopLive()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
