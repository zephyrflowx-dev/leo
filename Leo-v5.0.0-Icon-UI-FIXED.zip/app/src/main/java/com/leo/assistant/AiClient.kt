package com.leo.assistant

import android.util.Base64
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject

data class AiAttachment(val name: String, val mime: String, val bytes: ByteArray)

class AiClient {
    companion object {
        const val SYSTEM_PROMPT = """You are Leo, a concise, friendly personal AI assistant on Android.
Speak naturally and directly. For ordinary voice replies, prefer 1–3 short sentences unless the user asks for detail.
Do not use markdown headings or long lists when the reply will be spoken aloud.
If the user asks for an action on the phone, explain what should happen clearly; the Android app handles permissions and final confirmation for sensitive actions.
"""
    }

    fun ask(
        provider: String,
        key: String,
        model: String,
        message: String,
        attachments: List<AiAttachment> = emptyList(),
        history: List<Msg> = emptyList()
    ): String {
        if (key.isBlank()) return "Add your $provider API key in Settings."
        return try {
            when (provider) {
                "OpenAI" -> openAi(key, model, message, attachments, history)
                "Anthropic" -> anthropic(key, model, message, attachments, history)
                "Groq" -> groq(key, model, message, history)
                "OpenRouter" -> openRouter(key, model, message, attachments, history)
                else -> gemini(key, model, message, attachments, history)
            }
        } catch (e: Exception) { "Leo couldn't reach $provider: ${e.message ?: "network error"}" }
    }
    private fun post(url:String, headers:Map<String,String>, body:String):Pair<Int,String>{
        val c=URL(url).openConnection() as HttpURLConnection
        c.requestMethod="POST"; c.doOutput=true; c.connectTimeout=20000; c.readTimeout=60000
        headers.forEach{(k,v)->c.setRequestProperty(k,v)}
        c.outputStream.use{it.write(body.toByteArray(Charsets.UTF_8))}
        val code=c.responseCode; val r=if(code in 200..299)c.inputStream else c.errorStream
        return code to (r?.bufferedReader()?.use{it.readText()} ?: "")
    }
    private fun openAi(key:String,model:String,msg:String,a:List<AiAttachment>,history:List<Msg>):String{
        val content=JSONArray().put(JSONObject().put("type","text").put("text",msg))
        a.filter{it.mime.startsWith("image/")}.forEach{att->
            content.put(JSONObject().put("type","image_url").put("image_url",JSONObject().put("url","data:${att.mime};base64,${Base64.encodeToString(att.bytes,Base64.NO_WRAP)}")))
        }
        val textFiles=a.filter{!it.mime.startsWith("image/")}.mapNotNull{att->att.bytes.toString(Charsets.UTF_8).takeIf{it.isNotBlank()}?.let{"\n\nFile ${att.name}:\n$it"}}.joinToString("")
        if(textFiles.isNotBlank()) content.getJSONObject(0).put("text",msg+textFiles)
        val msgs = JSONArray().put(JSONObject().put("role","system").put("content",SYSTEM_PROMPT))
        history.takeLast(20).forEach { m ->
            msgs.put(JSONObject().put("role", if (m.user) "user" else "assistant").put("content", m.text))
        }
        msgs.put(JSONObject().put("role","user").put("content",content))
        val b=JSONObject().put("model",model).put("messages",msgs)
        val(code,s)=post("https://api.openai.com/v1/chat/completions",mapOf("Authorization" to "Bearer $key","Content-Type" to "application/json"),b.toString())
        if(code !in 200..299)return openAiError(code,s)
        return JSONObject(s).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
    private fun gemini(key:String,model:String,msg:String,a:List<AiAttachment>,history:List<Msg>):String{
        val parts=JSONArray().put(JSONObject().put("text",msg))
        a.forEach{att->parts.put(JSONObject().put("inlineData",JSONObject().put("mimeType",att.mime).put("data",Base64.encodeToString(att.bytes,Base64.NO_WRAP))))}
        val contents = JSONArray()
        history.takeLast(20).forEach { m ->
            contents.put(JSONObject().put("role", if (m.user) "user" else "model").put("parts", JSONArray().put(JSONObject().put("text", m.text))))
        }
        contents.put(JSONObject().put("role","user").put("parts",parts))
        val b=JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
            .put("contents",contents)
        val(code,s)=post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",mapOf("Content-Type" to "application/json","x-goog-api-key" to key),b.toString())
        if(code !in 200..299)return geminiError(code,s)
        return JSONObject(s).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }
    private fun anthropic(key:String,model:String,msg:String,a:List<AiAttachment>,history:List<Msg>):String{
        val content=JSONArray().put(JSONObject().put("type","text").put("text",msg))
        a.filter{it.mime.startsWith("image/")}.forEach{att->content.put(JSONObject().put("type","image").put("source",JSONObject().put("type","base64").put("media_type",att.mime).put("data",Base64.encodeToString(att.bytes,Base64.NO_WRAP))))}
        val textFiles=a.filter{!it.mime.startsWith("image/")}.mapNotNull{att->att.bytes.toString(Charsets.UTF_8).takeIf{it.isNotBlank()}?.let{"\n\nFile ${att.name}:\n$it"}}.joinToString("")
        if(textFiles.isNotBlank()) content.getJSONObject(0).put("text",msg+textFiles)
        val msgs = JSONArray()
        history.takeLast(20).forEach { m ->
            msgs.put(JSONObject().put("role", if (m.user) "user" else "assistant").put("content", m.text))
        }
        msgs.put(JSONObject().put("role","user").put("content",content))
        val b=JSONObject().put("model",model).put("max_tokens",2048).put("system",SYSTEM_PROMPT).put("messages",msgs)
        val(code,s)=post("https://api.anthropic.com/v1/messages",mapOf("Content-Type" to "application/json","x-api-key" to key,"anthropic-version" to "2023-06-01"),b.toString())
        if(code !in 200..299)return anthropicError(code,s)
        val c=JSONObject(s).optJSONArray("content")?:return "Anthropic returned an empty response."
        for(i in 0 until c.length()){val x=c.optJSONObject(i)?:continue;if(x.optString("type")=="text")return x.optString("text")}
        return "Anthropic returned an empty response."
    }

    private fun groq(key:String,model:String,msg:String,history:List<Msg>):String{
        val msgs = JSONArray().put(JSONObject().put("role","system").put("content",SYSTEM_PROMPT))
        history.takeLast(20).forEach { m ->
            msgs.put(JSONObject().put("role", if (m.user) "user" else "assistant").put("content", m.text))
        }
        msgs.put(JSONObject().put("role","user").put("content",msg))
        val b=JSONObject().put("model",model).put("messages",msgs)
        val(code,s)=post("https://api.groq.com/openai/v1/chat/completions",mapOf("Content-Type" to "application/json","Authorization" to "Bearer $key"),b.toString())
        if(code !in 200..299)return error("Groq",code,s)
        return JSONObject(s).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }

    private fun openRouter(key:String,model:String,msg:String,a:List<AiAttachment>,history:List<Msg>):String{
        val content=JSONArray().put(JSONObject().put("type","text").put("text",msg))
        a.filter{it.mime.startsWith("image/")}.forEach{att->
            content.put(JSONObject().put("type","image_url").put("image_url",JSONObject().put("url","data:${att.mime};base64,${Base64.encodeToString(att.bytes,Base64.NO_WRAP)}")))
        }
        val msgs = JSONArray().put(JSONObject().put("role","system").put("content",SYSTEM_PROMPT))
        history.takeLast(20).forEach { m ->
            msgs.put(JSONObject().put("role", if (m.user) "user" else "assistant").put("content", m.text))
        }
        msgs.put(JSONObject().put("role","user").put("content",content))
        val b=JSONObject().put("model",model).put("messages",msgs)
        val(code,s)=post("https://openrouter.ai/api/v1/chat/completions",mapOf("Content-Type" to "application/json","Authorization" to "Bearer $key","X-Title" to "Leo Android Assistant"),b.toString())
        if(code !in 200..299)return error("OpenRouter",code,s)
        return JSONObject(s).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content").ifBlank { "OpenRouter returned an empty response." }
    }
    private fun openAiError(code:Int,body:String)=error("OpenAI",code,body)
    private fun geminiError(code:Int,body:String)=error("Gemini",code,body)
    private fun anthropicError(code:Int,body:String)=error("Anthropic",code,body)
    private fun error(name:String,code:Int,body:String):String{val d=runCatching{JSONObject(body).optJSONObject("error")?.optString("message").takeUnless{it.isNullOrBlank()} ?: JSONObject(body).optString("message")}.getOrDefault("");return if(d.isNotBlank()) "$name error $code: $d" else "$name error $code"}
}
