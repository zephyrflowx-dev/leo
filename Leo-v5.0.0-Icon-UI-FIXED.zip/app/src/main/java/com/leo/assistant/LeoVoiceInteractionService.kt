package com.leo.assistant

import android.service.voice.VoiceInteractionService

/**
 * Leo's Android system-assistant entry point.
 * Wake-word listening was intentionally removed in v5.0.0.
 */
class LeoVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
    }
}
