package com.leo.assistant

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import java.util.Locale

class LiveAssistantService : Service() {
    companion object {
        const val ACTION_START = "com.leo.assistant.action.START_LIVE"
        const val ACTION_STOP = "com.leo.assistant.action.STOP_LIVE"
        const val ACTION_STATE = "com.leo.assistant.action.LIVE_STATE"
        const val EXTRA_LIVE = "live"
        const val CHANNEL_ID = "leo_live"
        const val NOTIFICATION_ID = 2601

        fun start(context: Context) {
            val i = Intent(context, LiveAssistantService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
        fun stop(context: Context) {
            context.startService(Intent(context, LiveAssistantService::class.java).setAction(ACTION_STOP))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var overlay: View? = null
    private var windowManager: WindowManager? = null
    private var live = false
    private var processing = false
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startLive()
            ACTION_STOP -> stopLive()
        }
        return START_NOT_STICKY
    }

    private fun startLive() {
        if (live) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission is required for Live mode.", Toast.LENGTH_SHORT).show()
            stopSelf(); return
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow Leo to display over other apps for the Live icon.", Toast.LENGTH_LONG).show()
            stopSelf(); return
        }
        live = true
        startAsForeground()
        showOverlay()
        broadcastState(true)
        startListening()
    }

    private fun startAsForeground() {
        val stopIntent = PendingIntent.getService(this, 2, Intent(this, LiveAssistantService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.leo_icon)
            .setContentTitle("Leo Live is on")
            .setContentText("Leo is listening. Tap the Leo icon or Stop to turn Live off.")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, "Stop Live", stopIntent)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Leo Live", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Persistent notification while Leo Live uses the microphone"
                setSound(null, null)
                enableVibration(false)
            })
        }
    }

    private fun showOverlay() {
        if (overlay != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val button = ImageButton(this).apply {
            setImageResource(R.drawable.leo_icon)
            background = null
            contentDescription = "Leo Live. Tap to stop."
            setPadding(4, 4, 4, 4)
            setOnClickListener { stopLive() }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(58, 58, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = 18
            y = 120
        }
        windowManager?.addView(button, lp)
        overlay = button
    }

    private fun hideOverlay() {
        overlay?.let { runCatching { windowManager?.removeView(it) } }
        overlay = null
        windowManager = null
    }

    private fun startListening() {
        if (!live || processing || restarting) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer?.cancel(); recognizer?.destroy()
        val r = if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        } else {
            SpeechRecognizer.createSpeechRecognizer(this)
        }
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
            override fun onError(error: Int) {
                recognizer?.destroy(); recognizer = null
                if (live && error != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) restartListeningSoon()
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                recognizer?.destroy(); recognizer = null
                val cleaned = cleanWakePhrase(text)
                if (cleaned.isNotBlank() && live) handleSpeech(cleaned) else restartListeningSoon()
            }
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        })
    }

    private fun cleanWakePhrase(text: String): String {
        return text.replaceFirst(Regex("""^\s*(hey\s+leo|hey\s+lio|hey\s+leah|hey\s+lia|hey\s+leon|hello\s+leo|hello\s+lio|halo\s+leo|helio)\s*[,.:;-]?\s*""", RegexOption.IGNORE_CASE), "").trim()
    }

    private fun restartListeningSoon() {
        if (!live || restarting) return
        restarting = true
        scope.launch {
            delay(350)
            restarting = false
            startListening()
        }
    }

    private fun handleSpeech(text: String) {
        if (processing) { restartListeningSoon(); return }
        processing = true
        scope.launch {
            val store = SecureStore(this@LiveAssistantService)
            val provider = store.get("provider").ifBlank { "Gemini" }
            val key = when (provider) { "OpenAI" -> store.get("openai"); "Anthropic" -> store.get("anthropic"); else -> store.get("gemini") }
            val reply = withContext(Dispatchers.IO) {
                if (text.lowercase(Locale.getDefault()).startsWith("open ")) AppActions.openApp(this@LiveAssistantService, text.substringAfter(" ").trim())
                else AiClient().ask(provider, key, text)
            }
            ChatStore(this@LiveAssistantService).let { chat ->
                val history = chat.load().toMutableList()
                history.add(Msg(text, true)); history.add(Msg(reply, false)); chat.save(history)
            }
            tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "leo-live")
            processing = false
            if (live) restartListeningSoon()
        }
    }

    private fun broadcastState(on: Boolean) {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra(EXTRA_LIVE, on))
    }

    private fun stopLive() {
        if (!live && overlay == null) { stopSelf(); return }
        live = false
        recognizer?.cancel(); recognizer?.destroy(); recognizer = null
        hideOverlay()
        broadcastState(false)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        live = false
        recognizer?.destroy(); recognizer = null
        hideOverlay()
        tts?.stop(); tts?.shutdown(); tts = null
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
