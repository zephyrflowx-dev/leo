package com.leo.assistant

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale
import kotlin.math.sqrt

/**
 * Two-stage wake listener.
 *
 * Stage 1 is a local acoustic gate using AudioRecord/RMS only. It does not
 * convert continuous audio to text and never sends wake-listening audio to an
 * AI provider. When speech energy is detected, Stage 2 briefly invokes the
 * device speech recognizer to validate the wake phrase. A real OEM/DSP hotword
 * detector, when exposed by the device, should replace Stage 1 in a future
 * device-specific implementation.
 */
class LeoHotwordService : Service() {
    companion object {
        private const val ACTION_START = "com.leo.assistant.action.START_HOTWORD"
        private const val ACTION_STOP = "com.leo.assistant.action.STOP_HOTWORD"
        private const val CHANNEL_ID = "leo_hotword"
        private const val NOTIFICATION_ID = 2602
        private const val SAMPLE_RATE = 16_000
        private const val FRAME_MS = 100
        private const val FRAME_SAMPLES = SAMPLE_RATE * FRAME_MS / 1000
        private const val SPEECH_THRESHOLD = 0.018
        private const val REQUIRED_SPEECH_FRAMES = 2

        fun start(context: Context) {
            val intent = Intent(context, LeoHotwordService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }
        fun stop(context: Context) { context.stopService(Intent(context, LeoHotwordService::class.java)) }
    }

    private val main = Handler(Looper.getMainLooper())
    private var running = false
    private var acousticThread: Thread? = null
    private var recorder: AudioRecord? = null
    private var recognizer: SpeechRecognizer? = null
    private var restartPending = false
    private var speechFrames = 0

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startHotword()
            ACTION_STOP -> stopHotword()
        }
        return START_STICKY
    }

    private fun startHotword() {
        if (running) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }
        running = true
        startForegroundNotification()
        startAcousticGate()
    }

    private fun startForegroundNotification() {
        val launch = PendingIntent.getActivity(
            this, 2602,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 2603,
            Intent(this, LeoHotwordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.leo_icon)
            .setContentTitle("Leo wake word is on")
            .setContentText("Listening locally for Hey Leo")
            .setContentIntent(launch)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Leo wake word", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Visible notification while Hey Leo listening is enabled"
                    setSound(null, null)
                    enableVibration(false)
                }
            )
        }
    }

    /** Stage 1: cheap local acoustic speech gate. */
    private fun startAcousticGate() {
        acousticThread?.interrupt()
        acousticThread = Thread {
            val minBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuffer <= 0) {
                main.post { startSpeechValidation() }
                return@Thread
            }
            val bufferSize = maxOf(minBuffer, FRAME_SAMPLES * 2)
            val local = runCatching {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
            }.getOrNull()
            if (local == null || local.state != AudioRecord.STATE_INITIALIZED) {
                local?.release()
                main.post { startSpeechValidation() }
                return@Thread
            }
            recorder = local
            val samples = ShortArray(FRAME_SAMPLES)
            try {
                local.startRecording()
                while (running && !Thread.currentThread().isInterrupted) {
                    val read = local.read(samples, 0, samples.size, AudioRecord.READ_BLOCKING)
                    if (read <= 0) continue
                    val rms = rms(samples, read)
                    if (rms >= SPEECH_THRESHOLD) {
                        speechFrames++
                    } else {
                        speechFrames = 0
                    }
                    if (speechFrames >= REQUIRED_SPEECH_FRAMES) {
                        speechFrames = 0
                        main.post { startSpeechValidation() }
                        // Pause the acoustic gate while Stage 2 owns the microphone.
                        break
                    }
                }
            } finally {
                runCatching { local.stop() }
                local.release()
                if (recorder === local) recorder = null
            }
        }.apply { name = "LeoLocalWakeGate"; isDaemon = true }
        acousticThread?.start()
    }

    private fun rms(samples: ShortArray, count: Int): Double {
        var sum = 0.0
        for (i in 0 until count) {
            val v = samples[i].toDouble() / 32768.0
            sum += v * v
        }
        return sqrt(sum / count.coerceAtLeast(1))
    }

    /** Stage 2: short-lived speech recognition used only after local speech activity. */
    private fun startSpeechValidation() {
        if (!running || recognizer != null) return
        recognizer = newRecognizer()
        val r = recognizer ?: run { scheduleWakeRestart(); return }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
            override fun onError(error: Int) { finishValidation(null) }
            override fun onResults(results: Bundle?) {
                val raw = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                finishValidation(raw)
            }
        })
        r.startListening(recognitionIntent())
    }

    private fun finishValidation(raw: String?) {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        val command = raw?.let(::stripWakePhrase)
        if (command != null) {
            if (command.isBlank()) startCommandRecognition() else deliverCommand(command)
        } else {
            scheduleWakeRestart()
        }
    }

    private fun startCommandRecognition() {
        if (!running || recognizer != null) return
        recognizer = newRecognizer()
        val r = recognizer ?: run { scheduleWakeRestart(); return }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
            override fun onError(error: Int) { finishCommand(null) }
            override fun onResults(results: Bundle?) {
                finishCommand(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim())
            }
        })
        r.startListening(recognitionIntent())
    }

    private fun finishCommand(text: String?) {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        if (!text.isNullOrBlank()) deliverCommand(text) else scheduleWakeRestart()
    }

    private fun newRecognizer(): SpeechRecognizer? {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return null
        return if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        } else {
            SpeechRecognizer.createSpeechRecognizer(this)
        }
    }

    private fun recognitionIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
    }

    private fun stripWakePhrase(text: String): String? {
        val normalized = text.lowercase(Locale.getDefault()).trim()
            .replace(Regex("[.,!?;:]+"), " ")
            .replace(Regex("\\s+"), " ")
        val pattern = Regex(
            "^(?:hey\\s+(?:leo|lio|leah|lia|leon)|hello\\s+(?:leo|lio)|halo\\s+leo|helio)(?:\\s+(.*))?$",
            RegexOption.IGNORE_CASE
        )
        return pattern.matchEntire(normalized)?.groupValues?.getOrNull(1)?.trim().orEmpty()
            .takeIf { pattern.matches(normalized) }
    }

    private fun deliverCommand(text: String) {
        if (!running) return
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        runCatching {
            startActivity(
                Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("voice_command", text)
                }
            )
        }
        scheduleWakeRestart()
    }

    private fun scheduleWakeRestart() {
        if (!running || restartPending) return
        restartPending = true
        main.postDelayed({
            restartPending = false
            if (running) startAcousticGate()
        }, 500)
    }

    private fun stopHotword() {
        running = false
        restartPending = false
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        acousticThread?.interrupt()
        acousticThread = null
        recorder?.let { runCatching { it.stop() }; it.release() }
        recorder = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        acousticThread?.interrupt()
        recognizer?.destroy()
        recorder?.let { runCatching { it.stop() }; it.release() }
        recognizer = null
        recorder = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
