# Leo v2.6.1

Fixed OpenAI/Anthropic provider handling, speech wake-phrase cleanup, and automatic chat scrolling. Normal replies are not spoken automatically; use the reply speaker button. Live mode remains a separate opt-in microphone mode.


## v2.6.3 wake engine
- Two-stage wake architecture: local AudioRecord acoustic speech gate followed by short speech recognition validation.
- Continuous wake-listening audio is not sent to an AI provider.
- On-device speech recognition is preferred when supported.
- Wake phrase is validated before a command is delivered.
- This is an app-level approximation of a DSP wake pipeline; it does not claim privileged OEM DSP hotword access.
