# Leo v2.5.1

Leo is a personal Android AI assistant.

## v2.5.1 changes
- Removed Local GGUF/llama.cpp completely.
- Gemini and OpenAI remain as AI providers.
- Corrected VoiceInteractionService registration and metadata for Android's assistant role.
- Added the RecognitionService metadata and DEFAULT category required by Android recognition-service discovery.
- Added MainActivity as Leo's assistant settings activity.
- Kept automatic voice-to-send behavior in the Leo UI.
- Kept calling, app opening, chat history, fonts, themes, TTS voice selection, and API-key storage.

Android still controls assistant eligibility and hotword behavior on each device. The selected VoiceInteractionService is the system component used for global voice interaction and hotword support.
