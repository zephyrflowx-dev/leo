# Leo v1.5.0

Personal Android AI assistant.

## v1.5 fixes
- Gemini now uses `gemini-3.5-flash-lite` instead of the old `gemini-2.0-flash` endpoint.
- Gemini API key is sent with the `x-goog-api-key` header.
- Clear 401/403/404/429 messages for Gemini and OpenAI.
- API keys remain encrypted locally on the device and are not included in this project.
- Existing voice input, TTS, app opening, web search, contacts/calling, and provider switching are retained.
