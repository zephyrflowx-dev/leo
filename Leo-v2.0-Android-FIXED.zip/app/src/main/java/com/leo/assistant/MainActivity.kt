package com.leo.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

data class Msg(val text: String, val user: Boolean)
enum class ThemeMode { SYSTEM, LIGHT, DARK }

class MainActivity : ComponentActivity() {
    private var incomingVoice by mutableStateOf("")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        incomingVoice = intent?.getStringExtra("voice_command") ?: ""
        setContent { LeoApp(incomingVoice) { incomingVoice = "" } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        incomingVoice = intent.getStringExtra("voice_command") ?: ""
    }
}

@Composable
fun LeoTheme(mode: ThemeMode, dynamicColor: Boolean, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current
    val colors = if (dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else if (dark) {
        darkColorScheme(
            primary = Color(0xFFE8E8E8), onPrimary = Color(0xFF111111),
            primaryContainer = Color(0xFF303030), onPrimaryContainer = Color(0xFFF2F2F2),
            surface = Color(0xFF101010), surfaceContainer = Color(0xFF1B1B1B), background = Color(0xFF0B0B0B)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF111111), onPrimary = Color.White,
            primaryContainer = Color(0xFFE9E9E9), onPrimaryContainer = Color(0xFF111111),
            surface = Color(0xFFF9F9F9), surfaceContainer = Color.White, background = Color(0xFFF6F6F6)
        )
    }
    MaterialTheme(colorScheme = colors, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeoApp(incomingVoice: String, onVoiceConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { SecureStore(ctx) }
    val chatStore = remember { ChatStore(ctx) }
    val scope = rememberCoroutineScope()
    var provider by remember { mutableStateOf(store.get("provider").ifBlank { "Gemini" }) }
    var openai by remember { mutableStateOf(store.get("openai")) }
    var gemini by remember { mutableStateOf(store.get("gemini")) }
    var input by remember { mutableStateOf("") }
    var screen by remember { mutableStateOf("home") }
    var busy by remember { mutableStateOf(false) }
    var themeMode by remember { mutableStateOf(runCatching { ThemeMode.valueOf(store.get("theme").ifBlank { "SYSTEM" }) }.getOrDefault(ThemeMode.SYSTEM)) }
    var dynamicColor by remember { mutableStateOf(store.get("dynamic_color") != "false") }
    var voiceReplies by remember { mutableStateOf(store.get("voice_replies") != "false") }
    var wakeWord by remember { mutableStateOf(store.get("wake_word") == "true") }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    val messages = remember { mutableStateListOf<Msg>().apply { addAll(chatStore.load()) } }

    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(ctx) { status -> if (status == TextToSpeech.SUCCESS) engine?.language = Locale.getDefault() }
        tts = engine
        onDispose { engine?.stop(); engine?.shutdown(); tts = null }
    }

    fun saveChat() = chatStore.save(messages)

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) input = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: ""
    }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to Leo")
        })
    }
    val contacts = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val call = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val overlayLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (wakeWord && Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(ctx)) startWakeService(ctx)
    }
    val audioPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(ctx)) {
                overlayLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            } else startWakeService(ctx)
        } else Toast.makeText(ctx, "Microphone permission is needed for Hey Leo.", Toast.LENGTH_SHORT).show()
    }

    fun setWake(enabled: Boolean) {
        wakeWord = enabled
        store.put("wake_word", enabled.toString())
        if (enabled) {
            if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                audioPermission.launch(Manifest.permission.RECORD_AUDIO)
            } else if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(ctx)) {
                overlayLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            } else startWakeService(ctx)
        } else stopWakeService(ctx)
    }

    fun send(textOverride: String? = null) {
        val text = (textOverride ?: input).trim()
        if (text.isEmpty() || busy) return
        messages.add(Msg(text, true)); saveChat(); input = ""; busy = true
        scope.launch {
            val action = handleCommand(ctx, text)
            val reply = when (action) {
                is CommandResult.Done -> action.text
                is CommandResult.NeedContacts -> { if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) contacts.launch(Manifest.permission.READ_CONTACTS); "I need contact permission to find that person." }
                is CommandResult.NeedCall -> { if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) call.launch(Manifest.permission.CALL_PHONE); "I need phone permission before placing the call." }
                CommandResult.None -> withContext(Dispatchers.IO) { AiClient().ask(provider, if (provider == "OpenAI") openai else gemini, text) }
            }
            messages.add(Msg(reply, false)); saveChat()
            if (voiceReplies) tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "leo")
            busy = false
        }
    }

    LaunchedEffect(incomingVoice) {
        if (incomingVoice.isNotBlank()) {
            screen = "home"
            send(incomingVoice)
            onVoiceConsumed()
        }
    }

    LeoTheme(themeMode, dynamicColor) {
        when (screen) {
            "settings" -> SettingsScreen(
                provider, { provider = it; store.put("provider", it) }, openai, { openai = it; store.put("openai", it) },
                gemini, { gemini = it; store.put("gemini", it) }, themeMode, { themeMode = it; store.put("theme", it.name) },
                dynamicColor, { dynamicColor = it; store.put("dynamic_color", it.toString()) }, voiceReplies,
                { voiceReplies = it; store.put("voice_replies", it.toString()) }, wakeWord, ::setWake,
                { messages.clear(); chatStore.clear(); messages.add(Msg("Chat cleared. Hi! I'm Leo — ready when you are.", false)); saveChat() },
                { screen = "home" }
            )
            "history" -> HistoryScreen(messages, { screen = "home" }, { messages.clear(); chatStore.clear(); messages.add(Msg("Hi! I'm Leo. Ask me anything, or try \"open YouTube\".", false)); saveChat() })
            else -> HomeScreen(provider, messages, input, { input = it }, busy, { send() },
                { if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) mic.launch(Manifest.permission.RECORD_AUDIO) else mic.launch(Manifest.permission.RECORD_AUDIO) },
                { screen = "history" }, { screen = "settings" })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(provider: String, messages: List<Msg>, input: String, onInput: (String) -> Unit, busy: Boolean, onSend: () -> Unit, onMic: () -> Unit, onHistory: () -> Unit, onSettings: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.leo_icon), "Leo", Modifier.size(42.dp).clip(CircleShape), ContentScale.Crop)
                Spacer(Modifier.width(10.dp)); Column { Text("Leo", fontWeight = FontWeight.Bold); Text("Your own AI", style = MaterialTheme.typography.labelSmall) }
            }
        }, actions = {
            IconButton(onClick = onHistory) { Icon(Icons.Default.History, "Chat history") }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings") }
        })
    }, bottomBar = {
        Surface(shadowElevation = 8.dp) {
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onMic) { Icon(Icons.Default.Mic, "Voice") }
                OutlinedTextField(input, onInput, Modifier.weight(1f), placeholder = { Text("Ask Leo...") }, singleLine = true, shape = RoundedCornerShape(24.dp))
                Spacer(Modifier.width(4.dp)); FilledIconButton(onClick = onSend, enabled = !busy) { Icon(Icons.Default.Send, "Send") }
            }
        }
    }) { p ->
        Column(Modifier.fillMaxSize().padding(p).padding(horizontal = 14.dp, vertical = 10.dp)) {
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Hello", fontWeight = FontWeight.Medium); Spacer(Modifier.height(4.dp)); Text("What can I help with?", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp)); AssistChip(onClick = {}, label = { Text(provider) })
                }
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 8.dp)) {
                items(messages) { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.user) Arrangement.End else Arrangement.Start) {
                        Surface(shape = RoundedCornerShape(20.dp), color = if (m.user) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainer, contentColor = if (m.user) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface) { Text(m.text, Modifier.padding(15.dp)) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HistoryScreen(messages: List<Msg>, onBack: () -> Unit, onClear: () -> Unit) {
    Scaffold(topBar = { TopAppBar(navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }, title = { Text("Chat history", fontWeight = FontWeight.Bold) }, actions = { IconButton(onClick = onClear) { Icon(Icons.Default.DeleteSweep, "Clear history") } }) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (messages.isEmpty()) item { Text("No saved chats yet.") }
            items(messages) { m ->
                Card(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp)) { Column(Modifier.padding(14.dp)) { Text(if (m.user) "You" else "Leo", fontWeight = FontWeight.Bold); Spacer(Modifier.height(3.dp)); Text(m.text) } }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(
    provider: String, onProviderChange: (String) -> Unit, openai: String, onOpenAiChange: (String) -> Unit, gemini: String, onGeminiChange: (String) -> Unit,
    themeMode: ThemeMode, onThemeChange: (ThemeMode) -> Unit, dynamicColor: Boolean, onDynamicColorChange: (Boolean) -> Unit,
    voiceReplies: Boolean, onVoiceRepliesChange: (Boolean) -> Unit, wakeWord: Boolean, onWakeWordChange: (Boolean) -> Unit,
    onClearChat: () -> Unit, onBack: () -> Unit
) {
    Scaffold(topBar = { TopAppBar(navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }, title = { Text("Settings", fontWeight = FontWeight.Bold) }) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { SettingsSection("Appearance", Icons.Default.Palette) { Text("Theme", fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { ThemeChip("System", themeMode == ThemeMode.SYSTEM) { onThemeChange(ThemeMode.SYSTEM) }; ThemeChip("Light", themeMode == ThemeMode.LIGHT) { onThemeChange(ThemeMode.LIGHT) }; ThemeChip("Dark", themeMode == ThemeMode.DARK) { onThemeChange(ThemeMode.DARK) }; }; Spacer(Modifier.height(10.dp)); SettingSwitch("Use device dynamic colors", dynamicColor, onDynamicColorChange) }
            }
            item { SettingsSection("AI provider", Icons.Default.Settings) { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(provider == "Gemini", { onProviderChange("Gemini") }, label = { Text("Gemini") }); FilterChip(provider == "OpenAI", { onProviderChange("OpenAI") }, label = { Text("OpenAI") }) } } }
            item { SettingsSection("API keys", Icons.Default.Key) { Text("Keys are encrypted and stored locally on this device.", style = MaterialTheme.typography.bodySmall); Spacer(Modifier.height(8.dp)); OutlinedTextField(openai, onOpenAiChange, Modifier.fillMaxWidth(), label = { Text("OpenAI API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation()); Spacer(Modifier.height(8.dp)); OutlinedTextField(gemini, onGeminiChange, Modifier.fillMaxWidth(), label = { Text("Gemini API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation()) } }
            item { SettingsSection("Voice", Icons.Default.Mic) { SettingSwitch("Read Leo replies aloud", voiceReplies, onVoiceRepliesChange); Spacer(Modifier.height(8.dp)); SettingSwitch("Hey Leo wake word", wakeWord, onWakeWordChange); Text("When enabled, Leo uses a visible microphone notification. A small popup can appear over other apps after you say Hey Leo. Android requires microphone and display-over-other-apps permissions.", style = MaterialTheme.typography.bodySmall) } }
            item { SettingsSection("Chat", Icons.Default.DeleteSweep) { OutlinedButton(onClick = onClearChat, Modifier.fillMaxWidth()) { Icon(Icons.Default.DeleteSweep, null); Spacer(Modifier.width(8.dp)); Text("Clear saved chats") } } }
            item { SettingsSection("About Leo", Icons.Default.Info) { Text("Leo v2.0.0", fontWeight = FontWeight.SemiBold); Text("Your own AI assistant", style = MaterialTheme.typography.bodyMedium) } }
        }
    }
}

@Composable private fun SettingsSection(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) { Card(RoundedCornerShape(22.dp)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null); Spacer(Modifier.width(10.dp)); Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp) }; Spacer(Modifier.height(8.dp)); content() } } }
@Composable private fun ThemeChip(label: String, selected: Boolean, onClick: () -> Unit) = FilterChip(selected, onClick, label = { Text(label) })
@Composable private fun SettingSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(checked, onCheckedChange) } }

sealed class CommandResult { data class Done(val text: String) : CommandResult(); object NeedContacts : CommandResult(); object NeedCall : CommandResult(); object None : CommandResult() }

suspend fun handleCommand(ctx: Context, text: String): CommandResult {
    val l = text.lowercase(Locale.getDefault()).trim()
    if (l.startsWith("search ")) { val q = text.substringAfter("search ").trim(); if (q.isNotBlank()) { ctx.startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", q)); return CommandResult.Done("Searching for $q.") } }
    if (l.startsWith("open ")) return CommandResult.Done(AppActions.openApp(ctx, text.substringAfter("open ")))
    if (l.startsWith("call ")) { val (ok, result) = AppActions.callContact(ctx, text.substringAfter("call ")); if (result.contains("permission")) return if (result.contains("contact")) CommandResult.NeedContacts else CommandResult.NeedCall; return CommandResult.Done(result) }
    return CommandResult.None
}

fun startWakeService(ctx: Context) {
    val i = Intent(ctx, WakeWordService::class.java)
    if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(ctx, i) else ctx.startService(i)
}
fun stopWakeService(ctx: Context) { ctx.stopService(Intent(ctx, WakeWordService::class.java)) }
