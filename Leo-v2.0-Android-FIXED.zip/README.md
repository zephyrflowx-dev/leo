# Leo v2.0

Personal Android AI assistant.

## v2.0 additions
- Hey Leo wake-word mode using an Android microphone foreground service
- Small listening overlay after the wake word when display-over-other-apps permission is granted
- Voice commands can open installed apps, call contacts, or continue as an AI chat
- More robust app launching using known package aliases plus installed-app label matching
- Persistent chat history with a dedicated Chat History screen
- Existing Gemini/OpenAI switching, encrypted API-key storage, themes, voice replies, calling, web search, and app icon retained

## Permissions
Wake-word mode requires microphone permission and, for the popup over other apps, Android's display-over-other-apps permission. Android shows a persistent foreground-service notification while wake-word mode is enabled.

## Build
Upload `Leo-v2.0-Android-FIXED.zip` to the repository and run the `Build Leo APK` GitHub Actions workflow.
