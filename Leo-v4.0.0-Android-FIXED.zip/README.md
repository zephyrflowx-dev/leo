# Leo v4.0.0

Modern voice-first Android AI assistant.

## Changes in v4.0.0
- Redesigned Gemini-inspired voice-first UI with a cleaner conversation layout and animated Leo orb.
- Added Groq as an AI provider and a dedicated Groq API key field.
- Groq normal chat uses the OpenAI-compatible Groq Chat Completions endpoint.
- Reworked Gemini Live service to use the current Gemini 3.8 Live model and removed the overlay requirement from Live mode.
- Fixed the wake-word → Live microphone handoff so the wake listener releases the microphone before Live starts.
- Wake detection threshold lowered to 0.45 for easier detection.
- The bundled openWakeWord model is **Hey Jarvis**. Exact **Hey Leo** requires a separately trained compatible wake-word model asset; the app does not pretend the bundled model is Hey Leo.
- Wake listening remains visible through Android's microphone privacy indicator and foreground notification.

## Build
Use the included GitHub Actions workflow. The workflow installs Gradle 8.7 and Android SDK 35 and builds `app-debug.apk`.
