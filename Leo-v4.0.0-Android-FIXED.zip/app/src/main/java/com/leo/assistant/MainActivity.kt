package com.leo.assistant

import android.Manifest
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.view.Window
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale


data class Msg(val text: String, val user: Boolean)
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class LeoFont { SYSTEM, SANS, SERIF, MONO, CURSIVE }

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

class MainActivity : ComponentActivity() {
    private var incomingVoice by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureBars(window)
        incomingVoice = intent?.getStringExtra("voice_command").orEmpty()
        setContent { LeoApp(incomingVoice) { incomingVoice = "" } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incomingVoice = intent.getStringExtra("voice_command").orEmpty()
    }
}

private fun configureBars(window: Window) {
    window.statusBarColor = android.graphics.Color.TRANSPARENT
    window.navigationBarColor = android.graphics.Color.TRANSPARENT
    if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
}

@Composable
private fun LeoTheme(mode: ThemeMode, dynamic: Boolean, font: LeoFont, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val ctx = LocalContext.current
    val colors = if (dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) androidx.compose.material3.dynamicDarkColorScheme(ctx) else androidx.compose.material3.dynamicLightColorScheme(ctx)
    } else if (dark) {
        androidx.compose.material3.darkColorScheme(
            background = Color(0xFF0B0B10), surface = Color(0xFF111119), surfaceContainer = Color(0xFF191922)
        )
    } else {
        androidx.compose.material3.lightColorScheme(
            background = Color(0xFFFBF9FF), surface = Color(0xFFFFFFFF), surfaceContainer = Color(0xFFF3F1F8)
        )
    }
    val family = when (font) {
        LeoFont.SYSTEM -> FontFamily.Default
        LeoFont.SANS -> FontFamily.SansSerif
        LeoFont.SERIF -> FontFamily.Serif
        LeoFont.MONO -> FontFamily.Monospace
        LeoFont.CURSIVE -> FontFamily.Cursive
    }
    val base = androidx.compose.material3.Typography()
    MaterialTheme(
        colorScheme = colors,
        typography = base.copy(
            headlineLarge = base.headlineLarge.copy(fontFamily = family),
            headlineMedium = base.headlineMedium.copy(fontFamily = family),
            titleLarge = base.titleLarge.copy(fontFamily = family),
            titleMedium = base.titleMedium.copy(fontFamily = family),
            bodyLarge = base.bodyLarge.copy(fontFamily = family),
            bodyMedium = base.bodyMedium.copy(fontFamily = family),
            bodySmall = base.bodySmall.copy(fontFamily = family)
        ),
        content = content
    )
}

private sealed class CommandResult {
    data class Done(val text: String) : CommandResult()
    data object None : CommandResult()
    data object NeedContacts : CommandResult()
    data object NeedCall : CommandResult()
}

private fun handleCommand(ctx: Context, text: String): CommandResult {
    val lower = text.trim().lowercase(Locale.getDefault())
    if (lower.startsWith("open ")) return CommandResult.Done(AppActions.openApp(ctx, text.trim().substringAfter(" ")))
    if (lower.startsWith("search ") || lower.startsWith("search the web for ") || lower.startsWith("google ")) {
        val query = when {
            lower.startsWith("search the web for ") -> text.trim().substring(20)
            else -> text.trim().substringAfter(" ")
        }.trim()
        if (query.isNotBlank()) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return CommandResult.Done("Searching the web for $query.")
        }
    }
    if (lower.startsWith("call ")) {
        val name = text.trim().substringAfter(" ").trim()
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return CommandResult.NeedContacts
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return CommandResult.NeedCall
        return CommandResult.Done(AppActions.callContact(ctx, name).second)
    }
    return CommandResult.None
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LeoApp(incomingVoice: String, onVoiceConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { SecureStore(ctx) }
    val chatStore = remember { ChatStore(ctx) }
    val scope = rememberCoroutineScope()

    var provider by remember { mutableStateOf(store.get("provider").ifBlank { "Gemini" }) }
    var openai by remember { mutableStateOf(store.get("openai")) }
    var gemini by remember { mutableStateOf(store.get("gemini")) }
    var anthropic by remember { mutableStateOf(store.get("anthropic")) }
    var groq by remember { mutableStateOf(store.get("groq")) }
    var input by remember { mutableStateOf("") }
    var screen by remember { mutableStateOf("home") }
    var busy by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    var speaking by remember { mutableStateOf(false) }
    var liveMode by remember { mutableStateOf(store.get("live_mode") == "true") }
    var orbState by remember { mutableStateOf(OrbState.IDLE) }
    var hotwordEnabled by remember { mutableStateOf(store.get("hotword_enabled") == "true") }
    var theme by remember { mutableStateOf(runCatching { ThemeMode.valueOf(store.get("theme").ifBlank { "SYSTEM" }) }.getOrDefault(ThemeMode.SYSTEM)) }
    var dynamic by remember { mutableStateOf(store.get("dynamic_color") != "false") }
    var font by remember { mutableStateOf(runCatching { LeoFont.valueOf(store.get("font").ifBlank { "SYSTEM" }) }.getOrDefault(LeoFont.SYSTEM)) }
    var selectedVoice by remember { mutableStateOf(store.get("tts_voice")) }
    var showKeyboard by remember { mutableStateOf(false) }
    var actionLabel by remember { mutableStateOf<String?>(null) }
    var pendingCallName by remember { mutableStateOf<String?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var voices by remember { mutableStateOf<List<Voice>>(emptyList()) }
    var speechResult by remember { mutableStateOf("") }
    var attachments by remember { mutableStateOf<List<AiAttachment>>(emptyList()) }
    val messages = remember { mutableStateListOf<Msg>().apply { addAll(chatStore.load()) } }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        attachments = uris.mapNotNull { readAttachment(ctx, it) }.take(6)
    }

    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine?.language = Locale.getDefault()
                tts = engine
                voices = engine?.voices?.filter { !it.isNetworkConnectionRequired }
                    ?.sortedBy { it.name.lowercase(Locale.getDefault()) }.orEmpty()
            }
        }
        onDispose { engine?.stop(); engine?.shutdown(); tts = null }
    }

    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    LiveAssistantService.ACTION_STATE -> {
                        liveMode = intent.getBooleanExtra(LiveAssistantService.EXTRA_LIVE, false)
                        orbState = if (liveMode) OrbState.LISTENING else OrbState.IDLE
                        store.put("live_mode", liveMode.toString())
                    }
                    LiveAssistantService.ACTION_ORB_STATE -> {
                        orbState = when (intent.getStringExtra(LiveAssistantService.EXTRA_ORB_STATE)) {
                            "listening" -> OrbState.LISTENING
                            "thinking" -> OrbState.THINKING
                            "speaking" -> OrbState.SPEAKING
                            else -> OrbState.IDLE
                        }
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(LiveAssistantService.ACTION_STATE)
            addAction(LiveAssistantService.ACTION_ORB_STATE)
        }
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") ctx.registerReceiver(receiver, filter)
        onDispose { runCatching { ctx.unregisterReceiver(receiver) } }
    }

    val speech = remember(ctx) {
        LeoSpeechController(
            ctx,
            onResult = { speechResult = it },
            onError = { listening = false },
            onListeningChanged = { listening = it }
        )
    }
    DisposableEffect(speech) { onDispose { speech.stop() } }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startLiveSafely(ctx, store) { liveMode = true }
    }
    val contactsPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val callPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun save() = chatStore.save(messages)
    fun speak(text: String) {
        val engine = tts ?: return
        if (selectedVoice.isNotBlank()) engine.voices?.firstOrNull { it.name == selectedVoice }?.let { engine.voice = it }
        speaking = true
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { speaking = true }
            override fun onDone(utteranceId: String?) { speaking = false }
            override fun onError(utteranceId: String?) { speaking = false }
        })
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "leo")
    }

    fun send(textValue: String = input) {
        val text = textValue.trim()
        if ((text.isEmpty() && attachments.isEmpty()) || busy) return
        val currentAttachments = attachments
        val visibleText = if (text.isBlank()) "Attached files: ${currentAttachments.joinToString(", ") { it.name }}" else text
        input = ""
        attachments = emptyList()
        showKeyboard = false
        actionLabel = null
        messages.add(Msg(visibleText, true)); save(); busy = true; orbState = OrbState.THINKING
        scope.launch {
            val lower = text.lowercase(Locale.getDefault())
            if (currentAttachments.isEmpty() && (lower.startsWith("call ") || lower.startsWith("ring "))) {
                pendingCallName = text.substringAfter(" ").trim(); busy = false; orbState = OrbState.IDLE; return@launch
            }
            val command = if (currentAttachments.isEmpty()) withContext(Dispatchers.Default) { handleCommand(ctx, text) } else CommandResult.None
            val reply = when (command) {
                is CommandResult.Done -> { actionLabel = command.text; command.text }
                CommandResult.NeedContacts -> { contactsPermission.launch(Manifest.permission.READ_CONTACTS); "I need contact permission to find that person." }
                CommandResult.NeedCall -> { callPermission.launch(Manifest.permission.CALL_PHONE); "I need phone permission to place that call." }
                CommandResult.None -> withContext(Dispatchers.IO) { AiClient().ask(provider, keyFor(provider, openai, gemini, anthropic, groq), text, currentAttachments, messages.dropLast(1)) }
            }
            messages.add(Msg(reply, false)); save(); busy = false; orbState = OrbState.IDLE
        }
    }

    LaunchedEffect(speechResult) {
        if (speechResult.isNotBlank()) { input = speechResult; send(speechResult); speechResult = "" }
    }
    LaunchedEffect(incomingVoice) {
        if (incomingVoice.isNotBlank()) { send(incomingVoice); onVoiceConsumed() }
    }

    LeoTheme(theme, dynamic, font) {
        when (screen) {
            "settings" -> SettingsScreen(
                provider, { provider = it; store.put("provider", it) },
                openai, { openai = it; store.put("openai", it) },
                gemini, { gemini = it; store.put("gemini", it) },
                anthropic, { anthropic = it; store.put("anthropic", it) },
                groq, { groq = it; store.put("groq", it) },
                theme, { theme = it; store.put("theme", it.name) },
                dynamic, { dynamic = it; store.put("dynamic_color", it.toString()) },
                hotwordEnabled,
                { enabled ->
                    if (enabled && ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    } else {
                        hotwordEnabled = enabled; store.put("hotword_enabled", enabled.toString())
                        if (enabled) LeoHotwordService.start(ctx) else LeoHotwordService.stop(ctx)
                    }
                },
                font, { font = it; store.put("font", it.name) }, selectedVoice, voices,
                { selectedVoice = it; store.put("tts_voice", it) },
                { speak("Hello, I'm Leo. Your voice assistant is ready.") },
                { openAssistantSettings(ctx) },
                { messages.clear(); chatStore.clear(); save() },
                { screen = "home" }
            )
            "history" -> HistoryScreen(messages, { screen = "home" }, { messages.clear(); chatStore.clear(); save() })
            else -> HomeScreen(
                input, busy, listening, speaking, liveMode, orbState, messages, attachments, actionLabel, showKeyboard,
                onInput = { input = it },
                onSuggestion = { input = it; send(it) },
                onPickFiles = { filePicker.launch(arrayOf("*/*")) },
                onRemoveAttachment = { i -> attachments = attachments.toMutableList().also { it.removeAt(i) } },
                onNewChat = { messages.clear(); chatStore.clear(); actionLabel = null },
                onSend = { send() },
                onVoice = {
                    if (liveMode) { LiveAssistantService.stop(ctx); liveMode = false }
                    else if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    else startLiveSafely(ctx, store) { liveMode = true }
                },
                onHistory = { screen = "history" }, onSettings = { screen = "settings" },
                onKeyboard = { showKeyboard = !showKeyboard }, onSay = { speak(it) },
                onPickMic = { speech.start() }
            )
        }
    }

    if (pendingCallName != null) {
        val name = pendingCallName!!
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { pendingCallName = null },
            title = { Text("Call $name?") },
            text = { Text("Leo will place the call only after confirmation.") },
            confirmButton = { Button(onClick = { pendingCallName = null; send("call $name") }) { Text("Call") } },
            dismissButton = { TextButton(onClick = { pendingCallName = null }) { Text("Cancel") } }
        )
    }
}

private fun keyFor(provider: String, openai: String, gemini: String, anthropic: String, groq: String) = when (provider) {
    "OpenAI" -> openai
    "Anthropic" -> anthropic
    "Groq" -> groq
    else -> gemini
}

private fun startLiveSafely(ctx: Context, store: SecureStore, onStarted: () -> Unit) {
    if (store.get("gemini").isBlank()) return
    store.put("live_mode", "true")
    onStarted()
    LiveAssistantService.start(ctx)
}

private fun openAssistantSettings(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 29) {
        val role = ctx.getSystemService(RoleManager::class.java)
        if (role?.isRoleAvailable(RoleManager.ROLE_ASSISTANT) == true) {
            runCatching { ctx.startActivity(role.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT)) }.onFailure { ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
            return
        }
    }
    runCatching { ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
}

private fun readAttachment(ctx: Context, uri: Uri): AiAttachment? = runCatching {
    val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
    val name = uri.lastPathSegment?.substringAfterLast('/') ?: "attachment"
    val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
    if (bytes.size > 10 * 1024 * 1024) return null
    AiAttachment(name, mime, bytes)
}.getOrNull()

@Composable
private fun HomeScreen(
    input: String, busy: Boolean, listening: Boolean, speaking: Boolean, liveMode: Boolean, orbState: OrbState,
    messages: List<Msg>, attachments: List<AiAttachment>, actionLabel: String?, showKeyboard: Boolean,
    onInput: (String) -> Unit, onSuggestion: (String) -> Unit, onPickFiles: () -> Unit, onRemoveAttachment: (Int) -> Unit,
    onNewChat: () -> Unit, onSend: () -> Unit, onVoice: () -> Unit, onHistory: () -> Unit, onSettings: () -> Unit,
    onKeyboard: () -> Unit, onSay: (String) -> Unit, onPickMic: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }
    val active = liveMode || listening
    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceContainer) {
                    Icon(painterResource(R.drawable.leo_icon), null, Modifier.size(38.dp).padding(5.dp))
                }
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text("Leo", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text(if (active) "Voice conversation" else "Personal AI assistant", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                    DropdownMenu(menuOpen, { menuOpen = false }) {
                        DropdownMenuItem({ Text("New chat") }, leadingIcon = { Icon(Icons.Default.AddComment, null) }, onClick = { menuOpen = false; onNewChat() })
                        DropdownMenuItem({ Text("History") }, leadingIcon = { Icon(Icons.Default.History, null) }, onClick = { menuOpen = false; onHistory() })
                        DropdownMenuItem({ Text("Settings") }, leadingIcon = { Icon(Icons.Default.Settings, null) }, onClick = { menuOpen = false; onSettings() })
                    }
                }
            }

            Box(Modifier.fillMaxWidth().weight(1f)) {
                if (messages.isEmpty()) {
                    WelcomeHero(orbState, onSuggestion)
                } else {
                    LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(messages) { msg -> MessageBubble(msg, onSay) }
                        if (actionLabel != null) item { AssistChip(onClick = {}, label = { Text(actionLabel) }) }
                    }
                }
            }

            if (messages.isNotEmpty() && !active) Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { MiniOrb(orbState) }

            AnimatedVisibility(showKeyboard) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                    if (attachments.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        attachments.forEachIndexed { i, a -> AssistChip(onClick = { onRemoveAttachment(i) }, label = { Text(a.name.take(18)) }) }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onPickFiles) { Icon(Icons.Default.AttachFile, "Attach") }
                        OutlinedTextField(input, onInput, Modifier.weight(1f), placeholder = { Text("Ask Leo…") }, maxLines = 4, shape = RoundedCornerShape(26.dp))
                        IconButton(onClick = onSend, enabled = input.isNotBlank() || attachments.isNotEmpty()) { Icon(Icons.Default.Add, "Send") }
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }

            Surface(color = MaterialTheme.colorScheme.background, tonalElevation = 0.dp, modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    IconButton(onClick = onKeyboard) { Icon(Icons.Default.Keyboard, "Keyboard") }
                    Spacer(Modifier.width(20.dp))
                    FilledIconButton(onClick = onVoice, modifier = Modifier.size(74.dp), shape = CircleShape) {
                        Icon(if (active) Icons.Default.Stop else Icons.Default.Mic, if (active) "Stop" else "Talk", Modifier.size(32.dp))
                    }
                    Spacer(Modifier.width(20.dp))
                    IconButton(onClick = onPickMic) { Icon(Icons.Default.WbSunny, "Voice input") }
                }
            }
        }
    }
}

@Composable
private fun WelcomeHero(state: OrbState, onSuggestion: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        LargeOrb(state)
        Spacer(Modifier.height(26.dp))
        Text("Hi, I'm Leo", fontSize = 31.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text("Ask anything, or tap the microphone to talk.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Explain something", "Search the web", "Open YouTube").forEach { label -> AssistChip(onClick = { onSuggestion(label) }, label = { Text(label) }) }
        }
    }
}

@Composable
private fun LargeOrb(state: OrbState) {
    val transition = rememberInfiniteTransition(label = "leoOrb")
    val pulse by transition.animateFloat(1f, if (state == OrbState.IDLE) 1.03f else 1.10f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "pulse")
    val gradient = Brush.radialGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.background))
    Box(Modifier.size(190.dp * pulse).clip(CircleShape).background(gradient), contentAlignment = Alignment.Center) {
        Icon(painterResource(R.drawable.leo_icon), "Leo", Modifier.size(112.dp).clip(CircleShape), tint = Color.Unspecified)
        if (state == OrbState.THINKING) androidx.compose.material3.CircularProgressIndicator(Modifier.size(126.dp), strokeWidth = 4.dp)
    }
}

@Composable
private fun MiniOrb(state: OrbState) {
    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.size(54.dp)) {
        Box(contentAlignment = Alignment.Center) { Icon(painterResource(R.drawable.leo_icon), "Leo", Modifier.size(36.dp), tint = Color.Unspecified) }
    }
}

@Composable
private fun MessageBubble(msg: Msg, onSay: (String) -> Unit) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (msg.user) Alignment.End else Alignment.Start) {
        if (msg.user) {
            Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = RoundedCornerShape(22.dp)) { Text(msg.text, Modifier.padding(horizontal = 15.dp, vertical = 11.dp), fontSize = 15.sp) }
        } else {
            Row(verticalAlignment = Alignment.Top) {
                Icon(painterResource(R.drawable.leo_icon), "Leo", Modifier.size(28.dp).clip(CircleShape), tint = Color.Unspecified)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(msg.text, fontSize = 16.sp, lineHeight = 24.sp)
                    IconButton(onClick = { onSay(msg.text) }, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.VolumeUp, "Speak", Modifier.size(18.dp)) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HistoryScreen(messages: List<Msg>, onBack: () -> Unit, onClear: () -> Unit) {
    Scaffold(topBar = { TopAppBar(navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }, title = { Text("History") }, actions = { IconButton(onClick = onClear) { Icon(Icons.Default.DeleteSweep, "Clear") } }) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (messages.isEmpty()) item { Text("No saved chats yet.") }
            items(messages) { m -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(15.dp)) { Text(if (m.user) "You" else "Leo", fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(m.text) } } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(
    provider: String, onProvider: (String) -> Unit,
    openai: String, onOpenAi: (String) -> Unit, gemini: String, onGemini: (String) -> Unit,
    anthropic: String, onAnthropic: (String) -> Unit, groq: String, onGroq: (String) -> Unit,
    theme: ThemeMode, onTheme: (ThemeMode) -> Unit, dynamic: Boolean, onDynamic: (Boolean) -> Unit,
    hotwordEnabled: Boolean, onHotword: (Boolean) -> Unit, font: LeoFont, onFont: (LeoFont) -> Unit,
    selectedVoice: String, voices: List<Voice>, onVoice: (String) -> Unit, onTestVoice: () -> Unit,
    onAssistant: () -> Unit, onClear: () -> Unit, onBack: () -> Unit
) {
    Scaffold(topBar = { TopAppBar(navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }, title = { Text("Settings") }) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { SettingsCard("AI provider", Icons.Default.AutoAwesome) {
                Text("Choose the engine used for normal chats.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("Gemini", "OpenAI", "Anthropic", "Groq").forEach { name -> FilterChip(provider == name, { onProvider(name) }, label = { Text(name) }) }
                }
            } }
            item { SettingsCard("API keys", Icons.Default.Settings) {
                Text("Keys stay on this device.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                KeyField("Gemini API key", gemini, onGemini); Spacer(Modifier.height(8.dp))
                KeyField("OpenAI API key", openai, onOpenAi); Spacer(Modifier.height(8.dp))
                KeyField("Anthropic API key", anthropic, onAnthropic); Spacer(Modifier.height(8.dp))
                KeyField("Groq API key", groq, onGroq)
            } }
            item { SettingsCard("Voice & wake word", Icons.Default.Mic) {
                Text("Wake listening is local and requires a visible microphone foreground service.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Wake word", Modifier.weight(1f), fontWeight = FontWeight.SemiBold); Switch(hotwordEnabled, onHotword) }
                Spacer(Modifier.height(6.dp))
                Text("Built-in phrase: Hey Jarvis. Exact Hey Leo needs a trained Hey Leo model asset.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                VoiceSelector(selectedVoice, voices, onVoice)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onTestVoice, Modifier.fillMaxWidth()) { Icon(Icons.Default.VolumeUp, null); Spacer(Modifier.width(8.dp)); Text("Test voice") }
            } }
            item { SettingsCard("Appearance", Icons.Default.Settings) {
                Text("Theme", fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ThemeChip("System", theme == ThemeMode.SYSTEM) { onTheme(ThemeMode.SYSTEM) }
                    ThemeChip("Light", theme == ThemeMode.LIGHT) { onTheme(ThemeMode.LIGHT) }
                    ThemeChip("Dark", theme == ThemeMode.DARK) { onTheme(ThemeMode.DARK) }
                }
                Spacer(Modifier.height(10.dp)); SettingSwitch("Use device dynamic colors", dynamic, onDynamic)
                Spacer(Modifier.height(10.dp)); FontSelector(font, onFont)
            } }
            item { SettingsCard("Device assistant", Icons.Default.AutoAwesome) {
                Text("Let Leo appear as the Android digital assistant.", color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(8.dp))
                Button(onClick = onAssistant, Modifier.fillMaxWidth()) { Text("Set Leo as device assistant") }
            } }
            item { SettingsCard("Chat", Icons.Default.AddComment) {
                OutlinedButton(onClick = onClear, Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("New chat") }
            } }
            item { Text("Leo v4.0.0 • modern voice-first build", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp)) }
        }
    }
}

@Composable
private fun SettingsCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer), shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(10.dp)); Text(title, fontWeight = FontWeight.SemiBold, fontSize = 18.sp) }
            Spacer(Modifier.height(13.dp)); content()
        }
    }
}

@Composable
private fun KeyField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), shape = RoundedCornerShape(18.dp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FontSelector(selected: LeoFont, onChange: (LeoFont) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val label = when (selected) { LeoFont.SYSTEM -> "System Default"; LeoFont.SANS -> "Sans"; LeoFont.SERIF -> "Serif"; LeoFont.MONO -> "Monospace"; LeoFont.CURSIVE -> "Cursive" }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(label, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Font") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, shape = RoundedCornerShape(18.dp))
        ExposedDropdownMenu(expanded, { expanded = false }) { LeoFont.values().forEach { f -> androidx.compose.material3.DropdownMenuItem(text = { Text(f.name.lowercase().replaceFirstChar { it.uppercase() }) }, onClick = { onChange(f); expanded = false }) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VoiceSelector(selected: String, voices: List<Voice>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val label = voices.firstOrNull { it.name == selected }?.let { "${it.locale.displayLanguage} · ${it.name}" } ?: if (selected.isBlank()) "System default" else selected
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(label, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Voice") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, shape = RoundedCornerShape(18.dp))
        ExposedDropdownMenu(expanded, { expanded = false }) {
            DropdownMenuItem(text = { Text("System default") }, onClick = { onChange(""); expanded = false })
            voices.take(60).forEach { v -> DropdownMenuItem(text = { Text("${v.locale.displayLanguage} · ${v.name}") }, onClick = { onChange(v.name); expanded = false }) }
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(checked, onChange) }
}

@Composable
private fun ThemeChip(label: String, selected: Boolean, onClick: () -> Unit) = FilterChip(selected, onClick, label = { Text(label) })
