package com.leo.assistant

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.openwakeword.OpenWakeWord

/**
 * Real on-device wake-word listener using the openWakeWord Android/ONNX engine.
 *
 * The detector processes microphone audio locally. It does not send the
 * wake-listening stream to an AI provider. When a wake word is detected,
 * Leo starts Gemini Live, which then owns the microphone for the conversation.
 *
 * For the exact "Hey Leo" phrase, place a compatible custom OpenWakeWord
 * classifier at app/src/main/assets/hey_leo.onnx. If that asset is not present,
 * the service falls back to the library's bundled HEY_JARVIS model so the
 * on-device engine can still be tested immediately.
 */
class LeoHotwordService : Service() {
    companion object {
        private const val ACTION_START = "com.leo.assistant.action.START_HOTWORD"
        private const val ACTION_STOP = "com.leo.assistant.action.STOP_HOTWORD"
        private const val CHANNEL_ID = "leo_hotword"
        private const val NOTIFICATION_ID = 2602
        private const val THRESHOLD = 0.45f
        private const val DEBOUNCE_MS = 2500L

        fun start(context: Context) {
            val intent = Intent(context, LeoHotwordService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, LeoHotwordService::class.java))
        }
    }

    private var running = false
    private var detector: OpenWakeWord? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startHotword()
            ACTION_STOP -> stopHotword()
        }
        return START_STICKY
    }

    private fun startHotword() {
        if (running) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }

        running = true
        startForegroundNotification()

        detector = runCatching {
            val builder = OpenWakeWord.Builder(this)
                .setThreshold(THRESHOLD)
                .setDebounceMs(DEBOUNCE_MS)

            // A custom Hey Leo ONNX classifier can be dropped into assets.
            // Otherwise use the bundled model for an immediate engine test.
            if (hasAsset("hey_leo.onnx")) {
                builder.setModelAsset("hey_leo.onnx")
            } else {
                builder.setModel(OpenWakeWord.BuiltInModel.HEY_JARVIS)
            }
            builder.build()
        }.getOrNull()

        val d = detector
        if (d == null) {
            running = false
            stopSelf()
            return
        }

        runCatching {
            d.start {
                if (!running) return@start
                // Release the wake listener microphone before Live opens its own microphone.
                running = false
                runCatching { d.stop(); d.release() }
                detector = null
                stopForeground(STOP_FOREGROUND_REMOVE)
                android.os.Handler(mainLooper).postDelayed({
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        LiveAssistantService.start(this)
                    }
                }, 450L)
            }
        }.onFailure {
            stopHotword()
        }
    }

    private fun hasAsset(name: String): Boolean =
        runCatching { assets.open(name).close(); true }.getOrDefault(false)

    private fun startForegroundNotification() {
        val launch = PendingIntent.getActivity(
            this,
            2602,
            Intent(this, MainActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            ),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this,
            2603,
            Intent(this, LeoHotwordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val customModel = hasAsset("hey_leo.onnx")
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.leo_icon)
            .setContentTitle("Leo wake word is on")
            .setContentText(
                if (customModel) "Listening locally for Hey Jarvis"
                else "Listening locally for Hey Jarvis"
            )
            .setContentIntent(launch)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stop)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Leo wake word",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Visible notification while Leo wake listening is enabled"
                    setSound(null, null)
                    enableVibration(false)
                }
            )
        }
    }

    private fun stopHotword() {
        running = false
        detector?.let { runCatching { it.stop(); it.release() } }
        detector = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        detector?.let { runCatching { it.stop(); it.release() } }
        detector = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
