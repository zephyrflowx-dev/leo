package com.leo.assistant

import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject

class AiClient {
    fun ask(provider:String,key:String,message:String):String {
        if(key.isBlank()) return "Add your $provider API key in Settings."
        return try {
            if(provider=="OpenAI") openAi(key,message) else gemini(key,message)
        } catch(e:Exception) {
            "Leo couldn't reach $provider. Check your internet connection."
        }
    }

    private fun openAi(key:String,msg:String):String {
        val c=URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod="POST"; c.doOutput=true; c.connectTimeout=15000; c.readTimeout=30000
        c.setRequestProperty("Authorization","Bearer $key")
        c.setRequestProperty("Content-Type","application/json")
        val b=JSONObject().put("model","gpt-4o-mini")
            .put("messages",JSONArray().put(JSONObject().put("role","user").put("content",msg)))
        c.outputStream.use{it.write(b.toString().toByteArray(Charsets.UTF_8))}
        val responseCode=c.responseCode
        val r=if(responseCode in 200..299)c.inputStream else c.errorStream
        val s=r?.bufferedReader()?.use{it.readText()} ?: ""
        if(responseCode !in 200..299) return openAiError(responseCode,s)
        return JSONObject(s).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    private fun gemini(key:String,msg:String):String {
        val model="gemini-3.5-flash-lite"
        val u="https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val c=URL(u).openConnection() as HttpURLConnection
        c.requestMethod="POST"; c.doOutput=true; c.connectTimeout=15000; c.readTimeout=30000
        c.setRequestProperty("Content-Type","application/json")
        c.setRequestProperty("x-goog-api-key",key)
        val b=JSONObject().put("contents",JSONArray().put(JSONObject().put(
            "parts",JSONArray().put(JSONObject().put("text",msg)))))
        c.outputStream.use{it.write(b.toString().toByteArray(Charsets.UTF_8))}
        val responseCode=c.responseCode
        val r=if(responseCode in 200..299)c.inputStream else c.errorStream
        val s=r?.bufferedReader()?.use{it.readText()} ?: ""
        if(responseCode !in 200..299) return geminiError(responseCode,s)
        return JSONObject(s).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    private fun openAiError(code:Int,body:String):String {
        val detail=try { JSONObject(body).getJSONObject("error").optString("message") } catch(_:Exception) { "" }
        return when(code) {
            401 -> "OpenAI error 401: API key is invalid or expired."
            403 -> "OpenAI error 403: this API key is not allowed to use the requested resource."
            429 -> "OpenAI error 429: the API quota or rate limit was reached. Check the OpenAI project usage/billing limits."
            else -> if(detail.isNotBlank()) "OpenAI error $code: $detail" else "OpenAI error: $code"
        }
    }

    private fun geminiError(code:Int,body:String):String {
        val detail=try { JSONObject(body).getJSONObject("error").optString("message") } catch(_:Exception) { "" }
        return when(code) {
            400 -> "Gemini error 400: the request was rejected."
            401 -> "Gemini error 401: API key is invalid or expired."
            403 -> "Gemini error 403: this API key does not have access to this resource."
            404 -> "Gemini error 404: the requested model was not found or is not available to this API key."
            429 -> "Gemini error 429: the API rate limit or quota was reached."
            else -> if(detail.isNotBlank()) "Gemini error $code: $detail" else "Gemini error: $code"
        }
    }
}
