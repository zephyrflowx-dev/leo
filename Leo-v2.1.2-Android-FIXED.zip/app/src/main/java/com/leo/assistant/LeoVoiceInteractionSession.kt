package com.leo.assistant

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.service.voice.VoiceInteractionSession
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class LeoVoiceInteractionSession(context: android.content.Context) : VoiceInteractionSession(context) {
    private var recognizer: SpeechRecognizer? = null
    private var status: TextView? = null

    override fun onCreateContentView(): View {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 28, 36, 28)
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        status = TextView(context).apply {
            text = "Leo\nListening…"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        return root
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        startListening()
    }

    private fun startListening() {
        status?.text = "Leo\nListening…"
        val intent = Intent(context, VoiceCaptureActivity::class.java)
        startAssistantActivity(intent)
        hide()
    }

    override fun onHide() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        super.onHide()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }
}
