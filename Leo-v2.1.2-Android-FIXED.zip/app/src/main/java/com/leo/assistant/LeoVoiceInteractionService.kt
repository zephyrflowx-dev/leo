package com.leo.assistant

import android.service.voice.VoiceInteractionService

class LeoVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
    }

    override fun onShutdown() {
        super.onShutdown()
    }
}
