# Leo v5.0 — One-ZIP package

`leo-source.zip` contains the fixed native Android project. The project itself includes the GitHub Actions workflow.

For the simplest GitHub setup, extract `leo-source.zip` and upload its contents to the repository root. The `.github/workflows/build-apk.yml` file must be at the repository root for GitHub Actions to detect it.
