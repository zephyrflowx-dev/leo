#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RES="$ROOT/android/app/src/main/res"
mkdir -p "$RES/drawable" "$RES/mipmap-hdpi" "$RES/mipmap-mdpi" "$RES/mipmap-xhdpi" "$RES/mipmap-xxhdpi" "$RES/mipmap-xxxhdpi"
cp "$ROOT/public/leo-icon.png" "$RES/drawable/leo_icon.png"
for d in mipmap-hdpi mipmap-mdpi mipmap-xhdpi mipmap-xxhdpi mipmap-xxxhdpi; do
  cp "$ROOT/public/leo-icon.png" "$RES/$d/ic_launcher.png"
  cp "$ROOT/public/leo-icon.png" "$RES/$d/ic_launcher_round.png"
done
if [ -f "$ROOT/android/app/src/main/AndroidManifest.xml" ]; then
  grep -q 'android.permission.RECORD_AUDIO' "$ROOT/android/app/src/main/AndroidManifest.xml" || sed -i '/<manifest[^>]*>/a\    <uses-permission android:name="android.permission.RECORD_AUDIO" />\n    <uses-permission android:name="android.permission.READ_CONTACTS" />' "$ROOT/android/app/src/main/AndroidManifest.xml"
  sed -i 's#android:icon="@mipmap/ic_launcher"#android:icon="@drawable/leo_icon"#g' "$ROOT/android/app/src/main/AndroidManifest.xml"
  sed -i 's#android:roundIcon="@mipmap/ic_launcher_round"#android:roundIcon="@drawable/leo_icon"#g' "$ROOT/android/app/src/main/AndroidManifest.xml"
fi
