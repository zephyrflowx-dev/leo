# Leo v5.0 — Standalone Android APK

This version keeps the supplied Leo UI design and moves the app away from the Vercel/Next.js server dependency. It uses Vite + React + Capacitor for a real Android WebView app.

## AI keys

The APK needs API keys to talk directly to Groq/Gemini. For a personal build, put them in GitHub Actions repository secrets:

- `GROQ_API_KEY`
- `GEMINI_API_KEY`

The workflow injects them as build-time environment variables. Do not commit real keys to the repository. A client APK cannot make an API key completely secret.

## Build

1. Upload this project to a GitHub repository.
2. In the repository settings, create the two Actions secrets above.
3. Open **Actions → Build Leo APK → Run workflow**.
4. Download the `Leo-v5.0-debug` artifact and install the APK on the Android phone.

The app is not configured with a `server.url`, so it does not launch Chrome and does not require the old Vercel deployment.

## Local build

```bash
corepack enable
pnpm install
cp .env.example .env.local
# fill in the keys in .env.local
pnpm build
pnpm exec cap add android
pnpm exec cap sync android
./scripts/prepare-android-assets.sh
cd android
./gradlew assembleDebug
```

## Current functionality

- Existing Leo UI structure and styling
- Groq/Gemini selection
- Local chat history
- Spoken replies
- Microphone recording + Groq Whisper transcription
- Android app launching for known apps
- Contact lookup + phone dialing

Wake-word/background listening is not included in this build yet; that requires an Android foreground-service/wake-word implementation and additional permissions.
