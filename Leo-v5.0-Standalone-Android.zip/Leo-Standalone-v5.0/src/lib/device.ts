import { Capacitor } from '@capacitor/core'
export const isNative = () => Capacitor.isNativePlatform()

const KNOWN_APPS: Record<string, { pkg: string; web?: string }> = {
  whatsapp: { pkg: 'com.whatsapp', web: 'https://web.whatsapp.com' }, youtube: { pkg: 'com.google.android.youtube', web: 'https://youtube.com' },
  instagram: { pkg: 'com.instagram.android', web: 'https://instagram.com' }, facebook: { pkg: 'com.facebook.katana', web: 'https://facebook.com' }, messenger: { pkg: 'com.facebook.orca' },
  spotify: { pkg: 'com.spotify.music', web: 'https://open.spotify.com' }, telegram: { pkg: 'org.telegram.messenger', web: 'https://web.telegram.org' }, snapchat: { pkg: 'com.snapchat.android' },
  twitter: { pkg: 'com.twitter.android', web: 'https://x.com' }, x: { pkg: 'com.twitter.android', web: 'https://x.com' }, gmail: { pkg: 'com.google.android.gm', web: 'https://mail.google.com' },
  chrome: { pkg: 'com.android.chrome' }, maps: { pkg: 'com.google.android.apps.maps', web: 'https://maps.google.com' }, 'google maps': { pkg: 'com.google.android.apps.maps', web: 'https://maps.google.com' },
  camera: { pkg: 'com.android.camera' }, settings: { pkg: 'com.android.settings' }, 'play store': { pkg: 'com.android.vending' }, photos: { pkg: 'com.google.android.apps.photos' },
  netflix: { pkg: 'com.netflix.mediaclient', web: 'https://netflix.com' }, calculator: { pkg: 'com.google.android.calculator' }, clock: { pkg: 'com.google.android.deskclock' },
  calendar: { pkg: 'com.google.android.calendar' }, phone: { pkg: 'com.google.android.dialer' }, messages: { pkg: 'com.google.android.apps.messaging' },
}

export async function openApp(appName: string, packageName?: string) {
  const key = appName.trim().toLowerCase(); const known = KNOWN_APPS[key]
  const candidates = [known?.pkg, packageName].filter(Boolean) as string[]
  if (isNative()) {
    const { AppLauncher } = await import('@capacitor/app-launcher')
    for (const pkg of candidates) {
      try {
        const { value } = await AppLauncher.canOpenUrl({ url: pkg })
        if (value) { await AppLauncher.openUrl({ url: pkg }); return { ok: true, message: `Opened ${appName}` } }
      } catch {}
    }
    return { ok: false, message: `${appName} doesn't seem to be installed.` }
  }
  if (known?.web) { window.open(known.web, '_blank', 'noopener'); return { ok: true, message: `Opened ${appName} on the web.` } }
  return { ok: false, message: 'Opening phone apps works inside the Leo Android app.' }
}

async function findContactNumber(name: string) {
  if (!isNative()) return null
  const { Contacts } = await import('@capacitor-community/contacts')
  const perm = await Contacts.requestPermissions()
  if (perm.contacts !== 'granted') throw new Error('Contacts permission denied')
  const { contacts } = await Contacts.getContacts({ projection: { name: true, phones: true } })
  const q = name.toLowerCase()
  const match = contacts.find(c => c.name?.display?.toLowerCase() === q) ?? contacts.find(c => c.name?.display?.toLowerCase().includes(q))
  const number = match?.phones?.find(p => p.number)?.number
  return number ? { number, display: match?.name?.display ?? name } : null
}

export async function makeCall(contactName?: string, phoneNumber?: string) {
  let number = phoneNumber?.replace(/[^\d+]/g, ''); let who = contactName ?? number ?? ''
  if (!number && contactName) {
    try {
      const found = await findContactNumber(contactName)
      if (!found) return { ok: false, message: isNative() ? `I couldn't find ${contactName} in your contacts.` : 'Calling contacts by name works inside the Leo Android app.' }
      number = found.number.replace(/[^\d+]/g, ''); who = found.display
    } catch (e) { return { ok: false, message: (e as Error).message } }
  }
  if (!number) return { ok: false, message: 'No phone number provided.' }
  window.location.href = `tel:${number}`
  return { ok: true, message: `Calling ${who}` }
}

export async function speak(text: string) {
  const clean = text.replace(/[*_#`>]/g, '').trim(); if (!clean) return
  if (isNative()) { const { TextToSpeech } = await import('@capacitor-community/text-to-speech'); await TextToSpeech.stop().catch(() => {}); await TextToSpeech.speak({ text: clean, lang: 'en-US', rate: 1.0 }).catch(() => {}); return }
  if ('speechSynthesis' in window) { window.speechSynthesis.cancel(); window.speechSynthesis.speak(new SpeechSynthesisUtterance(clean)) }
}
export async function stopSpeaking() {
  if (isNative()) { const { TextToSpeech } = await import('@capacitor-community/text-to-speech'); await TextToSpeech.stop().catch(() => {}) }
  else if ('speechSynthesis' in window) window.speechSynthesis.cancel()
}

export function detectDeviceCommand(text: string): { type: 'openApp'; appName: string } | { type: 'makeCall'; contactName?: string; phoneNumber?: string } | null {
  const t = text.trim()
  const open = t.match(/^(?:please\s+)?(?:open|launch|start)\s+(.+?)[.!?]?$/i)
  if (open) return { type: 'openApp', appName: open[1].trim() }
  const call = t.match(/^(?:please\s+)?(?:call|phone|dial)\s+(.+?)[.!?]?$/i)
  if (call) {
    const target = call[1].trim()
    return /^\+?[\d\s().-]+$/.test(target) ? { type: 'makeCall', phoneNumber: target } : { type: 'makeCall', contactName: target }
  }
  return null
}
