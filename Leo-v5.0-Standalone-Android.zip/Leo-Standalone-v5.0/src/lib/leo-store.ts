import { useSyncExternalStore } from 'react'

function createLocalStore<T>(key: string, fallback: T) {
  let cache: T | undefined
  const listeners = new Set<() => void>()
  const get = (): T => {
    if (cache !== undefined) return cache
    try {
      const raw = localStorage.getItem(key)
      cache = raw ? JSON.parse(raw) : fallback
    } catch { cache = fallback }
    return cache as T
  }
  const set = (next: T) => {
    cache = next
    try { localStorage.setItem(key, JSON.stringify(next)) } catch {}
    listeners.forEach((l) => l())
  }
  const subscribe = (l: () => void) => { listeners.add(l); return () => listeners.delete(l) }
  const useValue = () => useSyncExternalStore(subscribe, get, () => fallback)
  return { get, set, useValue }
}

export type Engine = 'groq' | 'gemini'
export type LeoSettings = { engine: Engine; voiceReplies: boolean; autoSend: boolean }
const DEFAULT_SETTINGS: LeoSettings = { engine: 'groq', voiceReplies: true, autoSend: true }
export const settingsStore = createLocalStore<LeoSettings>('leo-settings', DEFAULT_SETTINGS)
export const updateSettings = (patch: Partial<LeoSettings>) => settingsStore.set({ ...settingsStore.get(), ...patch })

export type MessageRole = 'user' | 'assistant'
export type ToolOutput = { ok: boolean; message: string }
export type LeoMessage = {
  id: string; role: MessageRole; text: string; tool?: 'openApp' | 'makeCall';
  toolInput?: { appName?: string; contactName?: string; phoneNumber?: string };
  toolOutput?: ToolOutput
}
export type StoredChat = { id: string; title: string; updatedAt: number; messages: LeoMessage[] }
const EMPTY_CHATS: StoredChat[] = []
export const chatsStore = createLocalStore<StoredChat[]>('leo-chats', EMPTY_CHATS)
export function chatTitle(messages: LeoMessage[]) {
  const first = messages.find((m) => m.role === 'user')
  return first?.text.trim().slice(0, 60) || 'New chat'
}
export function saveChat(id: string, messages: LeoMessage[]) {
  const others = chatsStore.get().filter((c) => c.id !== id)
  chatsStore.set([{ id, title: chatTitle(messages), updatedAt: Date.now(), messages }, ...others])
}
export const deleteChat = (id: string) => chatsStore.set(chatsStore.get().filter((c) => c.id !== id))
export const clearChats = () => chatsStore.set(EMPTY_CHATS)
