import type { Engine, LeoMessage } from './leo-store'

const SYSTEM_PROMPT = `You are Leo, a calm, concise personal AI assistant living on the user's Android phone.
Keep replies short and natural (1-3 sentences) because they are often read aloud.
No markdown tables or heavy formatting.
If the user asks to open an app or call someone, the app handles those commands locally.`

const GROQ_KEY = import.meta.env.VITE_GROQ_API_KEY as string | undefined
const GEMINI_KEY = import.meta.env.VITE_GEMINI_API_KEY as string | undefined

function modelMessages(messages: LeoMessage[]) {
  return messages.filter(m => !m.tool).map(m => ({ role: m.role, content: m.text }))
}

export async function askLeo(messages: LeoMessage[], engine: Engine): Promise<string> {
  const preferred = engine === 'gemini' ? 'gemini' : 'groq'
  const active = preferred === 'groq' ? (GROQ_KEY ? 'groq' : 'gemini') : (GEMINI_KEY ? 'gemini' : 'groq')
  if (active === 'groq' && !GROQ_KEY) throw new Error('Add VITE_GROQ_API_KEY to the build environment.')
  if (active === 'gemini' && !GEMINI_KEY) throw new Error('Add VITE_GEMINI_API_KEY to the build environment.')

  if (active === 'groq') {
    const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${GROQ_KEY}` },
      body: JSON.stringify({ model: 'openai/gpt-oss-120b', messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...modelMessages(messages)], temperature: 0.7 }),
    })
    const data = await res.json()
    if (!res.ok) throw new Error(data?.error?.message || 'Groq request failed')
    return data.choices?.[0]?.message?.content?.trim() || 'I could not generate a reply.'
  }

  const contents = modelMessages(messages).map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }))
  const res = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent', {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_KEY! },
    body: JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] }, contents, generationConfig: { temperature: 0.7 } }),
  })
  const data = await res.json()
  if (!res.ok) throw new Error(data?.error?.message || 'Gemini request failed')
  return data.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text || '').join('').trim() || 'I could not generate a reply.'
}

export async function transcribeAudio(blob: Blob): Promise<string> {
  if (!GROQ_KEY) throw new Error('Voice transcription needs VITE_GROQ_API_KEY in the build environment.')
  if (blob.size > 20 * 1024 * 1024) throw new Error('Audio too large')
  const form = new FormData()
  const ext = blob.type.includes('mp4') ? 'm4a' : blob.type.includes('ogg') ? 'ogg' : 'webm'
  form.append('file', blob, `voice.${ext}`)
  form.append('model', 'whisper-large-v3-turbo')
  const res = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
    method: 'POST', headers: { Authorization: `Bearer ${GROQ_KEY}` }, body: form,
  })
  const data = await res.json()
  if (!res.ok) throw new Error(data?.error?.message || 'Transcription failed')
  return String(data.text || '').trim()
}
