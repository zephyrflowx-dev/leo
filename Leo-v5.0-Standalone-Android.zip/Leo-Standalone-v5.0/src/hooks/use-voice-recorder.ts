import { useCallback, useRef, useState } from 'react'
import { transcribeAudio } from '../lib/api'

type RecorderState = 'idle' | 'recording' | 'transcribing'
const SILENCE_MS = 1400, SPEECH_LEVEL = 0.025, MAX_RECORDING_MS = 30000

export function useVoiceRecorder(onTranscript: (text: string) => void, { autoStop }: { autoStop: boolean }) {
  const [state, setState] = useState<RecorderState>('idle')
  const [error, setError] = useState<string | null>(null)
  const recorderRef = useRef<MediaRecorder | null>(null); const chunksRef = useRef<Blob[]>([]); const cleanupRef = useRef<() => void>(() => {})
  const autoStopRef = useRef(autoStop); autoStopRef.current = autoStop
  const stop = useCallback(() => { if (recorderRef.current?.state === 'recording') recorderRef.current.stop() }, [])
  const watchForSilence = useCallback((stream: MediaStream) => {
    const ctx = new AudioContext(), analyser = ctx.createAnalyser(); analyser.fftSize = 1024; ctx.createMediaStreamSource(stream).connect(analyser)
    const samples = new Float32Array(analyser.fftSize), startedAt = Date.now(); let heardSpeech = false, lastLoudAt = startedAt
    const interval = setInterval(() => {
      analyser.getFloatTimeDomainData(samples); let sum = 0; for (const s of samples) sum += s*s
      const level = Math.sqrt(sum / samples.length), now = Date.now(); if (level > SPEECH_LEVEL) { heardSpeech = true; lastLoudAt = now }
      if ((autoStopRef.current && heardSpeech && now-lastLoudAt > SILENCE_MS) || now-startedAt > MAX_RECORDING_MS) stop()
    }, 100)
    return () => { clearInterval(interval); ctx.close().catch(() => {}) }
  }, [stop])
  const start = useCallback(async () => {
    setError(null)
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mimeType = ['audio/webm', 'audio/mp4', 'audio/ogg'].find(t => MediaRecorder.isTypeSupported(t))
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined)
      chunksRef.current = []; recorder.ondataavailable = e => e.data.size && chunksRef.current.push(e.data)
      recorder.onstop = async () => {
        cleanupRef.current(); stream.getTracks().forEach(t => t.stop()); const type = recorder.mimeType || 'audio/webm'; const blob = new Blob(chunksRef.current, { type })
        if (blob.size < 1000) { setState('idle'); return }
        setState('transcribing')
        try { const text = await transcribeAudio(blob); if (text) onTranscript(text) } catch (e) { setError((e as Error).message) } finally { setState('idle') }
      }
      recorderRef.current = recorder; recorder.start(); cleanupRef.current = watchForSilence(stream); setState('recording')
    } catch { setError('Microphone permission is needed to talk to Leo.'); setState('idle') }
  }, [onTranscript, watchForSilence])
  return { state, error, start, stop }
}
