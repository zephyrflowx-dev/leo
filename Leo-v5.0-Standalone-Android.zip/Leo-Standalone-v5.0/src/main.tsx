import React from 'react'
import ReactDOM from 'react-dom/client'
import { LeoAssistant } from './components/leo/leo-assistant'
import './styles.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode><LeoAssistant /></React.StrictMode>,
)
