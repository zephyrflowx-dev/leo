import { useCallback, useEffect, useRef, useState } from 'react'
import { LeoHeader } from './leo-header'
import { MessageList } from './message-list'
import { Composer } from './composer'
import { ChatHistory } from './chat-history'
import { SettingsPanel } from './settings-panel'
import { detectDeviceCommand, makeCall, openApp, speak, stopSpeaking } from '../../lib/device'
import { askLeo } from '../../lib/api'
import { saveChat, settingsStore, updateSettings, type LeoMessage, type StoredChat } from '../../lib/leo-store'
import { useVoiceRecorder } from '../../hooks/use-voice-recorder'

const newId = () => crypto.randomUUID()

export function LeoAssistant() {
  const settings = settingsStore.useValue(); const [chatId, setChatId] = useState(newId); const [historyOpen, setHistoryOpen] = useState(false); const [settingsOpen, setSettingsOpen] = useState(false)
  const [messages, setMessages] = useState<LeoMessage[]>([]); const [busy, setBusy] = useState(false); const [error, setError] = useState<string | null>(null); const savedKeyRef = useRef('')
  useEffect(() => { if (!busy && messages.length) { const key=`${chatId}:${messages.length}`; if(savedKeyRef.current!==key){savedKeyRef.current=key; saveChat(chatId,messages)} } }, [busy,messages,chatId])
  const send = useCallback(async (text: string) => {
    const value=text.trim(); if(!value || busy)return; setError(null); await stopSpeaking()
    const user: LeoMessage={id:newId(),role:'user',text:value}; const next=[...messages,user]; setMessages(next); setBusy(true)
    try {
      const command=detectDeviceCommand(value)
      if(command?.type==='openApp') { const result=await openApp(command.appName); setMessages(prev=>[...prev,{id:newId(),role:'assistant',text:'',tool:'openApp',toolInput:{appName:command.appName},toolOutput:result}]); return }
      if(command?.type==='makeCall') { const result=await makeCall(command.contactName,command.phoneNumber); setMessages(prev=>[...prev,{id:newId(),role:'assistant',text:'',tool:'makeCall',toolInput:{contactName:command.contactName,phoneNumber:command.phoneNumber},toolOutput:result}]); return }
      const reply=await askLeo(next,settings.engine); setMessages(prev=>[...prev,{id:newId(),role:'assistant',text:reply}]); if(settingsStore.get().voiceReplies) speak(reply)
    } catch(e){ setError((e as Error).message) } finally { setBusy(false) }
  }, [busy,messages,settings.engine])
  const recorder=useVoiceRecorder(send,{autoStop:settings.autoSend})
  const openChat=(id:string,msgs:StoredChat['messages'])=>{stopSpeaking();setChatId(id);setMessages(msgs);setError(null);savedKeyRef.current=`${id}:${msgs.length}`}
  const startNewChat=()=>openChat(newId(),[])
  return <div className="mx-auto flex h-dvh w-full max-w-xl flex-col">
    <LeoHeader engine={settings.engine} onEngineChange={engine=>updateSettings({engine})} voiceReplies={settings.voiceReplies} onVoiceRepliesChange={v=>{updateSettings({voiceReplies:v});if(!v)stopSpeaking()}} onReset={messages.length?startNewChat:undefined} onOpenHistory={()=>setHistoryOpen(true)} onOpenSettings={()=>setSettingsOpen(true)}/>
    <MessageList messages={messages} busy={busy} recording={recorder.state==='recording'} error={error??recorder.error} onSuggestion={send}/>
    <Composer onSend={send} busy={busy} recorderState={recorder.state} onMicStart={()=>{stopSpeaking();recorder.start()}} onMicStop={recorder.stop}/>
    <ChatHistory open={historyOpen} onClose={()=>setHistoryOpen(false)} activeId={chatId} onSelect={chat=>{openChat(chat.id,chat.messages);setHistoryOpen(false)}} onNewChat={()=>{startNewChat();setHistoryOpen(false)}}/>
    <SettingsPanel open={settingsOpen} onClose={()=>setSettingsOpen(false)} onChatsCleared={startNewChat}/>
  </div>
}
