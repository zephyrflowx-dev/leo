import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'app.leo.assistant',
  appName: 'Leo',
  webDir: 'dist',
  backgroundColor: '#06090d',
  android: {
    allowMixedContent: false,
  },
}

export default config
