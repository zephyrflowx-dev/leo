package com.leo.assistant

import android.Manifest
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == RESULT_OK && t != null) send(t)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (12 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val title = TextView(this).apply {
            text = "Leo"; textSize = 28f; setTypeface(null, Typeface.BOLD)
        }
        log = TextView(this).apply {
            textSize = 16f
            text = "Hi, I'm Leo. Ask me anything, or try: open Instagram, call Mom, search pizza near me.\n\n"
        }
        scroll = ScrollView(this).apply { addView(log) }
        input = EditText(this).apply { hint = "Ask Leo or search..."; setSingleLine() }
        val mic = Button(this).apply { text = "Mic"; setOnClickListener { listen() } }
        val sendBtn = Button(this).apply {
            text = "Send"
            setOnClickListener { send(input.text.toString()); input.setText("") }
        }
        val settings = Button(this).apply { text = "AI keys"; setOnClickListener { keyDialog() } }
        val wake = Switch(this).apply {
            text = "Hands-free: say \"Hey Leo\""
            setOnCheckedChangeListener { _, on ->
                val i = Intent(this@MainActivity, WakeService::class.java)
                if (on) ContextCompat.startForegroundService(this@MainActivity, i)
                else stopService(i)
            }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(mic)
            addView(sendBtn)
        }
        root.addView(title)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(wake)
        root.addView(row)
        root.addView(settings)
        setContentView(root)

        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1)
    }

    private fun append(s: String) {
        log.append(s + "\n\n")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun send(text: String) {
        if (text.isBlank()) return
        append("You: $text")
        LeoCore.handle(this, text) { r ->
            runOnUiThread { append("Leo: $r"); LeoCore.speak(this, r) }
        }
    }

    private fun listen() {
        try {
            voice.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            )
        } catch (e: Exception) {
            append("Voice input isn't available on this phone.")
        }
    }

    private fun keyDialog() {
        val ids = listOf("anthropic", "gemini", "groq", "openrouter")
        val names = listOf("Anthropic (Claude)", "Google Gemini", "Groq", "OpenRouter")
        val prefs = getSharedPreferences("leo", 0)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
        val spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names)
            setSelection(ids.indexOf(prefs.getString("provider", "anthropic")).coerceAtLeast(0))
        }
        box.addView(TextView(this).apply { text = "Use this AI:" })
        box.addView(spin)
        val fields = ids.mapIndexed { n, id ->
            EditText(this).apply { hint = names[n] + " key"; setText(prefs.getString("key_$id", "")); setSingleLine() }
                .also { box.addView(it) }
        }
        AlertDialog.Builder(this)
            .setTitle("AI keys")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save") { _, _ ->
                val ed = prefs.edit().putString("provider", ids[spin.selectedItemPosition])
                ids.forEachIndexed { n, id -> ed.putString("key_$id", fields[n].text.toString().trim()) }
                ed.apply()
                append("Saved. Now using ${names[spin.selectedItemPosition]}.")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
