package com.leo.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class WakeService : Service() {
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var awaiting = false
    private var running = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("leo", "Leo", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "leo")
            .setContentTitle("Leo is listening for \"Hey Leo\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        running = true
        listen()
        return START_STICKY
    }

    private fun again(ms: Long) {
        if (running) h.postDelayed({ listen() }, ms)
    }

    private fun listen() {
        if (!running) return
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(e: Int) { again(1000) }
                override fun onResults(r: Bundle?) {
                    val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.trim() ?: ""
                    var cmd = ""
                    if (awaiting) {
                        cmd = text
                        awaiting = false
                    } else {
                        val m = Regex("\\bleo\\b", RegexOption.IGNORE_CASE).find(text)
                        if (m != null) {
                            cmd = text.substring(m.range.last + 1).trim().trimStart(',', '.')
                            if (cmd.isBlank()) {
                                awaiting = true
                                LeoCore.speak(this@WakeService, "Yes?")
                                again(1500)
                                return
                            }
                        }
                    }
                    if (cmd.isNotBlank()) {
                        LeoCore.handle(this@WakeService, cmd) { reply ->
                            LeoCore.speak(this@WakeService, reply)
                        }
                        again(5000)
                    } else again(500)
                }
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            )
        }
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        super.onDestroy()
    }
}
