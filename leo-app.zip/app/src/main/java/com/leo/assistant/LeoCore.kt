package com.leo.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.speech.tts.TextToSpeech
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread

object LeoCore {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private val history = mutableListOf<Pair<String, String>>()
    private const val SYS = "You are Leo, a warm, helpful personal voice assistant. Keep replies short and easy to say out loud."

    fun speak(c: Context, text: String) {
        if (tts == null) {
            tts = TextToSpeech(c.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.getDefault()
                    ready = true
                    pending?.let { p -> tts?.speak(p, TextToSpeech.QUEUE_FLUSH, null, "leo") }
                    pending = null
                }
            }
        }
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "leo") else pending = text
    }

    fun handle(c: Context, input: String, cb: (String) -> Unit) {
        val t = input.trim()
        val l = t.lowercase(Locale.getDefault())
        val local: String? = when {
            l.startsWith("open ") -> openApp(c, t.substring(5).trim())
            l.startsWith("call ") -> callContact(c, t.substring(5).trim())
            l.startsWith("search ") -> web(c, t.substring(7).trim())
            else -> null
        }
        if (local != null) { cb(local); return }
        thread { cb(askAI(c, t)) }
    }

    private fun web(c: Context, q: String): String {
        val u = Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8"))
        c.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Searching for $q"
    }

    private fun openApp(c: Context, name: String): String {
        val pm = c.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val m = apps.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
            ?: return "I couldn't find an app called $name."
        val i = pm.getLaunchIntentForPackage(m.activityInfo.packageName)
            ?: return "I couldn't open $name."
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opening ${m.loadLabel(pm)}"
    }

    private fun granted(c: Context, p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    private fun callContact(c: Context, name: String): String {
        if (!granted(c, Manifest.permission.READ_CONTACTS) || !granted(c, Manifest.permission.CALL_PHONE))
            return "Please allow Contacts and Phone permissions for Leo."
        val cur = c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"), null
        )
        var number: String? = null
        cur?.use { if (it.moveToFirst()) number = it.getString(0) }
        val n = number ?: return "I couldn't find $name in your contacts."
        c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Calling $name"
    }

    private fun dropLastUser() {
        if (history.isNotEmpty() && history.last().first == "user") history.removeAt(history.size - 1)
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): JSONObject {
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.connectTimeout = 15000
        con.readTimeout = 60000
        con.doOutput = true
        con.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> con.setRequestProperty(k, v) }
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = con.responseCode
        val ok = code in 200..299
        val raw = (if (ok) con.inputStream else con.errorStream).bufferedReader().use { it.readText() }
        if (!ok) throw RuntimeException("The AI returned error $code")
        return JSONObject(raw)
    }

    private fun askAI(c: Context, text: String): String {
        val prefs = c.getSharedPreferences("leo", 0)
        val provider = prefs.getString("provider", "anthropic") ?: "anthropic"
        val key = (prefs.getString("key_$provider", "") ?: "").trim()
        if (key.isBlank()) return "Please add your $provider key in settings first."
        history.add("user" to text)
        try {
            val reply: String = when (provider) {
                "gemini" -> {
                    val contents = JSONArray()
                    history.forEach {
                        contents.put(JSONObject()
                            .put("role", if (it.first == "user") "user" else "model")
                            .put("parts", JSONArray().put(JSONObject().put("text", it.second))))
                    }
                    val body = JSONObject().put("contents", contents)
                        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS))))
                    post("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent",
                        mapOf("x-goog-api-key" to key), body)
                        .getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                }
                "groq", "openrouter" -> {
                    val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", SYS))
                    history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
                    val groq = provider == "groq"
                    val body = JSONObject()
                        .put("model", if (groq) "llama-3.3-70b-versatile" else "openrouter/auto")
                        .put("messages", msgs).put("max_tokens", 600)
                    post(if (groq) "https://api.groq.com/openai/v1/chat/completions"
                         else "https://openrouter.ai/api/v1/chat/completions",
                        mapOf("Authorization" to "Bearer $key"), body)
                        .getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                }
                else -> {
                    val msgs = JSONArray()
                    history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
                    val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 600)
                        .put("system", SYS).put("messages", msgs)
                    post("https://api.anthropic.com/v1/messages",
                        mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body)
                        .getJSONArray("content").getJSONObject(0).getString("text")
                }
            }
            history.add("assistant" to reply)
            while (history.size > 20) { history.removeAt(0); history.removeAt(0) }
            return reply
        } catch (e: Exception) {
            dropLastUser()
            return "Sorry, that didn't work: ${e.message ?: "no connection"}. Check your key and internet."
        }
    }
}
