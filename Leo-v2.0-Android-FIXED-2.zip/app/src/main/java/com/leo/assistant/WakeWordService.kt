package com.leo.assistant

import android.Manifest
import android.app.*
import android.content.pm.ServiceInfo
import android.content.*
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.*
import android.speech.*
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable
import java.util.Locale

class WakeWordService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var overlay: View? = null
    private var listeningForCommand = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(42, notification("Hey Leo is on"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(42, notification("Hey Leo is on"))
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startWakeRecognition()
    }

    private fun startWakeRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle) {
                    val heard = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.joinToString(" ") ?: ""
                    val normalized = heard.lowercase(Locale.getDefault()).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
                    if (!listeningForCommand && normalized.contains("hey leo")) {
                        showOverlay()
                        val remainder = normalized.substringAfter("hey leo").trim()
                        if (remainder.isNotBlank()) {
                            listeningForCommand = true
                            handleCommandSpeech(remainder)
                        } else {
                            listeningForCommand = true
                            startCommandRecognition()
                        }
                    } else if (!listeningForCommand) {
                        restartWakeRecognition()
                    } else {
                        handleCommandSpeech(heard)
                    }
                }
                override fun onError(error: Int) { if (!listeningForCommand) restartWakeRecognition() else { hideOverlay(); listeningForCommand = false; restartWakeRecognition() } }
                override fun onReadyForSpeech(params: Bundle) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle) {}
                override fun onEvent(eventType: Int, params: Bundle) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        recognizer?.startListening(i)
    }

    private fun restartWakeRecognition() {
        Handler(Looper.getMainLooper()).postDelayed({ startWakeRecognition() }, 500)
    }

    private fun startCommandRecognition() {
        recognizer?.cancel()
        Handler(Looper.getMainLooper()).postDelayed({
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Listening to Leo")
            }
            recognizer?.startListening(i)
        }, 250)
    }

    private fun handleCommandSpeech(heard: String) {
        val command = heard.trim()
        hideOverlay()
        listeningForCommand = false
        val lower = command.lowercase(Locale.getDefault())
        when {
            lower.startsWith("open ") -> AppActions.openApp(this, command.substringAfter("open "))
            lower.startsWith("call ") -> AppActions.callContact(this, command.substringAfter("call "))
            else -> {
                val i = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    putExtra("voice_command", command)
                }
                startActivity(i)
            }
        }
        restartWakeRecognition()
    }

    private fun showOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        if (overlay != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 10, 10, 10)
            background = GradientDrawable().apply {
                setColor(android.graphics.Color.rgb(25, 25, 25))
                cornerRadius = 60f
                setStroke(1, android.graphics.Color.rgb(80, 80, 80))
            }
            addView(ImageView(this@WakeWordService).apply {
                setImageResource(R.drawable.leo_icon)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }, LinearLayout.LayoutParams(42, 42))
            addView(TextView(this@WakeWordService).apply {
                text = "Leo  ·  Listening"
                textSize = 15f
                setTextColor(android.graphics.Color.WHITE)
                setPadding(12, 0, 8, 0)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(ImageButton(this@WakeWordService).apply {
                setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
                setColorFilter(android.graphics.Color.WHITE)
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setOnClickListener { hideOverlay(); listeningForCommand = false; recognizer?.cancel(); restartWakeRecognition() }
            }, LinearLayout.LayoutParams(48, 48))
        }
        overlay = box
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 70 }
        getSystemService(WindowManager::class.java).addView(box, lp)
    }

    private fun hideOverlay() {
        overlay?.let { runCatching { getSystemService(WindowManager::class.java).removeView(it) } }
        overlay = null
    }

    override fun onDestroy() {
        hideOverlay()
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("leo_wake", "Leo wake word", NotificationManager.IMPORTANCE_LOW))
        }
    }
    private fun notification(text: String): Notification = Notification.Builder(this, "leo_wake")
        .setSmallIcon(R.drawable.leo_icon)
        .setContentTitle("Leo")
        .setContentText(text)
        .setOngoing(true)
        .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        .build()
}
