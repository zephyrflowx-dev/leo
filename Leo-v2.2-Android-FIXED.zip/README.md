# Leo v2.2

Changes in this build:
- Mic button uses Android SpeechRecognizer directly instead of launching the Google speech UI.
- Recognized speech is automatically sent to Leo.
- Assistant session listens directly after the system invokes Leo as the digital assistant and sends the recognized phrase to Leo.
- Added Settings > AI provider > Local GGUF.
- Added GGUF model picker, local model storage, Load/Unload controls, and llama.cpp native runtime integration.
- Local GGUF runs on arm64-v8a devices.
- Existing Gemini, OpenAI, calling, app opening, history, fonts, voice, themes and device-assistant settings are retained.

Build note: the GitHub Actions workflow downloads the current llama.cpp source while building the native runtime, so the first build can take longer than earlier Leo builds.

Android will continue to show its microphone privacy indicator whenever Leo is actively using the microphone. Leo does not attempt to hide or bypass that indicator.
