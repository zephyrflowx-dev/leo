package com.leo.assistant

object LocalLlama {
    init { System.loadLibrary("leo_native") }
    external fun nativeLoad(path: String): String
    external fun nativeUnload()
    external fun nativeGenerate(prompt: String): String
    fun load(path: String): String = nativeLoad(path)
    fun unload() = nativeUnload()
    fun generate(prompt: String): String = nativeGenerate(prompt)
}
