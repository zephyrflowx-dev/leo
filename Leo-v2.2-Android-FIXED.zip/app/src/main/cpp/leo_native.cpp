#include <jni.h>
#include <string>
#include <vector>
#include <cstring>
#include <mutex>
#include <llama.h>

static llama_model * g_model = nullptr;
static std::mutex g_mutex;

extern "C" JNIEXPORT jstring JNICALL
Java_com_leo_assistant_LocalLlama_nativeLoad(JNIEnv *env, jclass, jstring path_) {
    const char *path = env->GetStringUTFChars(path_, nullptr);
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_model) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    g_model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(path_, path);
    if (!g_model) return env->NewStringUTF("Failed to load GGUF model. The model may be unsupported or too large for this device.");
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT void JNICALL
Java_com_leo_assistant_LocalLlama_nativeUnload(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_model) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_leo_assistant_LocalLlama_nativeGenerate(JNIEnv *env, jclass, jstring prompt_) {
    const char *prompt = env->GetStringUTFChars(prompt_, nullptr);
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model) {
        env->ReleaseStringUTFChars(prompt_, prompt);
        return env->NewStringUTF("Load a Local GGUF model first in Settings.");
    }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = 2048;
    cp.n_batch = 512;
    cp.n_threads = 4;
    cp.n_threads_batch = 4;
    llama_context *ctx = llama_init_from_model(g_model, cp);
    if (!ctx) {
        env->ReleaseStringUTFChars(prompt_, prompt);
        return env->NewStringUTF("Leo could not create a context for this model.");
    }

    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    int32_t n = llama_tokenize(vocab, prompt, (int32_t)strlen(prompt), nullptr, 0, true, true);
    if (n < 0) n = -n;
    std::vector<llama_token> tokens((size_t)n);
    int32_t got = llama_tokenize(vocab, prompt, (int32_t)strlen(prompt), tokens.data(), n, true, true);
    if (got < 0) {
        llama_free(ctx);
        env->ReleaseStringUTFChars(prompt_, prompt);
        return env->NewStringUTF("Leo could not tokenize that message.");
    }

    llama_sampler_chain_params sp = llama_sampler_chain_default_params();
    llama_sampler *sampler = llama_sampler_chain_init(sp);
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    llama_batch batch = llama_batch_get_one(tokens.data(), (int32_t)tokens.size());
    std::string output;
    if (llama_decode(ctx, batch) != 0) {
        llama_sampler_free(sampler);
        llama_free(ctx);
        env->ReleaseStringUTFChars(prompt_, prompt);
        return env->NewStringUTF("Leo could not run this GGUF model.");
    }

    for (int i = 0; i < 256; ++i) {
        llama_token id = llama_sampler_sample(sampler, ctx, -1);
        if (llama_vocab_is_eog(vocab, id)) break;
        char buf[256];
        int m = llama_token_to_piece(vocab, id, buf, sizeof(buf), 0, true);
        if (m > 0) output.append(buf, (size_t)m);
        llama_sampler_accept(sampler, id);
        llama_batch next = llama_batch_get_one(&id, 1);
        if (llama_decode(ctx, next) != 0) break;
    }

    llama_sampler_free(sampler);
    llama_free(ctx);
    env->ReleaseStringUTFChars(prompt_, prompt);
    return env->NewStringUTF(output.c_str());
}

jint JNI_OnLoad(JavaVM *vm, void *) {
    llama_backend_init();
    return JNI_VERSION_1_6;
}
