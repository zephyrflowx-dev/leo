# Leo v3.4.0

Personal Android AI assistant.

## v3.2 upgrades
- v3.1 on-device openWakeWord/ONNX wake-word engine remains enabled.
- Conversation memory: the latest 20 saved messages are sent to normal AI turns with a Leo system prompt.
- Gemini Live receives the same recent conversation context plus a concise voice-assistant system prompt.
- Gemini Live waits for `setupComplete` before microphone streaming, uses 20–40 ms-class PCM chunks, correct 16-bit RMS calculation for local barge-in detection, and enables input/output transcription.
- Gemini Live enables server context-window compression.
- Phone calls now require an explicit confirmation dialog before dialing.
- `android:allowBackup="false"` is set because API keys are stored locally.
- API errors already expose the provider/status/detail rather than a generic internet message.

## Wake word
The wake listener uses openWakeWord Android/ONNX locally. The exact `Hey Leo` phrase requires a compatible `hey_leo.onnx` model in `app/src/main/assets/`. Without it, the bundled `Hey Jarvis` model is used for engine testing.

## Live audio
Gemini Live uses a persistent WebSocket and raw 16-bit PCM audio. The current implementation keeps the microphone privacy indicator and foreground-service notification visible.

## Build
GitHub Actions is configured to build `:app:assembleDebug` and upload the APK artifact. A local Android/Gradle build was not available in the packaging environment, so the GitHub Actions run is the authoritative compile test.


## v3.4.0 Voice-first UI and stability fixes
- Large animated Leo orb with idle, listening, thinking, and speaking states.
- Unified bottom voice control: tap to talk, tap again to stop.
- Keyboard entry is tucked behind a small keyboard button.
- Quiet top bar with Leo logo and one menu containing New chat, History, and Settings.
- Leo replies use full-width plain text; user messages use subtle bubbles.
- Empty state includes action suggestion chips.
- Direct phone actions show a compact action confirmation chip.
- Wake-triggered Live mode uses a bottom-sheet-style overlay instead of a full-screen takeover.
- Added JitPack repository for the openWakeWord Android dependency.
- Live WebSocket reconnects with bounded exponential backoff.
- Live startup posts a visible notification when microphone, overlay, or Gemini API key setup is missing.
- Gemini Live audio remains 16 kHz mono PCM input and 24 kHz mono PCM output.

Android build note: the project still requires a real Android/Gradle environment (for example GitHub Actions) to verify compilation and dependency resolution.

## v3.4.0 additions
- Fixed the missing closing brace that caused the v3.3.x Kotlin compile failure around `SettingsSection`.
- Version bumped to 3.4.0 / versionCode 44.
- Added direct web-search voice commands such as `search cats`, `search the web for ...`, and `google ...`.
- Wake-word listening defaults to off until explicitly enabled in Settings.
- Retains voice-first orb UI, unified mic/Live control, keyboard fallback, Gemini/OpenAI/Anthropic provider switching, encrypted local keys, file/image attachments, chat history, TTS voice selection, phone-call confirmation, app opening, system-assistant integration, Live mode, local wake-word engine, and visible microphone/foreground-service indicators.

Note: exact `Hey Leo` detection still requires a compatible custom `hey_leo.onnx` model in `app/src/main/assets/`; the app does not hide Android microphone indicators.
