# Leo v5.0 GitHub ZIP builder

The Android source is stored in `leo-source.zip`. The GitHub Actions workflow extracts it automatically and builds `Leo.apk`.

IMPORTANT:
GitHub does not execute a workflow that is hidden inside an uploaded ZIP. The workflow file must exist in the repository itself. Therefore, this package is a one-ZIP-source setup once the workflow has been placed in the repository.
