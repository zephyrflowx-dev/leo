package com.leo.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import java.util.Locale

object AppActions {
    fun openApp(ctx: Context, requested: String): String {
        val name = requested.trim()
        val lower = name.lowercase(Locale.getDefault())
        val aliases = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "chrome" to "com.android.chrome",
            "instagram" to "com.instagram.android",
            "settings" to "com.android.settings",
            "play store" to "com.android.vending",
            "google maps" to "com.google.android.apps.maps",
            "maps" to "com.google.android.apps.maps",
            "gmail" to "com.google.android.gm"
        )
        val packages = mutableListOf<String>()
        aliases[lower]?.let { packages.add(it) }
        if (packages.isEmpty()) {
            val pm = ctx.packageManager
            val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val match = apps.firstOrNull {
                val label = pm.getApplicationLabel(it).toString().lowercase(Locale.getDefault())
                label == lower || label.contains(lower)
            }
            if (match != null) packages.add(match.packageName)
        }
        for (pkg in packages) {
            val intent = ctx.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                return "Opening $name."
            }
        }
        return "I couldn't find $name on this phone."
    }

    fun callContact(ctx: Context, name: String): Pair<Boolean, String> {
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return false to "I need contact permission to find that person."
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        ctx.contentResolver.query(
            uri,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        )?.use {
            if (it.moveToFirst()) {
                val number = it.getString(0)
                if (ctx.checkSelfPermission(android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
                    return false to "I need phone permission before placing the call."
                ctx.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true to "Calling ${it.getString(1)}."
            }
        }
        return false to "I couldn't find a contact named $name."
    }
}
