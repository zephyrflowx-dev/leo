package com.leo.assistant

import android.Manifest
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.view.Window
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.animation.core.*
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.window.Dialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

data class Msg(val text: String, val user: Boolean)
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class LeoFont { SYSTEM, SANS, SERIF, MONO, CURSIVE }

class MainActivity : ComponentActivity() {
    private var incomingVoice by mutableStateOf("")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureBars(window)
        incomingVoice = intent?.getStringExtra("voice_command").orEmpty()
        setContent { LeoApp(incomingVoice) { incomingVoice = "" } }
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incomingVoice = intent.getStringExtra("voice_command").orEmpty()
    }
}

private fun configureBars(window: Window) {
    window.navigationBarColor = android.graphics.Color.TRANSPARENT
    window.statusBarColor = android.graphics.Color.TRANSPARENT
    if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
}

@Composable
private fun LeoTheme(mode: ThemeMode, dynamic: Boolean, font: LeoFont, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val ctx = LocalContext.current
    val colors = if (dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else if (dark) {
        darkColorScheme(background = Color(0xFF0B0B0B), surface = Color(0xFF121212), surfaceContainer = Color(0xFF1A1A1A))
    } else {
        lightColorScheme(background = Color(0xFFF7F7F5), surface = Color(0xFFFFFFFF), surfaceContainer = Color(0xFFF0F0EE))
    }
    val family = when (font) {
        LeoFont.SYSTEM -> FontFamily.Default
        LeoFont.SANS -> FontFamily.SansSerif
        LeoFont.SERIF -> FontFamily.Serif
        LeoFont.MONO -> FontFamily.Monospace
        LeoFont.CURSIVE -> FontFamily.Cursive
    }
    val base = Typography()
    val typography = base.copy(
        headlineLarge = base.headlineLarge.copy(fontFamily = family),
        headlineMedium = base.headlineMedium.copy(fontFamily = family),
        titleLarge = base.titleLarge.copy(fontFamily = family),
        titleMedium = base.titleMedium.copy(fontFamily = family),
        bodyLarge = base.bodyLarge.copy(fontFamily = family),
        bodyMedium = base.bodyMedium.copy(fontFamily = family),
        bodySmall = base.bodySmall.copy(fontFamily = family),
        labelLarge = base.labelLarge.copy(fontFamily = family)
    )
    MaterialTheme(colorScheme = colors, typography = typography, content = content)
}

private sealed class CommandResult {
    data class Done(val text: String) : CommandResult()
    data object None : CommandResult()
    data object NeedContacts : CommandResult()
    data object NeedCall : CommandResult()
}

private fun handleCommand(ctx: Context, text: String): CommandResult {
    val lower = text.trim().lowercase(Locale.getDefault())
    if (lower.startsWith("open ")) return CommandResult.Done(AppActions.openApp(ctx, text.trim().substringAfter(" ")))
    if (lower == "open youtube") return CommandResult.Done(AppActions.openApp(ctx, "YouTube"))
    if (lower.startsWith("call ")) {
        val name = text.trim().substringAfter(" ").trim()
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return CommandResult.NeedContacts
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return CommandResult.NeedCall
        return CommandResult.Done(AppActions.callContact(ctx, name).second)
    }
    return CommandResult.None
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LeoApp(incomingVoice: String, onVoiceConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { SecureStore(ctx) }
    val chatStore = remember { ChatStore(ctx) }
    val scope = rememberCoroutineScope()
    var provider by remember { mutableStateOf(store.get("provider").ifBlank { "Gemini" }) }
    var openai by remember { mutableStateOf(store.get("openai")) }
    var gemini by remember { mutableStateOf(store.get("gemini")) }
    var anthropic by remember { mutableStateOf(store.get("anthropic")) }
    var input by remember { mutableStateOf("") }
    var screen by remember { mutableStateOf("home") }
    var busy by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    var speaking by remember { mutableStateOf(false) }
    var actionLabel by remember { mutableStateOf<String?>(null) }
    var showKeyboard by remember { mutableStateOf(false) }
    var pendingCallName by remember { mutableStateOf<String?>(null) }
    var theme by remember { mutableStateOf(runCatching { ThemeMode.valueOf(store.get("theme").ifBlank { "SYSTEM" }) }.getOrDefault(ThemeMode.SYSTEM)) }
    var dynamic by remember { mutableStateOf(store.get("dynamic_color") != "false") }
    var voiceReplies by remember { mutableStateOf(false) }
    var liveMode by remember { mutableStateOf(store.get("live_mode") == "true") }
    var hotwordEnabled by remember { mutableStateOf(store.get("hotword_enabled").ifBlank { "true" } == "true") }
    var font by remember { mutableStateOf(runCatching { LeoFont.valueOf(store.get("font").ifBlank { "SYSTEM" }) }.getOrDefault(LeoFont.SYSTEM)) }
    var selectedVoice by remember { mutableStateOf(store.get("tts_voice")) }
    var speechResult by remember { mutableStateOf("") }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var voices by remember { mutableStateOf<List<Voice>>(emptyList()) }
    val messages = remember { mutableStateListOf<Msg>().apply { addAll(chatStore.load()) } }
    var attachments by remember { mutableStateOf<List<AiAttachment>>(emptyList()) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        attachments = uris.mapNotNull { uri -> readAttachment(ctx, uri) }.take(6)
    }

    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine?.language = Locale.getDefault()
                tts = engine
                voices = engine?.voices?.filter { !it.isNetworkConnectionRequired }?.sortedBy { it.name.lowercase(Locale.getDefault()) }.orEmpty()
            }
        }
        onDispose { engine?.stop(); engine?.shutdown(); tts = null }
    }

    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == LiveAssistantService.ACTION_STATE) {
                    val on = intent.getBooleanExtra(LiveAssistantService.EXTRA_LIVE, false)
                    liveMode = on
                    store.put("live_mode", on.toString())
                    if (!on) messages.clear().also { messages.addAll(chatStore.load()) }
                }
            }
        }
        val filter = IntentFilter(LiveAssistantService.ACTION_STATE)
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") ctx.registerReceiver(receiver, filter)
        onDispose { runCatching { ctx.unregisterReceiver(receiver) } }
    }

    val speech = remember(ctx) {
        LeoSpeechController(ctx,
            onResult = { speechResult = it },
            onError = { listening = false; android.widget.Toast.makeText(ctx, it, android.widget.Toast.LENGTH_SHORT).show() },
            onListeningChanged = { listening = it }
        )
    }
    DisposableEffect(speech) { onDispose { speech.stop() } }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(ctx)) ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            else { store.put("live_mode", "true"); liveMode = true; LiveAssistantService.start(ctx) }
        }
    }
    val contactsPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val callPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun save() = chatStore.save(messages)
    fun speak(text: String) {
        val engine = tts ?: return
        if (selectedVoice.isNotBlank()) engine.voices?.firstOrNull { it.name == selectedVoice }?.let { engine.voice = it }
        speaking = true
        engine.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { speaking = true }
            override fun onDone(utteranceId: String?) { speaking = false }
            override fun onError(utteranceId: String?) { speaking = false }
        })
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "leo")
    }
    fun send(textValue: String = input) {
        val text = textValue.trim()
        if ((text.isEmpty() && attachments.isEmpty()) || busy) return
        val attachmentSummary = if (attachments.isEmpty()) "" else "\n\nAttachments: " + attachments.joinToString(", ") { it.name }
        input = ""
        showKeyboard = false
        actionLabel = null
        messages.add(Msg(if (text.isBlank()) "Attached files${attachmentSummary}" else text + attachmentSummary, true)); save(); busy = true
        val currentAttachments = attachments
        attachments = emptyList()
        scope.launch {
            val lower = text.lowercase(Locale.getDefault())
            if (currentAttachments.isEmpty() && (lower.startsWith("call ") || lower.startsWith("ring "))) {
                val name = text.substringAfter(" ").trim()
                pendingCallName = name
                busy = false
                return@launch
            }
            val command = if (currentAttachments.isEmpty()) withContext(Dispatchers.Default) { handleCommand(ctx, text) } else CommandResult.None
            val reply = when (command) {
                is CommandResult.Done -> { actionLabel = command.text + " ✓"; command.text }
                CommandResult.NeedContacts -> { contactsPermission.launch(Manifest.permission.READ_CONTACTS); "I need contact permission to find that person." }
                CommandResult.NeedCall -> { callPermission.launch(Manifest.permission.CALL_PHONE); "I need phone permission before placing the call." }
                CommandResult.None -> withContext(Dispatchers.IO) {
                    val key = when (provider) { "OpenAI" -> openai; "Anthropic" -> anthropic; else -> gemini }
                    AiClient().ask(provider, key, if (text.isBlank()) "Please analyze the attached file(s)." else text, currentAttachments, messages.dropLast(1).takeLast(20))
                }
            }
            messages.add(Msg(reply, false)); save()
            busy = false
        }
    }

    LaunchedEffect(incomingVoice) {
        if (incomingVoice.isNotBlank()) { screen = "home"; send(incomingVoice); onVoiceConsumed() }
    }
    LaunchedEffect(speechResult) {
        val spoken = speechResult
        if (spoken.isNotBlank()) { speechResult = ""; send(spoken) }
    }

    if (pendingCallName != null) {
        AlertDialog(
            onDismissRequest = { pendingCallName = null },
            title = { Text("Confirm call") },
            text = { Text("Call ${pendingCallName}?") },
            confirmButton = {
                TextButton(onClick = {
                    val name = pendingCallName.orEmpty()
                    pendingCallName = null
                    scope.launch {
                        val result = withContext(Dispatchers.Default) { AppActions.callContact(ctx, name) }
                        messages.add(Msg(result.second, false)); save()
                    }
                }) { Text("Call") }
            },
            dismissButton = { TextButton(onClick = { pendingCallName = null }) { Text("Cancel") } }
        )
    }

    LeoTheme(theme, dynamic, font) {
        when (screen) {
            "settings" -> SettingsScreen(provider, { provider = it; store.put("provider", it) }, openai, { openai = it; store.put("openai", it) }, gemini, { gemini = it; store.put("gemini", it) }, anthropic, { anthropic = it; store.put("anthropic", it) }, theme, { theme = it; store.put("theme", it.name) }, dynamic, { dynamic = it; store.put("dynamic_color", it.toString()) }, false, { }, hotwordEnabled, { enabled -> hotwordEnabled = enabled; store.put("hotword_enabled", enabled.toString()); if (enabled) { if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) LeoHotwordService.start(ctx) } else LeoHotwordService.stop(ctx) }, font, { font = it; store.put("font", it.name) }, selectedVoice, voices, { selectedVoice = it; store.put("tts_voice", it) }, { speak("Hello, I'm Leo. This is my selected voice.") }, { openAssistantSettings(ctx) }, { messages.clear(); chatStore.clear(); save() }, { screen = "home" })
            "history" -> HistoryScreen(messages, { screen = "home" }, { messages.clear(); chatStore.clear(); save() })
            else -> HomeScreen(
                input, { input = it }, busy, listening, speaking, liveMode, messages, attachments, actionLabel, showKeyboard,
                { value -> input = value; showKeyboard = true },
                { filePicker.launch(arrayOf("*/*")) }, { i -> attachments = attachments.toMutableList().also { it.removeAt(i) } },
                { messages.clear(); chatStore.clear(); actionLabel = null }, { send() },
                {
                    if (liveMode) { LiveAssistantService.stop(ctx); liveMode = false }
                    else if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    else if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(ctx)) ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                    else { store.put("live_mode", "true"); liveMode = true; LiveAssistantService.start(ctx) }
                },
                { screen = "history" }, { screen = "settings" },
                { if (liveMode) { LiveAssistantService.stop(ctx); liveMode = false } else if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { micPermission.launch(Manifest.permission.RECORD_AUDIO) } else if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(ctx)) { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${ctx.packageName}"))) } else { store.put("live_mode", "true"); liveMode = true; LiveAssistantService.start(ctx) } },
                { showKeyboard = !showKeyboard }, { speak(it) }
            )
        }
    }
}

private fun openAssistantSettings(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 29) {
        val role = ctx.getSystemService(RoleManager::class.java)
        if (role?.isRoleAvailable(RoleManager.ROLE_ASSISTANT) == true) {
            runCatching { ctx.startActivity(role.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT)) }.onFailure { ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
            return
        }
    }
    runCatching { ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
}

private fun readAttachment(ctx: Context, uri: Uri): AiAttachment? {
    return runCatching {
        val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
        val name = uri.lastPathSegment?.substringAfterLast('/') ?: "attachment"
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        if (bytes.size > 10 * 1024 * 1024) return null
        AiAttachment(name, mime, bytes)
    }.getOrNull()
}

@Composable
private fun HomeScreen(
    input: String, onInput: (String) -> Unit, busy: Boolean, listening: Boolean, speaking: Boolean, liveMode: Boolean,
    messages: List<Msg>, attachments: List<AiAttachment>, actionLabel: String?, showKeyboard: Boolean,
    onSuggestion: (String) -> Unit, onPickFiles: () -> Unit, onRemoveAttachment: (Int) -> Unit, onNewChat: () -> Unit, onSend: () -> Unit, onVoice: () -> Unit,
    onHistory: () -> Unit, onSettings: () -> Unit, onLive: () -> Unit, onKeyboard: () -> Unit, onSay: (String) -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val state = when {
        speaking -> OrbState.SPEAKING
        busy -> OrbState.THINKING
        listening || liveMode -> OrbState.LISTENING
        else -> OrbState.IDLE
    }
    Scaffold(containerColor = MaterialTheme.colorScheme.background, topBar = {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.leo_icon), "Leo", Modifier.size(34.dp).clip(CircleShape), contentScale = ContentScale.Crop)
            Text("Leo", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(start = 9.dp))
            Box {
                IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.Menu, "Menu") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("New chat") }, leadingIcon = { Icon(Icons.Default.AddComment, null) }, onClick = { menuOpen = false; onNewChat() })
                    DropdownMenuItem(text = { Text("History") }, leadingIcon = { Icon(Icons.Default.History, null) }, onClick = { menuOpen = false; onHistory() })
                    DropdownMenuItem(text = { Text("Settings") }, leadingIcon = { Icon(Icons.Default.Settings, null) }, onClick = { menuOpen = false; onSettings() })
                }
            }
        }
    }) { padding ->
        val chatListState = rememberLazyListState()
        LaunchedEffect(messages.size) { if (messages.isNotEmpty()) chatListState.animateScrollToItem(messages.lastIndex) }
        Column(Modifier.fillMaxSize().padding(padding)) {
            Box(Modifier.fillMaxWidth().weight(1f)) {
                LazyColumn(state = chatListState, modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(top = 8.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val welcomeOnly = messages.size == 1 && !messages[0].user
                    if (welcomeOnly) item { Spacer(Modifier.height(280.dp)) }
                    items(messages) { msg ->
                        if (!(welcomeOnly && !msg.user)) Column(Modifier.fillMaxWidth(), horizontalAlignment = if (msg.user) Alignment.End else Alignment.Start) {
                            if (msg.user) {
                                Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = RoundedCornerShape(20.dp)) { Text(msg.text, Modifier.padding(horizontal = 14.dp, vertical = 10.dp), fontSize = 15.sp) }
                            } else {
                                Text(msg.text, Modifier.fillMaxWidth().padding(horizontal = 2.dp), fontSize = 16.sp, lineHeight = 23.sp)
                                IconButton(onClick = { onSay(msg.text) }, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.VolumeUp, "Say reply", Modifier.size(18.dp)) }
                            }
                        }
                    }
                    if (actionLabel != null) item { AssistChip(onClick = {}, label = { Text(actionLabel) }, leadingIcon = { Icon(Icons.Default.CheckCircle, null) }) }
                }
                if (messages.isEmpty() || (messages.size == 1 && !messages[0].user)) Box(Modifier.align(Alignment.TopCenter)) { VoiceWelcome(onSuggestion) }
            }
            if (messages.isNotEmpty()) Box(Modifier.fillMaxWidth().padding(bottom = 2.dp), contentAlignment = Alignment.Center) { LeoOrb(state, true) }
            Surface(color = MaterialTheme.colorScheme.background, tonalElevation = 0.dp) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (showKeyboard) {
                        if (attachments.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { attachments.forEachIndexed { i,a -> InputChip(true, { onRemoveAttachment(i) }, label={Text(a.name.take(18))}, trailingIcon={Icon(Icons.Default.Close, null, Modifier.size(15.dp))}) } }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onPickFiles) { Icon(Icons.Default.AttachFile, "Attach") }
                            OutlinedTextField(value = input, onValueChange = onInput, modifier = Modifier.weight(1f), placeholder = { Text("Message Leo…") }, maxLines = 3, shape = RoundedCornerShape(22.dp), trailingIcon = { IconButton(onClick = onSend, enabled = input.isNotBlank() || attachments.isNotEmpty()) { Icon(Icons.Default.Send, "Send") } })
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onKeyboard) { Icon(Icons.Default.Keyboard, "Keyboard") }
                        Spacer(Modifier.width(22.dp))
                        FilledIconButton(onClick = onVoice, modifier = Modifier.size(78.dp), shape = CircleShape) { Icon(if (listening || liveMode) Icons.Default.Stop else Icons.Default.Mic, if (listening || liveMode) "Stop" else "Talk", Modifier.size(36.dp)) }
                        Spacer(Modifier.width(22.dp))
                        Spacer(Modifier.size(48.dp))
                    }
                }
            }
        }
    }


enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

@Composable
private fun LeoOrb(state: OrbState, compact: Boolean = false) {
    val transition = rememberInfiniteTransition(label = "leo-orb")
    val pulse by transition.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(if (state == OrbState.IDLE) 2200 else 700), RepeatMode.Reverse), label = "pulse")
    val ripple by transition.animateFloat(0.84f, 1.22f, infiniteRepeatable(tween(950), RepeatMode.Restart), label = "ripple")
    val size = if (compact) 82.dp else 190.dp
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        if (state == OrbState.LISTENING) Box(Modifier.size(size * ripple).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)))
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, tonalElevation = 5.dp, modifier = Modifier.size(size * pulse)) {
            Box(contentAlignment = Alignment.Center) {
                Image(painterResource(R.drawable.leo_icon), "Leo", Modifier.fillMaxSize().padding(if (compact) 13.dp else 25.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                if (state == OrbState.THINKING) CircularProgressIndicator(Modifier.size(if (compact) 44.dp else 88.dp), strokeWidth = if (compact) 4.dp else 6.dp)
                if (state == OrbState.SPEAKING) Box(Modifier.size(if (compact) 68.dp else 145.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.11f)))
            }
        }
    }
}

@Composable
private fun VoiceWelcome(onSuggestion: (String) -> Unit, ignored: () -> Unit = {}) {
    Column(Modifier.fillMaxWidth().padding(top = 210.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        LeoOrb(OrbState.IDLE)
        Spacer(Modifier.height(10.dp))
        Text("What can Leo do?", fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text("Tap the mic and just talk.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Open YouTube", "Set alarm for 7", "Call Mum").forEach { label -> AssistChip(onClick = { onSuggestion(label) }, label = { Text(label) }) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun HistoryScreen(messages: List<Msg>, onBack: () -> Unit, onClear: () -> Unit) {
    Scaffold(topBar = { TopAppBar(navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }, title = { Text("History", fontWeight = FontWeight.Bold) }, actions = { IconButton(onClick = onClear) { Icon(Icons.Default.DeleteSweep, "Clear") } }) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (messages.isEmpty()) item { Text("No saved chats yet.") }
            items(messages) { m -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(14.dp)) { Text(if (m.user) "You" else "Leo", fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text(m.text) } } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun SettingsScreen(provider: String, onProvider: (String) -> Unit, openai: String, onOpenAi: (String) -> Unit, gemini: String, onGemini: (String) -> Unit, anthropic: String, onAnthropic: (String) -> Unit, theme: ThemeMode, onTheme: (ThemeMode) -> Unit, dynamic: Boolean, onDynamic: (Boolean) -> Unit, voiceReplies: Boolean, onVoiceReplies: (Boolean) -> Unit, hotwordEnabled: Boolean, onHotword: (Boolean) -> Unit, font: LeoFont, onFont: (LeoFont) -> Unit, selectedVoice: String, voices: List<Voice>, onVoice: (String) -> Unit, onTestVoice: () -> Unit, onAssistant: () -> Unit, onClear: () -> Unit, onBack: () -> Unit) {
    Scaffold(topBar = { TopAppBar(navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }, title = { Text("Settings", fontWeight = FontWeight.Bold) }) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { SettingsSection("Appearance", Icons.Default.Palette) { Text("Theme", fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { ThemeChip("System", theme == ThemeMode.SYSTEM) { onTheme(ThemeMode.SYSTEM) }; ThemeChip("Light", theme == ThemeMode.LIGHT) { onTheme(ThemeMode.LIGHT) }; ThemeChip("Dark", theme == ThemeMode.DARK) { onTheme(ThemeMode.DARK) } }; Spacer(Modifier.height(10.dp)); SettingSwitch("Use device dynamic colors", dynamic, onDynamic) } }
            item { SettingsSection("Fonts", Icons.Default.TextFields) { FontSelector(font, onFont) } }
            item { SettingsSection("Leo Voice", Icons.Default.RecordVoiceOver) { Text("Leo only speaks a reply when the speaker button is tapped.", style = MaterialTheme.typography.bodySmall); Spacer(Modifier.height(8.dp)); VoiceSelector(selectedVoice, voices, onVoice); Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = onTestVoice, Modifier.fillMaxWidth()) { Icon(Icons.Default.VolumeUp, null); Spacer(Modifier.width(8.dp)); Text("Test voice") } } }
            item { SettingsSection("Device Assistant", Icons.Default.Assistant) { Text("Set Leo as the phone's digital assistant.", style = MaterialTheme.typography.bodySmall); Spacer(Modifier.height(8.dp)); Button(onClick = onAssistant, Modifier.fillMaxWidth()) { Icon(Icons.Default.Assistant, null); Spacer(Modifier.width(8.dp)); Text("Set Leo as device assistant") } } }
            item { SettingsSection("Hey Leo", Icons.Default.Mic) { Text("Background wake-word listening uses the microphone while enabled. Android will show its microphone privacy indicator and Leo keeps a silent ongoing notification.", style = MaterialTheme.typography.bodySmall); Spacer(Modifier.height(8.dp)); SettingSwitch("Listen for Hey Leo", hotwordEnabled, onHotword) } }
            item { SettingsSection("AI Provider", Icons.Default.AutoAwesome) { Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { FilterChip(provider == "Gemini", { onProvider("Gemini") }, label = { Text("Gemini") }); FilterChip(provider == "OpenAI", { onProvider("OpenAI") }, label = { Text("OpenAI") }); FilterChip(provider == "Anthropic", { onProvider("Anthropic") }, label = { Text("Anthropic") }) } } }
            item { SettingsSection("API Keys", Icons.Default.Key) { Text("Keys are stored locally on this device.", style = MaterialTheme.typography.bodySmall); Spacer(Modifier.height(8.dp)); KeyField("OpenAI API key", openai, onOpenAi); Spacer(Modifier.height(8.dp)); KeyField("Gemini API key", gemini, onGemini); Spacer(Modifier.height(8.dp)); KeyField("Anthropic API key", anthropic, onAnthropic) } }
            item { SettingsSection("Chat", Icons.Default.Chat) { Text("Start a fresh conversation or clear all saved history.", style = MaterialTheme.typography.bodySmall); Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = onClear, Modifier.fillMaxWidth()) { Icon(Icons.Default.AddComment, null); Spacer(Modifier.width(8.dp)); Text("New chat") }; Spacer(Modifier.height(8.dp)); TextButton(onClick = onClear, Modifier.fillMaxWidth()) { Icon(Icons.Default.DeleteSweep, null); Spacer(Modifier.width(8.dp)); Text("Clear saved chats") } } }
            item { SettingsSection("About Leo", Icons.Default.Info) { Text("Leo v3.3.1", fontWeight = FontWeight.SemiBold); Text("Your own AI assistant") } }
        }
    }
}

@Composable private fun KeyField(label: String, value: String, onChange: (String) -> Unit) { OutlinedTextField(value, onChange, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true, visualTransformation = PasswordVisualTransformation()) }
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun FontSelector(selected: LeoFont, onChange: (LeoFont) -> Unit) { var expanded by remember { mutableStateOf(false) }; val label = when (selected) { LeoFont.SYSTEM -> "System Default"; LeoFont.SANS -> "Sans"; LeoFont.SERIF -> "Serif"; LeoFont.MONO -> "Monospace"; LeoFont.CURSIVE -> "Cursive" }; ExposedDropdownMenuBox(expanded, { expanded = !expanded }) { OutlinedTextField(label, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Font") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }); ExposedDropdownMenu(expanded, { expanded = false }) { LeoFont.values().forEach { f -> DropdownMenuItem(text = { Text(f.name.lowercase().replaceFirstChar { it.uppercase() }) }, onClick = { onChange(f); expanded = false }) } } } }
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun VoiceSelector(selected: String, voices: List<Voice>, onChange: (String) -> Unit) { var expanded by remember { mutableStateOf(false) }; val label = voices.firstOrNull { it.name == selected }?.let { "${it.locale.displayLanguage} · ${it.name}" } ?: if (selected.isBlank()) "System default" else selected; ExposedDropdownMenuBox(expanded, { expanded = !expanded }) { OutlinedTextField(label, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Voice") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }); ExposedDropdownMenu(expanded, { expanded = false }) { DropdownMenuItem(text = { Text("System default") }, onClick = { onChange(""); expanded = false }); voices.take(60).forEach { v -> DropdownMenuItem(text = { Text("${v.locale.displayLanguage} · ${v.name}") }, onClick = { onChange(v.name); expanded = false }) } } } }
@Composable private fun SettingsSection(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)) { Column(Modifier.padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(10.dp)); Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp) }; Spacer(Modifier.height(14.dp)); content() } } }
@Composable private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(checked, onChange) } }
@Composable private fun ThemeChip(label: String, selected: Boolean, onClick: () -> Unit) { FilterChip(selected, onClick, label = { Text(label) }) }
