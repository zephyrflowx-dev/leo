package com.leo.assistant

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecureStore(context: Context) {
    private val key=MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
    private val prefs=EncryptedSharedPreferences.create(
        context,"leo_secure",key,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun get(k:String)=prefs.getString(k,"") ?: ""
    fun put(k:String,v:String)=prefs.edit().putString(k,v).apply()
}
