package com.leo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ChatStore(context: Context) {
    private val store = SecureStore(context)

    fun load(): MutableList<Msg> {
        val raw = store.get("chat_messages")
        if (raw.isBlank()) return mutableListOf(Msg("Hi! I'm Leo. Ask me anything, or try \"open YouTube\".", false))
        return runCatching {
            val a = JSONArray(raw)
            MutableList(a.length()) { i ->
                val o = a.getJSONObject(i)
                Msg(o.optString("text"), o.optBoolean("user"))
            }
        }.getOrElse { mutableListOf(Msg("Hi! I'm Leo. Ask me anything, or try \"open YouTube\".", false)) }
    }

    fun save(messages: List<Msg>) {
        val a = JSONArray()
        messages.forEach { m ->
            a.put(JSONObject().put("text", m.text).put("user", m.user))
        }
        store.put("chat_messages", a.toString())
    }

    fun clear() {
        store.put("chat_messages", "")
    }
}
