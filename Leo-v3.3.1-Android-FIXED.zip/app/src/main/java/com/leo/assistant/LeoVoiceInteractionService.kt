package com.leo.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.service.voice.VoiceInteractionService

class LeoVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        val store = SecureStore(this)
        val enabled = store.get("hotword_enabled").ifBlank { "true" } == "true"
        if (enabled && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) LeoHotwordService.start(this)
    }

    override fun onShutdown() {
        LeoHotwordService.stop(this)
        super.onShutdown()
    }
}
