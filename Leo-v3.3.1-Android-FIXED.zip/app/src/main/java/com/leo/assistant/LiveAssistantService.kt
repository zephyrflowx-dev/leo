package com.leo.assistant

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import android.util.Base64

class LiveAssistantService : Service() {
    companion object {
        const val ACTION_START="com.leo.assistant.action.START_LIVE"
        const val ACTION_STOP="com.leo.assistant.action.STOP_LIVE"
        const val ACTION_STATE="com.leo.assistant.action.LIVE_STATE"
        const val ACTION_ORB_STATE="com.leo.assistant.action.ORB_STATE"
        const val EXTRA_LIVE="live"
        const val EXTRA_ORB_STATE="orb_state"
        const val CHANNEL_ID="leo_live"
        const val NOTIFICATION_ID=2601
        fun start(c:Context){val i=Intent(c,LiveAssistantService::class.java).setAction(ACTION_START);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i) else c.startService(i)}
        fun stop(c:Context){c.startService(Intent(c,LiveAssistantService::class.java).setAction(ACTION_STOP))}
    }

    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
    private var live=false
    private var ws:WebSocket?=null
    private var recorder:AudioRecord?=null
    private var player:AudioTrack?=null
    private var overlay:View?=null
    private var wm:WindowManager?=null
    private var lastInput=0L
    private var audioStarted=false
    private var retryAttempt=0
    private var speakingJob:Job?=null
    private val httpClient=OkHttpClient()

    override fun onCreate(){super.onCreate();createChannel()}
    override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int{if(i?.action==ACTION_START)startLive() else if(i?.action==ACTION_STOP)stopLive();return START_NOT_STICKY}

    private fun startLive(){
        if(live)return
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){notifyMissing("Microphone permission is required");stopSelf();return}
        if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){notifyMissing("Overlay permission is required for the voice sheet");stopSelf();return}
        val key=SecureStore(this).get("gemini")
        if(key.isBlank()){notifyMissing("Gemini API key is required for Live mode");stopSelf();return}
        live=true;retryAttempt=0;startAsForeground();showBottomSheet();sendState(true);connect()
    }

    private fun startAsForeground(){
        val pi=PendingIntent.getService(this,2,Intent(this,LiveAssistantService::class.java).setAction(ACTION_STOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n=NotificationCompat.Builder(this,CHANNEL_ID).setSmallIcon(R.drawable.leo_icon).setContentTitle("Leo Live is on").setContentText("Voice conversation active. Tap Stop to end it.").setOngoing(true).addAction(android.R.drawable.ic_media_pause,"Stop",pi).build()
        if(Build.VERSION.SDK_INT>=29)ServiceCompat.startForeground(this,NOTIFICATION_ID,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(NOTIFICATION_ID,n)
    }

    private fun notifyMissing(message:String){
        val launch=PendingIntent.getActivity(this,91,Intent(this,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        getSystemService(NotificationManager::class.java).notify(2604,NotificationCompat.Builder(this,CHANNEL_ID).setSmallIcon(R.drawable.leo_icon).setContentTitle("Leo voice needs attention").setContentText(message).setContentIntent(launch).setAutoCancel(true).build())
    }

    private fun createChannel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL_ID,"Leo Live",NotificationManager.IMPORTANCE_LOW).apply{setSound(null,null);enableVibration(false)})}

    private fun showBottomSheet(){
        if(overlay!=null)return
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val root=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(20,16,16,16)
            background=GradientDrawable().apply{setColor(Color.argb(245,24,24,28));cornerRadius=38f}
        }
        val icon=ImageView(this).apply{setImageResource(R.drawable.leo_icon);contentDescription="Leo"}
        root.addView(icon,LinearLayout.LayoutParams(64,64))
        val text=TextView(this).apply{setTextColor(Color.WHITE);textSize=16f;text="Leo is listening…";setPadding(18,0,12,0)}
        root.addView(text,LinearLayout.LayoutParams(0,72,1f))
        val stop=ImageButton(this).apply{setImageResource(android.R.drawable.ic_media_pause);setColorFilter(Color.WHITE);background=null;contentDescription="Stop Leo";setOnClickListener{stopLive()}}
        root.addView(stop,LinearLayout.LayoutParams(56,56))
        root.tag="leo_sheet_text"
        val type=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp=WindowManager.LayoutParams((resources.displayMetrics.widthPixels*0.92f).toInt(),88,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL;x=0;y=28}
        runCatching{wm?.addView(root,lp);overlay=root}.onFailure{notifyMissing("Leo could not show its voice sheet")}
    }

    private fun updateSheet(label:String){
        val root=overlay as? LinearLayout ?: return
        (root.tag as? String)?.let { if(it=="leo_sheet_text") root.getChildAt(1)?.let { v -> (v as? TextView)?.text=label } }
    }

    private fun hideOverlay(){overlay?.let{runCatching{wm?.removeView(it)}};overlay=null;wm=null}

    private fun connect(){
        if(!live)return
        val key=SecureStore(this).get("gemini")
        if(key.isBlank()){notifyMissing("Gemini API key is required for Live mode");stopLive();return}
        val url="wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key="+java.net.URLEncoder.encode(key,"UTF-8")
        val req=Request.Builder().url(url).build();audioStarted=false
        ws=httpClient.newWebSocket(req,object:WebSocketListener(){
            override fun onOpen(s:WebSocket,response:Response){
                retryAttempt=0;updateSheet("Leo is listening…")
                val history=ChatStore(this@LiveAssistantService).load().takeLast(20).joinToString("\n"){if(it.user)"User: ${it.text}" else "Leo: ${it.text}"}
                val instructions=buildString{append(AiClient.SYSTEM_PROMPT);if(history.isNotBlank()){append("\nRecent conversation context:\n");append(history)}}
                val setup=JSONObject().put("setup", JSONObject()
                    .put("model", "models/gemini-3.8-live")
                    .put("systemInstruction", JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", instructions))))
                    .put("generationConfig", JSONObject().put("responseModalities", org.json.JSONArray().put("AUDIO")))
                    .put("inputAudioTranscription", JSONObject())
                    .put("outputAudioTranscription", JSONObject())
                    .put("contextWindowCompression", JSONObject())
                )
                s.send(setup.toString())
            }
            override fun onMessage(s:WebSocket,text:String){handleServer(s,text)}
            override fun onFailure(s:WebSocket,t:Throwable,r:Response?){scheduleReconnect()}
            override fun onClosed(s:WebSocket,code:Int,reason:String){if(live)scheduleReconnect()}
        })
    }

    private fun scheduleReconnect(){
        if(!live)return
        val attempt=retryAttempt++
        if(attempt>=5){updateSheet("Leo couldn't reconnect");notifyMissing("Live connection lost. Tap Leo to try again.");stopLive();return}
        val delayMs=1000L shl attempt
        updateSheet("Reconnecting in ${delayMs/1000}s…")
        scope.launch{delay(delayMs);if(live)connect()}
    }

    private fun startAudio(socket:WebSocket){
        val min=AudioRecord.getMinBufferSize(16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        val buf=ByteArray(maxOf(min,1280))
        recorder=AudioRecord(MediaRecorder.AudioSource.MIC,16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,buf.size*2)
        recorder?.startRecording();updateSheet("Leo is listening…");sendOrb("listening")
        scope.launch{while(live&&recorder!=null){val n=recorder!!.read(buf,0,buf.size);if(n>1){var sum=0.0;var count=0;var i=0;while(i+1<n){val lo=buf[i].toInt() and 0xff;val hi=buf[i+1].toInt();val sample=((hi shl 8) or lo).toShort().toInt();sum+=sample.toDouble()*sample.toDouble();count++;i+=2};val rms=kotlin.math.sqrt((sum/count.coerceAtLeast(1)).coerceAtLeast(1.0));if(rms>1200){lastInput=System.currentTimeMillis();player?.pause();player?.flush();sendOrb("listening")};val data=Base64.encodeToString(buf.copyOf(n),Base64.NO_WRAP);socket.send(JSONObject().put("realtimeInput",JSONObject().put("audio",JSONObject().put("data",data).put("mimeType","audio/pcm;rate=16000"))).toString())}}}
    }

    private fun handleServer(socket:WebSocket,raw:String){runCatching{val o=JSONObject(raw);if(o.optJSONObject("setupComplete")!=null){if(!audioStarted){audioStarted=true;startAudio(socket)};return};val sc=o.optJSONObject("serverContent")?:return;if(sc.optBoolean("interrupted",false)){player?.pause();player?.flush();sendOrb("listening");updateSheet("Leo is listening…");return};val parts=sc.optJSONObject("modelTurn")?.optJSONArray("parts")?:return;for(i in 0 until parts.length()){val p=parts.optJSONObject(i)?:continue;val inline=p.optJSONObject("inlineData")?:continue;val data=inline.optString("data");if(data.isNotBlank())playAudio(Base64.decode(data,Base64.DEFAULT))}}}

    private fun playAudio(data:ByteArray){
        if(!live)return
        if(player==null){val min=AudioTrack.getMinBufferSize(24000,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);player=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()).setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()).setBufferSizeInBytes(maxOf(min,data.size*2)).setTransferMode(AudioTrack.MODE_STREAM).build();player?.play()}
        if(System.currentTimeMillis()-lastInput<800)return
        player?.write(data,0,data.size);updateSheet("Leo is speaking…");sendOrb("speaking");speakingJob?.cancel();speakingJob=scope.launch{delay(450);if(live){updateSheet("Leo is listening…");sendOrb("listening")}}
    }

    private fun sendState(on:Boolean)=sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra(EXTRA_LIVE,on))
    private fun sendOrb(state:String)=sendBroadcast(Intent(ACTION_ORB_STATE).setPackage(packageName).putExtra(EXTRA_ORB_STATE,state))

    private fun stopLive(){
        live=false;speakingJob?.cancel();runCatching{recorder?.stop()};recorder?.release();recorder=null;ws?.close(1000,"user stopped");ws=null;player?.stop();player?.release();player=null;hideOverlay();sendState(false);sendOrb("idle");ServiceCompat.stopForeground(this,ServiceCompat.STOP_FOREGROUND_REMOVE);stopSelf()
    }
    override fun onDestroy(){stopLive();scope.cancel();super.onDestroy()}
    override fun onBind(i:Intent?)=null
}
