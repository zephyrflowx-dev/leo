Leo wake-word model

The app uses the openWakeWord Android/ONNX engine locally.

For the exact "Hey Leo" wake phrase, put a compatible OpenWakeWord ONNX
classifier named:

    hey_leo.onnx

in this assets folder before building.

The Android code automatically uses that model when present. If it is absent,
it uses the bundled HEY_JARVIS model so the on-device wake-word engine can be
tested without a custom model.

The model must be compatible with the openWakeWord Android port used by Leo.
Do not put API keys in this folder.
