package com.leo.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Msg(val text: String, val user: Boolean)

enum class ThemeMode { SYSTEM, LIGHT, DARK }

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { LeoApp() }
    }
}

@Composable
fun LeoTheme(mode: ThemeMode, dynamicColor: Boolean, content: @Composable () -> Unit) {
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    val dark = when (mode) {
        ThemeMode.SYSTEM -> systemDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current
    val colors = if (dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        if (dark) darkColorScheme(
            primary = Color(0xFFE8E8E8),
            onPrimary = Color(0xFF111111),
            primaryContainer = Color(0xFF303030),
            onPrimaryContainer = Color(0xFFF2F2F2),
            surface = Color(0xFF101010),
            surfaceContainer = Color(0xFF1B1B1B),
            background = Color(0xFF0B0B0B)
        ) else lightColorScheme(
            primary = Color(0xFF111111),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFE9E9E9),
            onPrimaryContainer = Color(0xFF111111),
            surface = Color(0xFFF9F9F9),
            surfaceContainer = Color.White,
            background = Color(0xFFF6F6F6)
        )
    }
    MaterialTheme(colorScheme = colors, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeoApp() {
    val ctx = LocalContext.current
    val store = remember { SecureStore(ctx) }
    val scope = rememberCoroutineScope()

    var provider by remember { mutableStateOf(store.get("provider").ifBlank { "Gemini" }) }
    var openai by remember { mutableStateOf(store.get("openai")) }
    var gemini by remember { mutableStateOf(store.get("gemini")) }
    var input by remember { mutableStateOf("") }
    var settings by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var themeMode by remember {
        mutableStateOf(runCatching { ThemeMode.valueOf(store.get("theme").ifBlank { "SYSTEM" }) }.getOrDefault(ThemeMode.SYSTEM))
    }
    var dynamicColor by remember { mutableStateOf(store.get("dynamic_color") != "false") }
    var voiceReplies by remember { mutableStateOf(store.get("voice_replies") != "false") }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    val messages = remember { mutableStateListOf(Msg("Hi! I'm Leo. Ask me anything, or try “open YouTube”.", false)) }

    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) engine?.language = Locale.getDefault()
        }
        tts = engine
        onDispose {
            engine?.stop()
            engine?.shutdown()
            tts = null
        }
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            input = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: ""
        }
    }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to Leo")
        })
    }
    val contacts = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) Toast.makeText(ctx, "Contacts permission granted. Say “call Name” again.", Toast.LENGTH_SHORT).show()
    }
    val call = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) Toast.makeText(ctx, "Call permission granted. Say “call Name” again.", Toast.LENGTH_SHORT).show()
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || busy) return
        messages.add(Msg(text, true))
        input = ""
        busy = true
        scope.launch {
            val action = handleCommand(ctx, text)
            val reply = when (action) {
                is CommandResult.Done -> action.text
                is CommandResult.NeedContacts -> {
                    if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                        contacts.launch(Manifest.permission.READ_CONTACTS)
                    }
                    "I need contact permission to find that person."
                }
                is CommandResult.NeedCall -> {
                    if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        call.launch(Manifest.permission.CALL_PHONE)
                    }
                    "I need phone permission before placing the call."
                }
                CommandResult.None -> withContext(Dispatchers.IO) {
                    AiClient().ask(provider, if (provider == "OpenAI") openai else gemini, text)
                }
            }
            messages.add(Msg(reply, false))
            if (voiceReplies) tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "leo")
            busy = false
        }
    }

    LeoTheme(themeMode, dynamicColor) {
        if (settings) {
            SettingsScreen(
                provider = provider,
                onProviderChange = {
                    provider = it
                    store.put("provider", it)
                },
                openai = openai,
                onOpenAiChange = { openai = it; store.put("openai", it) },
                gemini = gemini,
                onGeminiChange = { gemini = it; store.put("gemini", it) },
                themeMode = themeMode,
                onThemeChange = {
                    themeMode = it
                    store.put("theme", it.name)
                },
                dynamicColor = dynamicColor,
                onDynamicColorChange = {
                    dynamicColor = it
                    store.put("dynamic_color", it.toString())
                },
                voiceReplies = voiceReplies,
                onVoiceRepliesChange = {
                    voiceReplies = it
                    store.put("voice_replies", it.toString())
                },
                onClearChat = {
                    messages.clear()
                    messages.add(Msg("Chat cleared. Hi! I'm Leo — ready when you are.", false))
                },
                onBack = { settings = false }
            )
        } else {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Image(
                                    painter = painterResource(com.leo.assistant.R.drawable.leo_icon),
                                    contentDescription = "Leo",
                                    modifier = Modifier.size(42.dp).clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text("Leo", fontWeight = FontWeight.Bold)
                                    Text("Your own AI", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        },
                        actions = {
                            IconButton(onClick = { settings = true }) {
                                Icon(Icons.Default.Settings, "Settings")
                            }
                        }
                    )
                },
                bottomBar = {
                    Surface(shadowElevation = 8.dp) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { mic.launch(Manifest.permission.RECORD_AUDIO) }) {
                                Icon(Icons.Default.Mic, "Voice")
                            }
                            OutlinedTextField(
                                value = input,
                                onValueChange = { input = it },
                                modifier = Modifier.weight(1f),
                                placeholder = { Text("Ask Leo...") },
                                singleLine = true,
                                shape = RoundedCornerShape(24.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            FilledIconButton(onClick = { send() }, enabled = !busy) {
                                Icon(Icons.Default.Send, "Send")
                            }
                        }
                    }
                }
            ) { p ->
                Column(
                    Modifier.fillMaxSize().padding(p).padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Card(
                        Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(Modifier.padding(18.dp)) {
                            Text("Hello", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(4.dp))
                            Text("What can I help with?", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("AI provider", style = MaterialTheme.typography.labelMedium)
                                Spacer(Modifier.width(8.dp))
                                AssistChip(
                                    onClick = {
                                        provider = if (provider == "OpenAI") "Gemini" else "OpenAI"
                                        store.put("provider", provider)
                                    },
                                    label = { Text(provider) }
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    LazyColumn(
                        Modifier.weight(1f).fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 8.dp)
                    ) {
                        items(messages) { m ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = if (m.user) Arrangement.End else Arrangement.Start
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = if (m.user) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainer,
                                    contentColor = if (m.user) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                    tonalElevation = if (m.user) 0.dp else 1.dp
                                ) {
                                    Text(m.text, Modifier.padding(horizontal = 15.dp, vertical = 12.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(
    provider: String,
    onProviderChange: (String) -> Unit,
    openai: String,
    onOpenAiChange: (String) -> Unit,
    gemini: String,
    onGeminiChange: (String) -> Unit,
    themeMode: ThemeMode,
    onThemeChange: (ThemeMode) -> Unit,
    dynamicColor: Boolean,
    onDynamicColorChange: (Boolean) -> Unit,
    voiceReplies: Boolean,
    onVoiceRepliesChange: (Boolean) -> Unit,
    onClearChat: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
                title = { Text("Settings", fontWeight = FontWeight.Bold) }
            )
        }
    ) { p ->
        LazyColumn(
            Modifier.fillMaxSize().padding(p),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SettingsSection("Appearance", Icons.Default.Palette) {
                    Text("Theme", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeChip("System", themeMode == ThemeMode.SYSTEM) { onThemeChange(ThemeMode.SYSTEM) }
                        ThemeChip("Light", themeMode == ThemeMode.LIGHT) { onThemeChange(ThemeMode.LIGHT) }
                        ThemeChip("Dark", themeMode == ThemeMode.DARK) { onThemeChange(ThemeMode.DARK) }
                    }
                    Spacer(Modifier.height(10.dp))
                    SettingSwitch("Use device dynamic colors", dynamicColor, onDynamicColorChange)
                    Text(
                        "On Android 12+, Leo can use colors derived from the device wallpaper.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            item {
                SettingsSection("AI provider", Icons.Default.Settings) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = provider == "Gemini", onClick = { onProviderChange("Gemini") }, label = { Text("Gemini") })
                        FilterChip(selected = provider == "OpenAI", onClick = { onProviderChange("OpenAI") }, label = { Text("OpenAI") })
                    }
                }
            }
            item {
                SettingsSection("API keys", Icons.Default.Key) {
                    Text("Keys are encrypted and stored locally on this device.", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = openai,
                        onValueChange = onOpenAiChange,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("OpenAI API key") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = gemini,
                        onValueChange = onGeminiChange,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Gemini API key") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                }
            }
            item {
                SettingsSection("Voice", Icons.Default.VolumeUp) {
                    SettingSwitch("Read Leo replies aloud", voiceReplies, onVoiceRepliesChange)
                }
            }
            item {
                SettingsSection("Chat", Icons.Default.DeleteSweep) {
                    OutlinedButton(onClick = onClearChat, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.DeleteSweep, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Clear chat")
                    }
                }
            }
            item {
                SettingsSection("About Leo", Icons.Default.Info) {
                    Text("Leo v1.8.0", fontWeight = FontWeight.SemiBold)
                    Text("Your own AI assistant", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                    Text("API keys stay on the device and are not included in the APK source.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun SettingsSection(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null)
                Spacer(Modifier.width(10.dp))
                Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun ThemeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

sealed class CommandResult {
    data class Done(val text: String) : CommandResult()
    object NeedContacts : CommandResult()
    object NeedCall : CommandResult()
    object None : CommandResult()
}

suspend fun handleCommand(ctx: Context, text: String): CommandResult {
    val l = text.lowercase(Locale.getDefault()).trim()
    if (l.startsWith("search ")) {
        val q = text.substringAfter("search ").trim()
        if (q.isNotBlank()) {
            ctx.startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", q))
            return CommandResult.Done("Searching for $q.")
        }
    }
    if (l.startsWith("open ")) {
        val name = l.removePrefix("open ").trim()
        val pkg = when {
            "youtube" in name -> "com.google.android.youtube"
            "whatsapp" in name -> "com.whatsapp"
            "chrome" in name -> "com.android.chrome"
            "instagram" in name -> "com.instagram.android"
            "settings" in name -> "com.android.settings"
            else -> null
        }
        if (pkg != null) {
            val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                ctx.startActivity(i)
                return CommandResult.Done("Opening $name.")
            }
        }
        return CommandResult.Done("I couldn't find $name.")
    }
    if (l.startsWith("call ")) {
        val name = text.substringAfter("call ").trim()
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return CommandResult.NeedContacts
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val cur = ctx.contentResolver.query(
            uri,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        )
        cur?.use {
            if (it.moveToFirst()) {
                val number = it.getString(0)
                if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
                    return CommandResult.NeedCall
                ctx.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}")))
                return CommandResult.Done("Calling ${it.getString(1)}.")
            }
        }
        return CommandResult.Done("I couldn't find a contact named $name.")
    }
    return CommandResult.None
}
