# Leo v1.8.0

Personal Android AI assistant.

## v1.8 fixes
- Gemini now uses `gemini-3.5-flash-lite` instead of the old `gemini-2.0-flash` endpoint.
- Gemini API key is sent with the `x-goog-api-key` header.
- Clear 401/403/404/429 messages for Gemini and OpenAI.
- API keys remain encrypted locally on the device and are not included in this project.
- Existing voice input, TTS, app opening, web search, contacts/calling, and provider switching are retained.


## v1.8 highlights
- Redesigned Material 3 home screen and chat bubbles
- Full Settings screen
- Theme controls: System default, Light, Dark
- Optional Android 12+ dynamic colors
- Voice reply toggle
- Clear chat
- New Leo launcher icon using the supplied Leo logo
