package com.leo.assistant

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionService

class LeoRecognitionService : RecognitionService() {
    override fun onStartListening(intent: Intent, listener: Callback) {
        listener.error(ERROR_CLIENT)
    }

    override fun onCancel(listener: Callback) {
        // The assistant session owns its active speech recognition flow.
    }

    override fun onStopListening(listener: Callback) {
        listener.error(ERROR_CLIENT)
    }
}
