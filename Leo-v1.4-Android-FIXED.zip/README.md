# Leo v1.4

Leo is a personal Android AI assistant.

## v1.3 features
- OpenAI + Gemini provider switching
- Encrypted local API key storage
- AI chat
- Android speech input
- Text-to-speech
- Web search command: `search weather tomorrow`
- App launching: `open YouTube`, `open WhatsApp`, `open Chrome`, `open Settings`
- Contact lookup and phone calling: `call Mom`
- GitHub Actions workflow that builds a debug APK
- No API keys included in source

## Build without a laptop
1. Create a GitHub repository from the Android phone.
2. Extract this ZIP.
3. Upload the extracted project files/folders to the repository, preserving `.github/workflows/build-apk.yml`.
4. Commit to `main`.
5. Open the repository's Actions tab and run "Build Leo APK" if it does not start automatically.
6. Open the completed workflow run and download the `Leo-v1.3-debug` artifact.
7. Extract the artifact and install `app-debug.apk` on the Android phone.

Android's normal debug APK is signed with a debug certificate. A release APK for distribution needs a private release key; do not publish a debug APK as a production release.

## API keys
Do not put API keys into source code. Enter them in Leo's Settings after installing the APK. They are stored with Android encrypted preferences on the device.

## Wake word
“Hey Leo” is not falsely advertised as complete in v1.3. Android background microphone and hotword behavior has platform restrictions. A dedicated wake-word engine and foreground-service design should be added and tested separately.
