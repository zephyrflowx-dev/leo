package com.leo.assistant

import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject

class AiClient {
    fun ask(provider:String,key:String,message:String):String {
        if(key.isBlank()) return "Add your $provider API key in Settings."
        return try { if(provider=="OpenAI") openAi(key,message) else gemini(key,message) }
        catch(e:Exception) { "Leo couldn't reach $provider. Check your connection and API key." }
    }
    private fun openAi(key:String,msg:String):String {
        val c=URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod="POST"; c.doOutput=true
        c.setRequestProperty("Authorization","Bearer $key")
        c.setRequestProperty("Content-Type","application/json")
        val b=JSONObject().put("model","gpt-4o-mini")
            .put("messages",JSONArray().put(JSONObject().put("role","user").put("content",msg)))
        c.outputStream.use{it.write(b.toString().toByteArray())}
        val r=if(c.responseCode in 200..299)c.inputStream else c.errorStream
        val s=r.bufferedReader().readText()
        if(c.responseCode !in 200..299) return "OpenAI error: ${c.responseCode}"
        return JSONObject(s).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }
    private fun gemini(key:String,msg:String):String {
        val u="https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key"
        val c=URL(u).openConnection() as HttpURLConnection
        c.requestMethod="POST"; c.doOutput=true
        c.setRequestProperty("Content-Type","application/json")
        val b=JSONObject().put("contents",JSONArray().put(JSONObject().put(
            "parts",JSONArray().put(JSONObject().put("text",msg)))))
        c.outputStream.use{it.write(b.toString().toByteArray())}
        val r=if(c.responseCode in 200..299)c.inputStream else c.errorStream
        val s=r.bufferedReader().readText()
        if(c.responseCode !in 200..299) return "Gemini error: ${c.responseCode}"
        return JSONObject(s).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }
}
