package com.leo.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Msg(val text:String,val user:Boolean)

class MainActivity:Activity(){
    override fun onCreate(b:android.os.Bundle?){super.onCreate(b);setContent{LeoApp()}}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeoApp(){
    val ctx=LocalContext.current
    val store=remember{SecureStore(ctx)}
    val scope=rememberCoroutineScope()
    var provider by remember{mutableStateOf(store.get("provider").ifBlank{"OpenAI"})}
    var openai by remember{mutableStateOf(store.get("openai"))}
    var gemini by remember{mutableStateOf(store.get("gemini"))}
    var input by remember{mutableStateOf("")}
    var settings by remember{mutableStateOf(false)}
    var busy by remember{mutableStateOf(false)}
    var tts by remember{mutableStateOf<TextToSpeech?>(null)}
    val messages=remember{mutableStateListOf(Msg("Hi! I'm Leo. Try asking a question or saying “open YouTube”.",false))}

    DisposableEffect(Unit){
        val x=TextToSpeech(ctx){if(it==TextToSpeech.SUCCESS)xSet(x)}
        tts=x
        onDispose{x.shutdown()}
    }
    fun xSet(x:TextToSpeech){x.language=Locale.getDefault()}

    val speech=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r->
        if(r.resultCode==Activity.RESULT_OK)
            input=r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?:""
    }
    val mic=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){ok->
        if(ok)speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT,"Talk to Leo")
        })
    }
    val contacts=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){ok->
        if(ok) Toast.makeText(ctx,"Contacts permission granted. Say “call Name” again.",Toast.LENGTH_SHORT).show()
    }
    val call=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){ok->
        if(ok) Toast.makeText(ctx,"Call permission granted. Say “call Name” again.",Toast.LENGTH_SHORT).show()
    }

    fun send(){
        val text=input.trim();if(text.isEmpty()||busy)return
        messages.add(Msg(text,true));input="";busy=true
        scope.launch{
            val action=handleCommand(ctx,text)
            val reply=when(action){
                is CommandResult.Done->action.text
                is CommandResult.NeedContacts->{
                    if(ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)
                        contacts.launch(Manifest.permission.READ_CONTACTS)
                    "I need contact permission to find that person."
                }
                is CommandResult.NeedCall->{
                    if(ctx.checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED)
                        call.launch(Manifest.permission.CALL_PHONE)
                    "I need phone permission before placing the call."
                }
                CommandResult.None->withContext(Dispatchers.IO){
                    AiClient().ask(provider,if(provider=="OpenAI")openai else gemini,text)
                }
            }
            messages.add(Msg(reply,false))
            tts?.speak(reply,TextToSpeech.QUEUE_FLUSH,null,"leo")
            busy=false
        }
    }

    MaterialTheme{
        Scaffold(topBar={TopAppBar(title={Text("🦁 Leo")},actions={
            IconButton({settings=true}){Icon(Icons.Default.Settings,null)}
        })},bottomBar={
            Row(Modifier.fillMaxWidth().padding(8.dp)){
                IconButton({mic.launch(Manifest.permission.RECORD_AUDIO)}){Icon(Icons.Default.Mic,"Voice")}
                OutlinedTextField(input,{input=it},Modifier.weight(1f),
                    placeholder={Text("Ask Leo...")},singleLine=true,
                    shape=RoundedCornerShape(24.dp))
                IconButton({send()}){Icon(Icons.Default.Send,"Send")}
            }
        }){p->
            Column(Modifier.fillMaxSize().padding(p).padding(12.dp)){
                Row{Text("AI: ");AssistChip({
                    provider=if(provider=="OpenAI")"Gemini" else "OpenAI"
                    store.put("provider",provider)
                },label={Text(provider)})}
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    items(messages){m->Surface(
                        Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),
                        color=if(m.user)MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    ){Text(m.text,Modifier.padding(13.dp))}}
                }
            }
        }
        if(settings)AlertDialog(
            onDismissRequest={settings=false},
            title={Text("Leo Settings")},
            text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("Keys are encrypted locally on this device.")
                OutlinedTextField(openai,{openai=it;store.put("openai",it)},
                    label={Text("OpenAI API key")},singleLine=true)
                OutlinedTextField(gemini,{gemini=it;store.put("gemini",it)},
                    label={Text("Gemini API key")},singleLine=true)
                Text("Wake word: planned for the next build. Android background microphone access has platform restrictions.")
            }},
            confirmButton={Button({settings=false}){Text("Done")}}
        )
    }
}

sealed class CommandResult{
    data class Done(val text:String):CommandResult()
    object NeedContacts:CommandResult()
    object NeedCall:CommandResult()
    object None:CommandResult()
}

suspend fun handleCommand(ctx:Context,text:String):CommandResult{
    val l=text.lowercase(Locale.getDefault()).trim()
    if(l.startsWith("search ")){
        val q=text.substringAfter("search ").trim()
        if(q.isNotBlank()){
            ctx.startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query",q))
            return CommandResult.Done("Searching for $q.")
        }
    }
    if(l.startsWith("open ")){
        val name=l.removePrefix("open ").trim()
        val pkg=when{
            "youtube" in name->"com.google.android.youtube"
            "whatsapp" in name->"com.whatsapp"
            "chrome" in name->"com.android.chrome"
            "instagram" in name->"com.instagram.android"
            "settings" in name->"com.android.settings"
            else->null
        }
        if(pkg!=null){
            val i=ctx.packageManager.getLaunchIntentForPackage(pkg)
            if(i!=null){ctx.startActivity(i);return CommandResult.Done("Opening $name.")}
        }
        return CommandResult.Done("I couldn't find $name.")
    }
    if(l.startsWith("call ")){
        val name=text.substringAfter("call ").trim()
        if(ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)
            return CommandResult.NeedContacts
        val uri=ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val cur=ctx.contentResolver.query(uri,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER,ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),null)
        cur?.use{
            if(it.moveToFirst()){
                val number=it.getString(0)
                if(ctx.checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED)
                    return CommandResult.NeedCall
                ctx.startActivity(Intent(Intent.ACTION_CALL,Uri.parse("tel:${Uri.encode(number)}")))
                return CommandResult.Done("Calling ${it.getString(1)}.")
            }
        }
        return CommandResult.Done("I couldn't find a contact named $name.")
    }
    return CommandResult.None
}
